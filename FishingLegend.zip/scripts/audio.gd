extends Node
# Мягкие фоновые звуки и эффекты. Файлы лежат в assets/audio/*.pcm (16 бит, моно, 22050 Гц),
# их создаёт tools/gen_audio.py

const LOOPS := ["wind", "water", "rain", "crickets", "drag", "rustle", "music"]
const SHOTS := ["bird1", "bird2", "bird3", "splash", "plop", "plip", "bell", "click", "swish", "chime", "snap", "step_grass", "step_wood", "thunder", "rattle", "beep", "frog", "fishjump"]

var muted: bool = false
var _streams: Dictionary = {}
var _loops: Dictionary = {}
var _pool: Array = []
var _pool_i: int = 0
var _bird_t: float = 6.0

func _ready() -> void:
	var lpf := AudioEffectLowPassFilter.new()
	lpf.cutoff_hz = 7000.0
	AudioServer.add_bus_effect(0, lpf)
	AudioServer.add_bus_effect(0, AudioEffectLimiter.new())
	AudioServer.set_bus_volume_db(0, -3.0)
	for n in LOOPS:
		var s := _load(n, true)
		if s == null:
			continue
		var p := AudioStreamPlayer.new()
		p.stream = s
		p.volume_db = -80.0
		add_child(p)
		p.play()
		_loops[n] = p
	for n in SHOTS:
		var s2 := _load(n, false)
		if s2 != null:
			_streams[n] = s2
	for i in 8:
		var p2 := AudioStreamPlayer.new()
		add_child(p2)
		_pool.append(p2)

func _load(name: String, loop: bool) -> AudioStreamWAV:
	var bytes := FileAccess.get_file_as_bytes("res://assets/audio/%s.pcm" % name)
	if bytes.is_empty():
		return null
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = 22050
	s.stereo = false
	s.data = bytes
	if loop:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = bytes.size() / 2
	return s

func set_muted(m: bool) -> void:
	muted = m
	AudioServer.set_bus_mute(0, m)

func play(name: String, vol_db: float = -12.0, pitch: float = 1.0) -> void:
	if not _streams.has(name):
		return
	var p: AudioStreamPlayer = _pool[_pool_i]
	_pool_i = (_pool_i + 1) % _pool.size()
	p.stream = _streams[name]
	p.volume_db = vol_db
	p.pitch_scale = pitch
	p.play()

func _vol(name: String, db: float) -> void:
	if _loops.has(name):
		_loops[name].volume_db = db

func set_drag(v: float) -> void:
	_vol("drag", -80.0 if v < 0.05 else lerpf(-30.0, -14.0, v))

# day: 0..1 (1 — день), wind/rain/water: 0..1
func update_ambience(day: float, wind: float, rain: float, water: float) -> void:
	_vol("wind", lerpf(-36.0, -22.0, wind))
	_vol("rustle", lerpf(-46.0, -26.0, wind))
	_vol("music", -27.0)
	_vol("water", -80.0 if water < 0.05 else lerpf(-36.0, -20.0, water))
	_vol("rain", -80.0 if rain < 0.05 else lerpf(-34.0, -16.0, rain))
	_vol("crickets", lerpf(-26.0, -80.0, clampf(day * 5.0, 0.0, 1.0)) if rain < 0.3 else -80.0)

var _amb_t: float = 12.0

func tick(delta: float, day: float, rain: float, water: float = 0.0) -> void:
	_amb_t -= delta
	if _amb_t <= 0.0:
		_amb_t = randf_range(9.0, 24.0)
		if water > 0.3 and rain < 0.5:
			if day < 0.25:
				play("frog", randf_range(-30.0, -24.0), randf_range(0.9, 1.1))
			else:
				play("fishjump", randf_range(-30.0, -24.0), randf_range(0.9, 1.1))
	_bird_t -= delta
	if _bird_t <= 0.0:
		_bird_t = randf_range(5.0, 14.0)
		if day > 0.35 and rain < 0.3:
			play("bird%d" % randi_range(1, 3), randf_range(-30.0, -24.0), randf_range(0.9, 1.15))
