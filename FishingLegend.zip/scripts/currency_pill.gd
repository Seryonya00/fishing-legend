extends Control
# Плашка валюты: серебро или золото

var amount: int = 0:
	set(v):
		amount = v
		queue_redraw()
var kind: String = "silver"

func _init() -> void:
	custom_minimum_size = Vector2(170, 50)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _fmt(n: int) -> String:
	var s := str(n)
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = " " + out
	return out

func _draw() -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.11, 0.15, 0.92)
	sb.set_corner_radius_all(25)
	sb.border_color = Color(1, 1, 1, 0.16)
	sb.set_border_width_all(2)
	draw_style_box(sb, Rect2(Vector2.ZERO, size))
	var c := Vector2(28, size.y * 0.5)
	if kind == "gold":
		draw_colored_polygon(PackedVector2Array([c + Vector2(-16, 8), c + Vector2(-10, -8), c + Vector2(14, -8), c + Vector2(18, 8)]), Color(0.95, 0.75, 0.2))
		draw_colored_polygon(PackedVector2Array([c + Vector2(-10, -8), c + Vector2(14, -8), c + Vector2(10, -13), c + Vector2(-6, -13)]), Color(1.0, 0.9, 0.5))
	else:
		draw_circle(c, 15, Color(0.82, 0.84, 0.88))
		draw_arc(c, 11, 0.0, TAU, 24, Color(0.5, 0.52, 0.58), 2.5)
		draw_string(ThemeDB.fallback_font, c + Vector2(-5, 7), "$", HORIZONTAL_ALIGNMENT_LEFT, 20, 18, Color(0.4, 0.42, 0.48))
	var col := Color(1.0, 0.8, 0.25) if kind == "gold" else Color(0.9, 0.93, 0.97)
	draw_string(ThemeDB.fallback_font, Vector2(54, size.y * 0.5 + 10), _fmt(amount), HORIZONTAL_ALIGNMENT_LEFT, size.x - 60, 28, col)
