extends RefCounted
# Каталог: рыба, удилища, лески, наживки

const FISH := {
	"roach": {"name": "Плотва", "kind": "small", "temp": [4.0, 12.0, 22.0, 28.0], "bottom": ["sand", "silt", "grass"], "struct": false, "hook": 0, "min": 0.05, "max": 0.45, "kg_price": 180, "pull": 0.30, "len": 33, "chance": 40, "depth": [0.5, 4.0], "baits": ["worm", "maggot", "bread", "corn"], "col": [0.72, 0.78, 0.82]},
	"perch": {"name": "Окунь", "kind": "pred", "temp": [4.0, 10.0, 20.0, 26.0], "bottom": ["sand", "stone", "grass"], "struct": true, "hook": 1, "min": 0.10, "max": 1.20, "kg_price": 220, "pull": 0.45, "len": 30, "chance": 25, "depth": [1.0, 5.0], "baits": ["worm", "maggot"], "col": [0.45, 0.55, 0.25]},
	"crucian": {"name": "Карась", "kind": "small", "temp": [8.0, 16.0, 26.0, 30.0], "bottom": ["silt", "grass"], "struct": false, "hook": 0, "min": 0.10, "max": 1.50, "kg_price": 200, "pull": 0.45, "len": 29, "chance": 25, "depth": [0.3, 2.5], "baits": ["worm", "corn", "bread"], "col": [0.80, 0.65, 0.30]},
	"bream": {"name": "Лещ", "kind": "peace", "temp": [6.0, 12.0, 22.0, 27.0], "bottom": ["silt", "sand"], "struct": false, "hook": 1, "min": 0.30, "max": 6.0, "kg_price": 260, "pull": 0.45, "len": 36, "chance": 15, "depth": [2.0, 6.0], "baits": ["worm", "maggot", "corn"], "col": [0.65, 0.62, 0.55]},
	"pike": {"name": "Щука", "kind": "pred", "temp": [3.0, 8.0, 18.0, 24.0], "bottom": ["grass", "silt"], "struct": true, "hook": 2, "min": 0.80, "max": 20.0, "kg_price": 400, "pull": 0.80, "len": 45, "chance": 4, "depth": [1.5, 5.0], "baits": ["worm"], "col": [0.35, 0.5, 0.3]},
	"carp": {"name": "Карп", "kind": "peace", "temp": [10.0, 18.0, 26.0, 30.0], "bottom": ["silt", "grass", "shell"], "struct": false, "hook": 2, "min": 1.00, "max": 30.0, "kg_price": 380, "pull": 0.90, "len": 38, "chance": 5, "depth": [1.5, 6.0], "baits": ["corn", "bread"], "col": [0.75, 0.55, 0.2]},
	"zander": {"name": "Судак", "kind": "night", "temp": [6.0, 12.0, 20.0, 26.0], "bottom": ["stone", "sand", "shell"], "struct": true, "hook": 2, "min": 0.8, "max": 12.0, "kg_price": 450, "pull": 0.85, "len": 42, "chance": 1, "depth": [3.0, 8.0], "baits": ["worm"], "col": [0.55, 0.60, 0.50]},
	"asp": {"name": "Жерех", "kind": "pred", "temp": [8.0, 14.0, 22.0, 27.0], "bottom": ["sand", "stone"], "struct": false, "hook": 1, "min": 0.5, "max": 8.0, "kg_price": 380, "pull": 0.95, "len": 40, "chance": 1, "depth": [0.3, 2.5], "baits": ["worm", "maggot"], "col": [0.70, 0.75, 0.80]},
	"chub": {"name": "Голавль", "kind": "pred", "temp": [5.0, 12.0, 22.0, 27.0], "bottom": ["stone", "sand"], "struct": true, "hook": 1, "min": 0.2, "max": 3.0, "kg_price": 300, "pull": 0.60, "len": 34, "chance": 1, "depth": [0.5, 3.0], "baits": ["worm", "maggot", "bread"], "col": [0.60, 0.50, 0.35]},
	"sturgeon": {"name": "Осётр", "kind": "peace", "temp": [6.0, 12.0, 20.0, 25.0], "bottom": ["sand", "silt"], "struct": false, "hook": 2, "min": 3.0, "max": 30.0, "kg_price": 700, "pull": 1.0, "len": 52, "chance": 1, "depth": [3.0, 8.0], "baits": ["worm"], "col": [0.5, 0.52, 0.48]},
	"catfish": {"name": "Сом", "kind": "night", "temp": [14.0, 20.0, 28.0, 32.0], "bottom": ["silt", "grass"], "struct": true, "hook": 2, "min": 2.0, "max": 30.0, "kg_price": 520, "pull": 0.95, "len": 55, "chance": 1, "depth": [2.5, 8.0], "baits": ["worm"], "col": [0.35, 0.33, 0.28]},
	"burbot": {"name": "Налим", "kind": "night", "temp": [1.0, 4.0, 14.0, 20.0], "bottom": ["stone", "silt"], "struct": true, "hook": 2, "min": 0.3, "max": 8.0, "kg_price": 420, "pull": 0.8, "len": 45, "chance": 1, "depth": [2.0, 8.0], "baits": ["worm"], "col": [0.42, 0.38, 0.25]},
}


const LINES := [
	{"name": "Леска 0.20 мм", "kg": 2.0, "price": 0},
	{"name": "Леска 0.28 мм", "kg": 4.5, "price": 250},
	{"name": "Флюорокарбон 0.35 мм", "kg": 8.0, "price": 800},
]

const BAITS := {
	"worm": {"name": "Червь", "price": 30},
	"maggot": {"name": "Опарыш", "price": 40},
	"corn": {"name": "Кукуруза", "price": 50},
	"bread": {"name": "Хлеб", "price": 20},
}

const HOOKS := [
	{"name": "Крючок №14 (мелкий)", "kg": 2.5, "price": 0},
	{"name": "Крючок №10 (средний)", "kg": 4.0, "price": 60},
	{"name": "Крючок №6 (крупный)", "kg": 7.0, "price": 100},
]

const FLOATS := [
	{"name": "Поплавок 1 г", "cap": 1, "price": 0},
	{"name": "Поплавок 2 г", "cap": 2, "price": 80},
	{"name": "Поплавок 4 г", "cap": 4, "price": 150},
]

const FEEDERS := [
	{"name": "Кормушка 20 г", "w": 20, "price": 0},
	{"name": "Кормушка 40 г", "w": 40, "price": 200},
	{"name": "Кормушка 60 г", "w": 60, "price": 350},
]

const SINKERS := [1, 2, 4, 6]

const GB_BASES := {
	"univ": {"name": "Универсальная", "price": 40, "aff": {"roach": 0.4, "perch": 0.2, "crucian": 0.4, "bream": 0.4, "carp": 0.4}},
	"bream": {"name": "Для леща и плотвы", "price": 60, "aff": {"roach": 1.0, "bream": 1.2, "crucian": 0.3}},
	"carp": {"name": "Для карася и карпа", "price": 60, "aff": {"crucian": 1.0, "carp": 1.2, "bream": 0.3}},
}

const GB_FLAVORS := {
	"none": {"name": "без запаха", "price": 0, "aff": {}},
	"vanilla": {"name": "ваниль", "price": 20, "aff": {"crucian": 0.5, "carp": 0.6, "bream": 0.2}},
	"garlic": {"name": "чеснок", "price": 20, "aff": {"bream": 0.5, "roach": 0.4, "pike": 0.2}},
	"anise": {"name": "анис", "price": 20, "aff": {"roach": 0.6, "perch": 0.3, "bream": 0.2}},
}

const GB_ADDS := {
	"none": {"name": "без добавок", "price": 0, "aff": {}},
	"corn": {"name": "кукуруза", "price": 15, "aff": {"carp": 0.8, "crucian": 0.4}},
	"worm": {"name": "рубленый червь", "price": 15, "aff": {"perch": 0.9, "bream": 0.4, "pike": 0.2}},
}

# Во сколько раз прикормка повышает шанс данной рыбы (1.0 = без эффекта)
static func gb_effect(fish_id: String, mix: Dictionary) -> float:
	if mix.is_empty():
		return 1.0
	var e := 1.0
	e += float(GB_BASES[mix["base"]]["aff"].get(fish_id, 0.0))
	e += float(GB_FLAVORS[mix["flavor"]]["aff"].get(fish_id, 0.0))
	e += float(GB_ADDS[mix["add"]]["aff"].get(fish_id, 0.0))
	return e

# Удилища по классам. kg — «тест» (макс. нагрузка), range — дальность заброса, cast — вес заброса (г)
const ROD_CLASSES := {
	"float": [
		{"name": "Бамбуковая удочка 3 м", "lvl": 1, "range": 10.0, "kg": 1.5, "reel": 0.0, "cast": 10, "price": 0},
		{"name": "Карбон «Поплавок» 4 м", "lvl": 4, "range": 14.0, "kg": 3.0, "reel": 0.0, "cast": 12, "price": 350},
		{"name": "Телескоп «Мастер» 5 м", "lvl": 8, "range": 18.0, "kg": 5.0, "reel": 0.0, "cast": 15, "price": 1100},
	],
	"feeder": [
		{"name": "Фидер «Старт» 3.3 м", "lvl": 2, "reel_kg": 3.0, "drag_kg": 2.4, "range": 22.0, "kg": 2.5, "reel": 1.0, "cast": 40, "price": 250},
		{"name": "Фидер «Классик» 3.6 м", "lvl": 6, "reel_kg": 5.0, "drag_kg": 4.0, "range": 30.0, "kg": 4.0, "reel": 1.2, "cast": 70, "price": 900},
		{"name": "Фидер «Про» 3.9 м", "lvl": 10, "reel_kg": 8.0, "drag_kg": 6.4, "range": 38.0, "kg": 6.0, "reel": 1.4, "cast": 110, "price": 2200},
	],
	"spin": [
		{"name": "Спиннинг «Старт» 2.1 м", "lvl": 2, "reel_kg": 3.0, "drag_kg": 2.4, "range": 24.0, "kg": 2.0, "reel": 1.0, "cast": 15, "price": 250},
		{"name": "Спиннинг «Классик» 2.4 м", "lvl": 6, "reel_kg": 5.0, "drag_kg": 4.0, "range": 32.0, "kg": 3.5, "reel": 1.2, "cast": 30, "price": 900},
		{"name": "Спиннинг «Про» 2.7 м", "lvl": 10, "reel_kg": 8.0, "drag_kg": 6.4, "range": 40.0, "kg": 6.0, "reel": 1.4, "cast": 50, "price": 2200},
	],
}

const CLASS_NAMES := {"float": "Поплавочная", "feeder": "Фидер", "spin": "Спиннинг"}
const CLASS_ORDER := ["float", "feeder", "spin"]

# Приманки для спиннинга: depth — рабочая глубина, speed — скорость проводки (м/с), size — крупность
const LURES := [
	{"name": "Блесна-вертушка №2", "kg": 2.5, "depth": [0.5, 3.0], "speed": [0.8, 2.5], "size": 0, "price": 0},
	{"name": "Воблер «Минноу»", "kg": 3.5, "depth": [0.5, 2.0], "speed": [0.6, 2.0], "size": 1, "price": 150},
	{"name": "Джиг-силикон", "kg": 5.0, "depth": [2.0, 8.0], "speed": [0.4, 1.4], "size": 2, "price": 120},
]

const LURE_AFF := {"pike": 1.0, "zander": 0.9, "asp": 0.95, "catfish": 0.3, "perch": 0.8, "chub": 0.3, "roach": 0.05, "bream": 0.02, "crucian": 0.02, "carp": 0.02}

# Локации
const LOCS := {
	"pond": {"name": "Пруд", "lvl": 1, "kind": "pond", "center": Vector2(0, -45), "r": 30.0, "depth": 3.5, "x0": -80.0, "x1": 80.0, "z0": -110.0, "z1": 50.0, "cell": 2.0, "pier": [0.0, -6.5, -21.0], "trees": 80, "flow": Vector2(0, 0), "temp": 19.0, "fish": {"roach": 40, "crucian": 40, "perch": 15, "carp": 6, "pike": 2}},
	"lake": {"name": "Озеро", "lvl": 3, "kind": "lake", "center": Vector2(0, -90), "r": 60.0, "depth": 8.0, "x0": -140.0, "x1": 140.0, "z0": -210.0, "z1": 50.0, "cell": 3.2, "pier": [0.0, -8.0, -38.0], "trees": 120, "flow": Vector2(0, 0), "temp": 16.0, "fish": {"roach": 30, "perch": 25, "bream": 25, "pike": 8, "carp": 8, "zander": 5, "sturgeon": 1.5, "catfish": 2, "burbot": 3}},
	"river": {"name": "Река", "lvl": 5, "kind": "river", "center": Vector2(0, -50), "r": 13.0, "depth": 3.5, "x0": -120.0, "x1": 120.0, "z0": -130.0, "z1": 50.0, "cell": 2.4, "pier": [0.0, -30.0, -44.0], "trees": 100, "flow": Vector2(0.7, 0), "temp": 15.0, "fish": {"roach": 20, "chub": 25, "asp": 12, "perch": 15, "bream": 12, "pike": 5, "zander": 8, "sturgeon": 2, "catfish": 3, "burbot": 4}},
}

static func cur_rod() -> Dictionary:
	var t: String = str(State.rig["type"])
	var i: int = int(State.rods.get(t, -1))
	if i < 0:
		return {}
	return ROD_CLASSES[t][i]

static func rod_of(c: Dictionary) -> Dictionary:
	var t: String = str(c["type"])
	var i: int = int(State.rods.get(t, -1))
	if i < 0:
		return {}
	return ROD_CLASSES[t][i]

# Сигнализаторы поклёвки для фидера
const SIGNALS := [
	{"name": "Колокольчик", "price": 0},
	{"name": "Электронный сигнализатор", "price": 350},
]

# Подставки (рогатки): слот 2 и 3
const STAND_PRICES := [0, 150, 250]

# Акция: скидка 30% на удочки старшего уровня («ПРОФИ»)
static func rod_price(tier: int, price: int) -> int:
	return int(price * 0.7) if tier == 2 else price

# ---------- рынок: эксклюзивные заказы, обновляются раз в 2 игровых суток ----------
const MARKET_FISH := ["bream", "pike", "carp", "zander", "asp", "sturgeon", "catfish"]
const MARKET_MULT := 2.0

static func market_orders(cycle: int) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = cycle * 7919 + 13
	var pool: Array = MARKET_FISH.duplicate()
	var out: Array = []
	for i in 4:
		var idx: int = rng.randi() % pool.size()
		var id: String = pool[idx]
		pool.remove_at(idx)
		var mx: float = float(FISH[id]["max"])
		var lo: float = maxf(3.0, mx * 0.25)
		var hi: float = maxf(lo + 0.5, mx * 0.6)
		out.append({"fish": id, "min": snappedf(rng.randf_range(lo, hi), 0.5), "need": rng.randi_range(1, 3)})
	return out

# ---------- достижения ----------
const ACH := [
	{"id": "first", "name": "Первая рыба", "desc": "Поймай любую рыбу", "kind": "count", "need": 1, "silver": 50},
	{"id": "c25", "name": "Рыбак", "desc": "Поймай 25 рыб", "kind": "count", "need": 25, "silver": 200},
	{"id": "c100", "name": "Мастер улова", "desc": "Поймай 100 рыб", "kind": "count", "need": 100, "silver": 800},
	{"id": "trophy", "name": "Трофей", "desc": "Поймай рыбу тяжелее 5 кг", "kind": "weight", "need": 5, "silver": 300},
	{"id": "giant", "name": "Гигант", "desc": "Поймай рыбу тяжелее 15 кг", "kind": "weight", "need": 15, "silver": 1000},
	{"id": "species", "name": "Коллекционер", "desc": "Поймай 6 разных видов", "kind": "species", "need": 6, "silver": 500},
]

# ---------- биоритмы и температура ----------
# [пик утро/вечер, день, ночь]
const RHYTHM := {
	"pred": [1.35, 0.55, 0.5],
	"peace": [1.2, 0.7, 0.45],
	"small": [1.1, 1.0, 0.35],
	"night": [1.0, 0.3, 1.45],
}

static func _win(h: float, a: float, b: float, s: float) -> float:
	if h >= a and h <= b:
		return 1.0
	var dd: float = a - h if h < a else h - b
	return clampf(1.0 - dd / s, 0.0, 1.0)

static func rhythm(kind: String, hr: float) -> float:
	var p: Array = RHYTHM[kind]
	var wp: float = maxf(_win(hr, 5.0, 9.0, 1.5), _win(hr, 17.0, 21.0, 1.5))
	var wd: float = _win(hr, 10.5, 15.5, 1.5)
	var wn: float = maxf(_win(hr, 22.5, 24.0, 1.5), _win(hr, 0.0, 3.5, 1.5))
	var tot: float = wp + wd + wn
	if tot <= 0.01:
		return 0.6
	return (wp * float(p[0]) + wd * float(p[1]) + wn * float(p[2])) / tot

# c = [мин, оптимум от, оптимум до, макс] в °C
static func temp_factor(c: Array, t: float) -> float:
	var lo: float = float(c[0])
	var a: float = float(c[1])
	var b: float = float(c[2])
	var hi: float = float(c[3])
	if t <= lo or t >= hi:
		return 0.05
	if t < a:
		return lerpf(0.05, 1.0, (t - lo) / maxf(a - lo, 0.1))
	if t > b:
		return lerpf(1.0, 0.05, (t - b) / maxf(hi - b, 0.1))
	return 1.0
