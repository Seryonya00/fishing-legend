extends RefCounted
# Каталог: рыба, удилища, лески, наживки

const FISH := {
	"roach": {"name": "Плотва", "hook": 0, "min": 0.05, "max": 0.45, "kg_price": 180, "pull": 0.30, "len": 33, "chance": 40, "depth": [0.5, 4.0], "baits": ["worm", "maggot", "bread", "corn"], "col": [0.72, 0.78, 0.82]},
	"perch": {"name": "Окунь", "hook": 1, "min": 0.10, "max": 1.20, "kg_price": 220, "pull": 0.45, "len": 30, "chance": 25, "depth": [1.0, 5.0], "baits": ["worm", "maggot"], "col": [0.45, 0.55, 0.25]},
	"crucian": {"name": "Карась", "hook": 0, "min": 0.10, "max": 1.50, "kg_price": 200, "pull": 0.45, "len": 29, "chance": 25, "depth": [0.3, 2.5], "baits": ["worm", "corn", "bread"], "col": [0.80, 0.65, 0.30]},
	"bream": {"name": "Лещ", "hook": 1, "min": 0.30, "max": 3.50, "kg_price": 260, "pull": 0.45, "len": 36, "chance": 15, "depth": [2.0, 6.0], "baits": ["worm", "maggot", "corn"], "col": [0.65, 0.62, 0.55]},
	"pike": {"name": "Щука", "hook": 2, "min": 0.80, "max": 9.00, "kg_price": 400, "pull": 0.80, "len": 45, "chance": 4, "depth": [1.5, 5.0], "baits": ["worm"], "col": [0.35, 0.5, 0.3]},
	"carp": {"name": "Карп", "hook": 2, "min": 1.00, "max": 15.0, "kg_price": 380, "pull": 0.90, "len": 38, "chance": 5, "depth": [1.5, 6.0], "baits": ["corn", "bread"], "col": [0.75, 0.55, 0.2]},
	"zander": {"name": "Судак", "hook": 2, "min": 0.8, "max": 8.0, "kg_price": 450, "pull": 0.85, "len": 42, "chance": 1, "depth": [3.0, 8.0], "baits": ["worm"], "col": [0.55, 0.60, 0.50]},
	"asp": {"name": "Жерех", "hook": 1, "min": 0.5, "max": 6.0, "kg_price": 380, "pull": 0.95, "len": 40, "chance": 1, "depth": [0.3, 2.5], "baits": ["worm", "maggot"], "col": [0.70, 0.75, 0.80]},
	"chub": {"name": "Голавль", "hook": 1, "min": 0.2, "max": 3.0, "kg_price": 300, "pull": 0.60, "len": 34, "chance": 1, "depth": [0.5, 3.0], "baits": ["worm", "maggot", "bread"], "col": [0.60, 0.50, 0.35]},
}


const LINES := [
	{"name": "Леска 0.20 мм", "kg": 2.0, "price": 0},
	{"name": "Леска 0.28 мм", "kg": 4.5, "price": 250},
	{"name": "Флюорокарбон 0.35 мм", "kg": 8.0, "price": 800},
]

const BAITS := {
	"worm": {"name": "Червь", "price": 30},
	"maggot": {"name": "Опарыш", "price": 40},
	"corn": {"name": "Кукуруза", "price": 50},
	"bread": {"name": "Хлеб", "price": 20},
}

const HOOKS := [
	{"name": "Крючок №14 (мелкий)", "price": 0},
	{"name": "Крючок №10 (средний)", "price": 60},
	{"name": "Крючок №6 (крупный)", "price": 100},
]

const FLOATS := [
	{"name": "Поплавок 1 г", "cap": 1, "price": 0},
	{"name": "Поплавок 2 г", "cap": 2, "price": 80},
	{"name": "Поплавок 4 г", "cap": 4, "price": 150},
]

const FEEDERS := [
	{"name": "Кормушка 20 г", "w": 20, "price": 0},
	{"name": "Кормушка 40 г", "w": 40, "price": 200},
	{"name": "Кормушка 60 г", "w": 60, "price": 350},
]

const SINKERS := [1, 2, 4, 6]

const GB_BASES := {
	"univ": {"name": "Универсальная", "price": 40, "aff": {"roach": 0.4, "perch": 0.2, "crucian": 0.4, "bream": 0.4, "carp": 0.4}},
	"bream": {"name": "Для леща и плотвы", "price": 60, "aff": {"roach": 1.0, "bream": 1.2, "crucian": 0.3}},
	"carp": {"name": "Для карася и карпа", "price": 60, "aff": {"crucian": 1.0, "carp": 1.2, "bream": 0.3}},
}

const GB_FLAVORS := {
	"none": {"name": "без запаха", "price": 0, "aff": {}},
	"vanilla": {"name": "ваниль", "price": 20, "aff": {"crucian": 0.5, "carp": 0.6, "bream": 0.2}},
	"garlic": {"name": "чеснок", "price": 20, "aff": {"bream": 0.5, "roach": 0.4, "pike": 0.2}},
	"anise": {"name": "анис", "price": 20, "aff": {"roach": 0.6, "perch": 0.3, "bream": 0.2}},
}

const GB_ADDS := {
	"none": {"name": "без добавок", "price": 0, "aff": {}},
	"corn": {"name": "кукуруза", "price": 15, "aff": {"carp": 0.8, "crucian": 0.4}},
	"worm": {"name": "рубленый червь", "price": 15, "aff": {"perch": 0.9, "bream": 0.4, "pike": 0.2}},
}

# Во сколько раз прикормка повышает шанс данной рыбы (1.0 = без эффекта)
static func gb_effect(fish_id: String, mix: Dictionary) -> float:
	if mix.is_empty():
		return 1.0
	var e := 1.0
	e += float(GB_BASES[mix["base"]]["aff"].get(fish_id, 0.0))
	e += float(GB_FLAVORS[mix["flavor"]]["aff"].get(fish_id, 0.0))
	e += float(GB_ADDS[mix["add"]]["aff"].get(fish_id, 0.0))
	return e

# Удилища по классам. kg — «тест» (макс. нагрузка), range — дальность заброса, cast — вес заброса (г)
const ROD_CLASSES := {
	"float": [
		{"name": "Бамбуковая удочка 3 м", "range": 10.0, "kg": 1.5, "reel": 0.0, "cast": 10, "price": 0},
		{"name": "Карбон «Поплавок» 4 м", "range": 14.0, "kg": 3.0, "reel": 0.0, "cast": 12, "price": 350},
		{"name": "Телескоп «Мастер» 5 м", "range": 18.0, "kg": 5.0, "reel": 0.0, "cast": 15, "price": 1100},
	],
	"feeder": [
		{"name": "Фидер «Старт» 3.3 м", "range": 22.0, "kg": 2.5, "reel": 1.0, "cast": 40, "price": 250},
		{"name": "Фидер «Классик» 3.6 м", "range": 30.0, "kg": 4.0, "reel": 1.2, "cast": 70, "price": 900},
		{"name": "Фидер «Про» 3.9 м", "range": 38.0, "kg": 6.0, "reel": 1.4, "cast": 110, "price": 2200},
	],
	"spin": [
		{"name": "Спиннинг «Старт» 2.1 м", "range": 24.0, "kg": 2.0, "reel": 1.0, "cast": 15, "price": 250},
		{"name": "Спиннинг «Классик» 2.4 м", "range": 32.0, "kg": 3.5, "reel": 1.2, "cast": 30, "price": 900},
		{"name": "Спиннинг «Про» 2.7 м", "range": 40.0, "kg": 6.0, "reel": 1.4, "cast": 50, "price": 2200},
	],
}

const CLASS_NAMES := {"float": "Поплавочная", "feeder": "Фидер", "spin": "Спиннинг"}
const CLASS_ORDER := ["float", "feeder", "spin"]

# Приманки для спиннинга: depth — рабочая глубина, speed — скорость проводки (м/с), size — крупность
const LURES := [
	{"name": "Блесна-вертушка №2", "depth": [0.5, 3.0], "speed": [0.8, 2.5], "size": 0, "price": 0},
	{"name": "Воблер «Минноу»", "depth": [0.5, 2.0], "speed": [0.6, 2.0], "size": 1, "price": 150},
	{"name": "Джиг-силикон", "depth": [2.0, 8.0], "speed": [0.4, 1.4], "size": 2, "price": 120},
]

const LURE_AFF := {"pike": 1.0, "zander": 0.9, "asp": 0.95, "perch": 0.8, "chub": 0.3, "roach": 0.05, "bream": 0.02, "crucian": 0.02, "carp": 0.02}

# Локации
const LOCS := {
	"pond": {"name": "Пруд", "lvl": 1, "kind": "pond", "center": Vector2(0, -45), "r": 30.0, "depth": 3.5, "x0": -80.0, "x1": 80.0, "z0": -110.0, "z1": 50.0, "cell": 2.0, "pier": [0.0, -6.5, -21.0], "trees": 80, "flow": Vector2(0, 0), "fish": {"roach": 40, "crucian": 40, "perch": 15, "carp": 6, "pike": 2}},
	"lake": {"name": "Озеро", "lvl": 3, "kind": "lake", "center": Vector2(0, -90), "r": 60.0, "depth": 8.0, "x0": -140.0, "x1": 140.0, "z0": -210.0, "z1": 50.0, "cell": 3.2, "pier": [0.0, -8.0, -38.0], "trees": 120, "flow": Vector2(0, 0), "fish": {"roach": 30, "perch": 25, "bream": 25, "pike": 8, "carp": 8, "zander": 5}},
	"river": {"name": "Река", "lvl": 5, "kind": "river", "center": Vector2(0, -50), "r": 13.0, "depth": 3.5, "x0": -120.0, "x1": 120.0, "z0": -130.0, "z1": 50.0, "cell": 2.4, "pier": [0.0, -30.0, -44.0], "trees": 100, "flow": Vector2(0.7, 0), "fish": {"roach": 20, "chub": 25, "asp": 12, "perch": 15, "bream": 12, "pike": 5, "zander": 8}},
}

static func cur_rod() -> Dictionary:
	var t: String = str(State.rig["type"])
	var i: int = int(State.rods.get(t, -1))
	if i < 0:
		return {}
	return ROD_CLASSES[t][i]

static func rod_of(c: Dictionary) -> Dictionary:
	var t: String = str(c["type"])
	var i: int = int(State.rods.get(t, -1))
	if i < 0:
		return {}
	return ROD_CLASSES[t][i]

# Сигнализаторы поклёвки для фидера
const SIGNALS := [
	{"name": "Колокольчик", "price": 0},
	{"name": "Электронный сигнализатор", "price": 350},
]

# Подставки (рогатки): слот 2 и 3
const STAND_PRICES := [0, 150, 250]
