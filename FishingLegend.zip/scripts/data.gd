extends RefCounted
# Каталог: рыба, удилища, лески, наживки

const FISH := {
	"roach": {"name": "Плотва", "min": 0.05, "max": 0.45, "kg_price": 180, "pull": 0.30, "len": 33, "chance": 40, "depth": [0.5, 4.0], "baits": ["worm", "maggot", "bread", "corn"], "col": [0.72, 0.78, 0.82]},
	"perch": {"name": "Окунь", "min": 0.10, "max": 1.20, "kg_price": 220, "pull": 0.45, "len": 30, "chance": 25, "depth": [1.0, 5.0], "baits": ["worm", "maggot"], "col": [0.45, 0.55, 0.25]},
	"crucian": {"name": "Карась", "min": 0.10, "max": 1.50, "kg_price": 200, "pull": 0.45, "len": 29, "chance": 25, "depth": [0.3, 2.5], "baits": ["worm", "corn", "bread"], "col": [0.80, 0.65, 0.30]},
	"bream": {"name": "Лещ", "min": 0.30, "max": 3.50, "kg_price": 260, "pull": 0.45, "len": 36, "chance": 15, "depth": [2.0, 6.0], "baits": ["worm", "maggot", "corn"], "col": [0.65, 0.62, 0.55]},
	"pike": {"name": "Щука", "min": 0.80, "max": 9.00, "kg_price": 400, "pull": 0.80, "len": 45, "chance": 4, "depth": [1.5, 5.0], "baits": ["worm"], "col": [0.35, 0.5, 0.3]},
	"carp": {"name": "Карп", "min": 1.00, "max": 15.0, "kg_price": 380, "pull": 0.90, "len": 38, "chance": 5, "depth": [1.5, 6.0], "baits": ["corn", "bread"], "col": [0.75, 0.55, 0.2]},
}

const RODS := [
	{"name": "Бамбуковая удочка 3 м", "range": 14.0, "kg": 1.5, "reel": 1.6, "price": 0},
	{"name": "Карбон «Ловец» 4 м", "range": 22.0, "kg": 3.0, "reel": 2.2, "price": 450},
	{"name": "Телескоп «Профи» 5 м", "range": 32.0, "kg": 5.0, "reel": 3.0, "price": 1500},
]

const LINES := [
	{"name": "Леска 0.20 мм", "kg": 2.0, "price": 0},
	{"name": "Леска 0.28 мм", "kg": 4.5, "price": 250},
	{"name": "Флюорокарбон 0.35 мм", "kg": 8.0, "price": 800},
]

const BAITS := {
	"worm": {"name": "Червь", "price": 30},
	"maggot": {"name": "Опарыш", "price": 40},
	"corn": {"name": "Кукуруза", "price": 50},
	"bread": {"name": "Хлеб", "price": 20},
}
