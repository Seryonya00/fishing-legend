extends Control
# Подводный фон: градиент, лучи света, пузыри, водоросли

var _bubbles: Array = []
var _t: float = 0.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP

func _ready() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4
	for i in 28:
		_bubbles.append({"x": rng.randf(), "y": rng.randf(), "r": rng.randf_range(3.0, 12.0), "s": rng.randf_range(0.02, 0.06)})

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_t += delta
	for b in _bubbles:
		b["y"] = float(b["y"]) - float(b["s"]) * delta
		if float(b["y"]) < -0.05:
			b["y"] = 1.05
			b["x"] = randf()
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	var top := Color(0.1, 0.22, 0.34)
	var bot := Color(0.02, 0.06, 0.12)
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)]), PackedColorArray([top, top, bot, bot]))
	for i in 5:
		var x := w * (0.08 + 0.2 * float(i)) + sin(_t * 0.3 + float(i)) * 30.0
		draw_colored_polygon(PackedVector2Array([Vector2(x, 0), Vector2(x + 70, 0), Vector2(x + 260, h), Vector2(x + 110, h)]), Color(0.5, 0.8, 1.0, 0.035))
	for i in 9:
		var bx := w * (float(i) / 8.0)
		var sway := sin(_t * 0.8 + float(i) * 1.7) * 14.0
		draw_colored_polygon(PackedVector2Array([Vector2(bx - 12, h), Vector2(bx + sway, h - 110 - float(i % 3) * 30.0), Vector2(bx + 12, h)]), Color(0.04, 0.2, 0.17, 0.55))
	for b in _bubbles:
		var p := Vector2(float(b["x"]) * w, float(b["y"]) * h)
		draw_circle(p, float(b["r"]), Color(0.7, 0.9, 1, 0.06))
		draw_arc(p, float(b["r"]), 0.0, TAU, 20, Color(0.7, 0.9, 1, 0.35), 1.5, true)
