extends Node
# ИИ рыбы. Стаи плавают по водоёму с учётом глубины, дна и «структуры» (коряги, бровки, заросли),
# подтягиваются к прикормке и клюют по формуле: время суток, погода, температура воды,
# давление, ветер, наживка, крючок, расстояние до стаи, голод.

const Data = preload("res://scripts/data.gd")
const BASE := 0.045
const BASE_L := 0.06
const ATTRACT_R := 28.0

var world
var schools: Array = []
var _acc: float = 0.0
var _rng := RandomNumberGenerator.new()

func rebuild() -> void:
	schools = []
	_rng.randomize()
	var lf: Dictionary = world.loc_fish
	for id in lf:
		var cnt: int = clampi(int(round(float(lf[id]) / 3.0)) + 1, 1, 14)
		for i in cnt:
			var s: Dictionary = _new_school(str(id))
			if not s.is_empty():
				schools.append(s)

func _new_school(id: String) -> Dictionary:
	var x0: float = float(world.loc["x0"]) + 20.0
	var x1: float = float(world.loc["x1"]) - 20.0
	var z0: float = float(world.loc["z0"]) + 20.0
	var z1: float = float(world.loc["z1"]) - 20.0
	var best := Vector2.ZERO
	var bs := -1.0
	for i in 40:
		var p := Vector2(_rng.randf_range(x0, x1), _rng.randf_range(z0, z1))
		var h: float = _habitat(id, p)
		if h > bs:
			bs = h
			best = p
	if bs < 0.25:
		return {}
	var kind: String = str(Data.FISH[id]["kind"])
	var n: int = _rng.randi_range(1, 2) if (kind == "pred" or kind == "night") else _rng.randi_range(2, 6)
	return {"id": id, "n": n, "pos": best, "tgt": best, "spd": _rng.randf_range(0.5, 1.1), "hunger": _rng.randf_range(0.3, 0.9), "wt": _rng.randf(), "t": _rng.randf_range(3.0, 15.0)}

# Пригодность точки для вида: глубина, дно, структура (хищники держатся у коряг, бровок, зарослей)
func _habitat(id: String, p: Vector2) -> float:
	var fd: Dictionary = Data.FISH[id]
	var d: float = -float(world.ground_at(p.x, p.y))
	if d < 0.35:
		return 0.0
	var dr: Array = fd["depth"]
	var s := 1.0
	if d < float(dr[0]):
		s = clampf(1.0 - (float(dr[0]) - d) / 2.0, 0.0, 1.0)
	elif d > float(dr[1]):
		s = clampf(1.0 - (d - float(dr[1])) / 3.0, 0.0, 1.0)
	var bt: String = str(world.bottom_at(p.x, p.y))
	s *= 1.0 if bt in fd["bottom"] else 0.5
	if bool(fd["struct"]):
		var st := 0.0
		if world.snag_at(p.x, p.y):
			st = 1.0
		elif float(world.edge_at(p.x, p.y)) > 0.17:
			st = 0.8
		elif bt == "grass":
			st = 0.7
		s *= 0.4 + 0.6 * st
	return s

func _pick_target(id: String, pos: Vector2, act: float) -> Vector2:
	var r: float = 8.0 + 16.0 * clampf(act, 0.0, 1.2)
	var best := pos
	var bs := -1.0
	for i in 6:
		var p := pos + Vector2(_rng.randf_range(-r, r), _rng.randf_range(-r, r))
		var h: float = _habitat(id, p)
		if h > bs:
			bs = h
			best = p
	return best

func tick(delta: float) -> void:
	_acc += delta
	if _acc < 0.5:
		return
	var dt: float = _acc
	_acc = 0.0
	var spot_on: bool = world.spot_left > 0.0
	for s in schools:
		var id: String = str(s["id"])
		var act: float = world.fish_activity(id)
		s["hunger"] = clampf(float(s["hunger"]) + dt * 0.004 * act, 0.0, 1.0)
		var pos: Vector2 = s["pos"]
		var held := false
		if spot_on:
			var aff: float = Data.gb_effect(id, world.spot_mix) - 1.0
			if aff > 0.25 and pos.distance_to(world.spot_pos) < ATTRACT_R * clampf(aff, 0.3, 1.5):
				s["tgt"] = world.spot_pos + Vector2(_rng.randf_range(-3.0, 3.0), _rng.randf_range(-3.0, 3.0))
				held = true
		s["t"] = float(s["t"]) - dt
		if not held and float(s["t"]) <= 0.0:
			s["t"] = _rng.randf_range(8.0, 25.0)
			s["tgt"] = _pick_target(id, pos, act)
		var tgt: Vector2 = s["tgt"]
		var dv: Vector2 = tgt - pos
		if dv.length() > 0.5:
			var sp: float = float(s["spd"]) * (0.4 + 0.6 * clampf(act, 0.0, 1.2))
			var np: Vector2 = pos + dv.normalized() * minf(dv.length(), sp * dt)
			if float(world.ground_at(np.x, np.y)) < -0.35:
				s["pos"] = np
			else:
				s["t"] = 0.0

func _choose(weights: Array, total: float) -> int:
	var x: float = randf() * total
	for w in weights:
		x -= float(w[1])
		if x <= 0.0:
			return int(w[0])
	return int(weights[weights.size() - 1][0]) if weights.size() > 0 else -1

# Скорость поклёвок (1/с) для наживки у точки p
func query_bait(p: Vector2, rd: float, bait: String, hook: int, on_bottom: bool) -> Dictionary:
	var bt: String = str(world.bottom_at(p.x, p.y))
	var spot_here: bool = world.spot_left > 0.0 and p.distance_to(world.spot_pos) < 6.0
	var rad: float = 8.0 + (4.0 if spot_here else 0.0)
	var weights: Array = []
	var total := 0.0
	for i in schools.size():
		var s: Dictionary = schools[i]
		var d: float = (s["pos"] as Vector2).distance_to(p)
		if d > rad:
			continue
		var id: String = str(s["id"])
		var fd: Dictionary = Data.FISH[id]
		var dr: Array = fd["depth"]
		var m_d: float = 1.0 if (rd >= float(dr[0]) and rd <= float(dr[1])) else 0.2
		var m_b: float = 0.8
		if on_bottom:
			m_b = 1.0 if bt in fd["bottom"] else 0.5
		var m_bait: float = 1.0 if bait in fd["baits"] else 0.1
		var m_h: float = [1.0, 0.5, 0.12][absi(hook - int(fd["hook"]))]
		var gbf: float = Data.gb_effect(id, world.spot_mix) if spot_here else 1.0
		var r: float = BASE * sqrt(float(s["n"])) * (1.0 - d / rad) * m_d * m_b * m_bait * m_h * float(world.fish_activity(id)) * (0.3 + 0.7 * float(s["hunger"])) * gbf
		if r > 0.0:
			weights.append([i, r])
			total += r
	return {"rate": total, "school": _choose(weights, total)}

# Скорость ударов хищников по приманке (воблер, блесна, джиг)
func query_lure(p: Vector2, ld: float, speed: float, lure: Dictionary) -> Dictionary:
	var weights: Array = []
	var total := 0.0
	var lr: Array = lure["depth"]
	var ls: Array = lure["speed"]
	for i in schools.size():
		var s: Dictionary = schools[i]
		var id: String = str(s["id"])
		var aff: float = float(Data.LURE_AFF.get(id, 0.02))
		if aff < 0.1:
			continue
		var d: float = (s["pos"] as Vector2).distance_to(p)
		if d > 10.0:
			continue
		var fd: Dictionary = Data.FISH[id]
		var fr: Array = fd["depth"]
		var m_f: float = 1.0 if (ld >= float(fr[0]) and ld <= float(fr[1])) else 0.3
		var m_l: float = 1.0 if (ld >= float(lr[0]) and ld <= float(lr[1])) else 0.3
		var m_s: float = 1.0 if (speed >= float(ls[0]) and speed <= float(ls[1])) else 0.4
		var r: float = BASE_L * aff * (1.0 - d / 10.0) * m_f * m_l * m_s * float(world.fish_activity(id)) * (0.3 + 0.7 * float(s["hunger"])) * (1.0 + 0.2 * float(s["n"]))
		weights.append([i, r])
		total += r
	return {"rate": total, "school": _choose(weights, total)}

# Рыба из стаи (вес зависит от крупности крючка/приманки, «характера» стаи и ночных трофеев)
func take_fish(si: int, hook: int, lure: bool, size_idx: int) -> Dictionary:
	if si < 0 or si >= schools.size():
		return {}
	var s: Dictionary = schools[si]
	var id: String = str(s["id"])
	var fd: Dictionary = Data.FISH[id]
	var expo: float = [3.5, 2.5, 1.8][clampi(hook, 0, 2)]
	if lure:
		expo = [3.0, 2.4, 1.9][clampi(size_idx, 0, 2)]
	var bias: float = float(s["wt"]) * 0.7
	var kind: String = str(fd["kind"])
	var hr: float = world.hour
	if (kind == "peace" or kind == "night") and (hr > 22.5 or hr < 3.5):
		bias += 0.4
	var e: float = maxf(0.6, expo * (1.0 - 0.5 * clampf(bias, 0.0, 1.0)))
	var wt: float = lerpf(float(fd["min"]), float(fd["max"]), pow(randf(), e))
	return {"id": id, "w": snappedf(wt, 0.01)}

func fed(si: int, amount: float) -> void:
	if si >= 0 and si < schools.size():
		schools[si]["hunger"] = clampf(float(schools[si]["hunger"]) - amount, 0.0, 1.0)

func remove_one(si: int) -> void:
	if si < 0 or si >= schools.size():
		return
	var s: Dictionary = schools[si]
	s["n"] = int(s["n"]) - 1
	s["hunger"] = clampf(float(s["hunger"]) - 0.2, 0.0, 1.0)
	if int(s["n"]) <= 0:
		var ns: Dictionary = _new_school(str(s["id"]))
		if ns.is_empty():
			s["n"] = 1
		else:
			schools[si] = ns
