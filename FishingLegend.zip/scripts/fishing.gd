extends Node3D
# Один комплект удилища (слот). Видов ловли три:
#  float  — поплавок: видишь, как он клюёт/уходит под воду, сам решаешь, когда подсекать
#  feeder — фидер на подставке: дрожит кончик (колокольчик/сигнализатор), потом резкий изгиб — берёшь удилище и подсекаешь
#  spin   — спиннинг: проводка колесом, удар хищника, подсечка
# Вываживание: колесо против часовой = выбирать, по часовой = травить, ПОДНЯТЬ = подтянуть рыбу (помпинг).

const Data = preload("res://scripts/data.gd")

const IDLE := 0
const CHARGE := 1
const FLY := 2
const WAIT := 3
const BITE := 4
const FIGHT := 5
const RETRIEVE := 6
const SPIN := 7
const NIBBLE := 8

signal msg(text: String)
signal caught(fish: Dictionary)

var slot: int = 0
var held: bool = false
var state: int = IDLE
var power: float = 0.0
var tension: float = 0.0
var dist: float = 0.0
var depth: float = 1.0
var rush: bool = false
var pump: bool = false
var alert: int = 0
var reel_vel: float = 0.0
var world
var audio
var cam: Camera3D
var pivot: Node3D
var hand_tip: Node3D
var hooked: Dictionary = {}

var _pdir: float = 1.0
var _float: MeshInstance3D
var _float_mat: StandardMaterial3D
var _line: MeshInstance3D
var _ring: MeshInstance3D
var _ring_mat: StandardMaterial3D
var _stand_root: Node3D
var _sp: Node3D
var _stand_tip: Node3D
var _o: Vector3 = Vector3.ZERO
var _dir: Vector3 = Vector3.FORWARD
var _target: Vector3 = Vector3.ZERO
var _from: Vector3 = Vector3.ZERO
var _wpos: Vector3 = Vector3.ZERO
var _fpos: Vector3 = Vector3.ZERO
var _fly_t: float = 0.0
var _wait_t: float = 0.0
var _seq_t: float = 0.0
var _win_t: float = 0.0
var _win_len: float = 1.4
var _take_at: float = 3.0
var _trem: float = 4.0
var _false: bool = false
var _style: String = "dip"
var _nibs: Array = []
var _nib_i: int = 0
var _bell_t: float = 0.5
var _stamina: float = 1.0
var _phase: float = 0.0
var _over: float = 0.0
var _slack: float = 0.0
var _time: float = 0.0
var _ring_t: float = 1.0
var _ring_next: float = 2.0
var _run_side: float = 1.0
var _lure_depth: float = 0.5
var _cd: float = 0.0
var _auto_retrieve: bool = false
var _spin_bite: bool = false
var _click_acc: float = 0.0
var _lift_t: float = 0.0
var _haptic: float = 0.0
var _last_wake: int = 0

func _ready() -> void:
	_float = MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.03
	cap.height = 0.2
	_float.mesh = cap
	_float_mat = StandardMaterial3D.new()
	_float_mat.albedo_color = Color(0.95, 0.15, 0.1)
	_float.material_override = _float_mat
	_float.top_level = true
	_float.visible = false
	add_child(_float)

	_line = MeshInstance3D.new()
	_line.mesh = ImmediateMesh.new()
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(1, 1, 1, 0.8)
	lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_line.material_override = lm
	_line.top_level = true
	_line.visible = false
	add_child(_line)

	_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.9
	tm.outer_radius = 1.0
	_ring.mesh = tm
	_ring_mat = StandardMaterial3D.new()
	_ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ring_mat.albedo_color = Color(1, 1, 1, 0.5)
	_ring.material_override = _ring_mat
	_ring.top_level = true
	_ring.visible = false
	add_child(_ring)

	# удилище на подставке (рогатке)
	_stand_root = Node3D.new()
	_stand_root.top_level = true
	_stand_root.visible = false
	add_child(_stand_root)
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.3, 0.22, 0.12)
	var post := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.02
	pm.bottom_radius = 0.025
	pm.height = 0.8
	post.mesh = pm
	post.material_override = wood
	post.position = Vector3(0, 0.4, 0)
	_stand_root.add_child(post)
	_sp = Node3D.new()
	_sp.position = Vector3(0, 0.75, 0)
	_sp.rotation_degrees = Vector3(-62, 0, 0)
	_stand_root.add_child(_sp)
	var rm := MeshInstance3D.new()
	var rc := CylinderMesh.new()
	rc.top_radius = 0.004
	rc.bottom_radius = 0.014
	rc.height = 3.0
	rc.radial_segments = 6
	rm.mesh = rc
	var rmat := StandardMaterial3D.new()
	rmat.albedo_color = Color(0.1, 0.1, 0.1)
	rm.material_override = rmat
	rm.position = Vector3(0, 1.5, 0)
	_sp.add_child(rm)
	_stand_tip = Node3D.new()
	_stand_tip.position = Vector3(0, 3.0, 0)
	_sp.add_child(_stand_tip)
	var bell := MeshInstance3D.new()
	var bs := SphereMesh.new()
	bs.radius = 0.03
	bs.height = 0.06
	bell.mesh = bs
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.9, 0.75, 0.2)
	bell.material_override = bmat
	bell.position = Vector3(0, -0.05, 0)
	_stand_tip.add_child(bell)

# ---------- вспомогательное ----------

func cfg() -> Dictionary:
	return State.slots[slot]

func rtype() -> String:
	return str(cfg()["type"])

func _rod() -> Dictionary:
	return Data.rod_of(cfg())

func _limit() -> float:
	return minf(float(Data.LINES[State.line]["kg"]), float(_rod()["kg"]))

func _k() -> float:
	return 0.2 * float(_rod()["reel"])

func _say(text: String) -> void:
	msg.emit(text)

func _sfx(name: String, vol: float = -12.0, pitch: float = 1.0) -> void:
	if audio != null:
		audio.play(name, vol, pitch)

func _origin() -> Vector3:
	if held:
		return Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	return _o

func _tip_pos() -> Vector3:
	return hand_tip.global_position if held else _stand_tip.global_position

func _rig_depth() -> float:
	if rtype() == "feeder":
		return depth
	return minf(float(cfg()["fdepth"]), depth)

func _in_spot() -> bool:
	return world.spot_left > 0.0 and Vector2(_wpos.x, _wpos.z).distance_to(world.spot_pos) < 6.0

func is_waiting() -> bool:
	return state == WAIT or state == NIBBLE or state == BITE

# ---------- взять в руки / поставить на подставку ----------

func take() -> void:
	held = true
	_stand_root.visible = false

func hide_rod() -> void:
	held = false
	_stand_root.visible = false

func place_on_stand(pos: Vector3) -> void:
	_o = Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	held = false
	_stand_root.global_position = pos
	var d := Vector3(_wpos.x - pos.x, 0.0, _wpos.z - pos.z)
	if d.length() < 0.5:
		d = -cam.global_transform.basis.z
	_stand_root.rotation = Vector3(0, atan2(-d.x, -d.z), 0)
	_stand_root.visible = true

# ---------- действия игрока ----------

func press_cast() -> void:
	if state != IDLE or not held:
		return
	var rod := _rod()
	if rod.is_empty():
		_say("Нет удилища этого типа — купите в магазине")
		return
	var t := rtype()
	if t == "spin":
		if not State.owned.has("lure%d" % State.lure):
			_say("Выберите приманку в меню «Снасть»")
			return
	elif int(State.baits.get(State.bait, 0)) <= 0:
		_say("Нет наживки — купите в магазине")
		return
	if t == "feeder" and int(Data.FEEDERS[int(cfg()["feeder"])]["w"]) > int(rod["cast"]):
		_say("Кормушка слишком тяжёлая для этого удилища")
		return
	state = CHARGE
	power = 0.0
	_pdir = 1.0

func release_cast() -> void:
	if state != CHARGE:
		return
	var rod := _rod()
	var t := rtype()
	var f: Vector3 = -cam.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var d: float = float(rod["range"]) * (0.25 + 0.75 * power)
	var o := _origin()
	_from = hand_tip.global_position
	_dir = f
	_target = o + f * d
	_fly_t = 0.0
	_float_mat.albedo_color = Color(0.85, 0.88, 0.92) if t == "spin" else Color(0.95, 0.15, 0.1)
	_float.scale = Vector3.ONE * (0.6 if t == "spin" else 1.0)
	_lift_t = 0.4
	_sfx("swish")
	state = FLY

func strike() -> void:
	if not held:
		return
	var t := rtype()
	match state:
		BITE:
			if t == "float" and _style == "dip" and _win_t < 0.25 and randf() < 0.3:
				_empty_strike()
			else:
				_hooked_up()
		NIBBLE:
			if (not _false) and randf() < 0.25:
				_hooked_up()
			else:
				_empty_strike()
		WAIT:
			_empty_strike()

func _empty_strike() -> void:
	_lift_t = 0.4
	_sfx("swish", -16.0, 1.2)
	_say("Пустая подсечка")
	hooked = {}
	alert = 0
	_auto_retrieve = rtype() == "float"
	state = RETRIEVE

func _hooked_up() -> void:
	_lift_t = 0.4
	_sfx("swish", -14.0, 1.2)
	alert = 0
	if rtype() == "float":
		var w: float = float(hooked["w"])
		if w > _limit() * 1.6:
			_say("Снасть не выдержала — рыба сорвалась")
			_sfx("snap")
			_reset()
		else:
			_sfx("splash", -12.0)
			_catch()
		return
	state = FIGHT
	_stamina = 1.0
	rush = true
	_phase = randf_range(1.0, 1.8)
	tension = 0.3
	_over = 0.0
	_slack = 0.0
	_say("Рыба на крючке! Колесо против часовой — выбирать, по часовой — травить")

func throw_groundbait() -> void:
	if state != IDLE or not held or rtype() == "spin":
		return
	if State.gb_portions <= 0:
		_say("Нет прикормки — замесите в меню «Снасть»")
		return
	var rod := _rod()
	if rod.is_empty():
		return
	var f: Vector3 = -cam.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var t := _origin() + f * (float(rod["range"]) * 0.6)
	if world.height_at(t.x, t.z) > -0.3:
		_say("Прикормку нужно бросать в воду")
		return
	State.gb_portions -= 1
	world.add_spot(Vector2(t.x, t.z), State.gb_mix.duplicate())
	_sfx("plop", -16.0)
	_say("Прикормка заброшена (≈5 минут)")

# ---------- основной цикл ----------

func _process(delta: float) -> void:
	_time += delta
	var o := _origin()
	var rin: float = maxf(reel_vel, 0.0)
	_haptic = maxf(0.0, _haptic - delta)
	match state:
		CHARGE:
			power += _pdir * delta * 0.9
			if power >= 1.0:
				power = 1.0
				_pdir = -1.0
			elif power <= 0.0:
				power = 0.0
				_pdir = 1.0
		FLY:
			_fly_t += delta / 0.9
			var t := minf(_fly_t, 1.0)
			_fpos = _from.lerp(Vector3(_target.x, 0.0, _target.z), t)
			_fpos.y += sin(PI * t) * (1.5 + _from.distance_to(_target) * 0.1)
			if _fly_t >= 1.0:
				_land(o)
		WAIT:
			_fpos = _wpos
			_sync_from_wpos(o)
			if held and rtype() != "float" and rin > 1.5:
				_auto_retrieve = false
				state = RETRIEVE
			_wait_t -= delta
			if _wait_t <= 0.0:
				_begin_seq()
		NIBBLE:
			_fpos = _wpos
			_sync_from_wpos(o)
			_seq_t += delta
			_nibble_tick(delta)
		BITE:
			_fpos = _wpos
			_sync_from_wpos(o)
			_win_t += delta
			if _win_t >= _win_len:
				hooked = {}
				alert = 0
				if _spin_bite:
					state = SPIN
					_cd = 2.0
				else:
					state = WAIT
					_wait_t = _wait_time() * 1.2
		FIGHT:
			_fight(delta, o)
		RETRIEVE:
			if _auto_retrieve:
				dist -= 9.0 * delta
			else:
				dist -= rin * _k() * delta
			_fpos = o + _dir * dist
			_wpos = _fpos
			if dist <= 1.8:
				_reset()
		SPIN:
			_spin(delta, o, rin)
	_click_acc += absf(reel_vel) * delta
	if _click_acc >= 1.2:
		_click_acc = 0.0
		if held and (state == RETRIEVE or state == SPIN or state == FIGHT):
			_sfx("click", -22.0, randf_range(0.95, 1.05))
	if audio != null and held:
		audio.set_drag(clampf(maxf(-reel_vel, 0.0) / 6.0, 0.0, 1.0) if state == FIGHT else 0.0)
	_rod_pose(delta)
	_visuals(delta)

func _sync_from_wpos(o: Vector3) -> void:
	var d := Vector3(_wpos.x - o.x, 0.0, _wpos.z - o.z)
	dist = d.length()
	if dist > 0.01:
		_dir = d / dist

func _land(o: Vector3) -> void:
	var h: float = world.height_at(_target.x, _target.z)
	if h > -0.3:
		_say("Закиньте в воду")
		_reset()
		return
	depth = -h
	_wpos = Vector3(_target.x, 0.0, _target.z)
	_fpos = _wpos
	_sync_from_wpos(o)
	_ring_t = 0.0
	_sfx("plop", -10.0)
	var t := rtype()
	if t == "spin":
		_lure_depth = 0.3
		_cd = 2.5
		_spin_bite = false
		state = SPIN
		return
	State.baits[State.bait] = int(State.baits.get(State.bait, 0)) - 1
	var flat := false
	if t == "feeder":
		if State.gb_portions > 0:
			State.gb_portions -= 1
			world.add_spot(Vector2(_wpos.x, _wpos.z), State.gb_mix.duplicate())
	elif float(cfg()["fdepth"]) > depth + 0.3:
		flat = true
		_say("Поплавок лёг — уменьши глубину в меню «Снасть»")
	state = WAIT
	_wait_t = _wait_time() * (2.0 if flat else 1.0)

# ---------- аппетит рыбы: ожидание поклёвки ----------

func _weights(lure: bool) -> Dictionary:
	var c := cfg()
	var rd: float = _lure_depth if lure else _rig_depth()
	var hook: int = int(c["hook"])
	var mix: Dictionary = world.spot_mix if (_in_spot() and not lure) else {}
	var loc_fish: Dictionary = world.loc_fish
	var ws := {}
	var total := 0.0
	var cap := 0.0
	for id in Data.FISH:
		var fd: Dictionary = Data.FISH[id]
		var base: float = float(loc_fish.get(id, 0.0))
		if base <= 0.0:
			continue
		cap += base
		var w: float = base
		if lure:
			w *= float(Data.LURE_AFF.get(id, 0.02))
		else:
			w *= 1.0 if (State.bait in fd["baits"]) else 0.12
			w *= [1.0, 0.5, 0.12][absi(hook - int(fd["hook"]))]
			w *= Data.gb_effect(id, mix)
		var dr: Array = fd["depth"]
		w *= 1.0 if (rd >= float(dr[0]) and rd <= float(dr[1])) else 0.25
		ws[id] = w
		total += w
	return {"ws": ws, "total": total, "cap": maxf(cap, 0.001)}

func _wait_time() -> float:
	var r := _weights(false)
	var q: float = clampf(float(r["total"]) / float(r["cap"]), 0.0, 1.0)
	var factor: float = float(world.appetite()) * (0.15 + 0.85 * q) * float(world.bite_mod()) * (1.6 if _in_spot() else 1.0)
	factor = clampf(factor, 0.04, 2.0)
	var mean: float = 55.0 / factor
	return clampf(-log(maxf(randf(), 0.001)) * mean, 8.0, 900.0)

func _style_for(id: String) -> String:
	match id:
		"bream":
			return "lift"
		"carp":
			return "sink"
		"pike", "zander", "asp":
			return "run"
	return "dip"

func _begin_seq() -> void:
	hooked = _pick_fish(false)
	_seq_t = 0.0
	_false = randf() < 0.3
	_nibs = []
	_nib_i = 0
	if rtype() == "float":
		var tt := randf_range(0.6, 1.5)
		for i in randi_range(2, 5):
			_nibs.append(tt)
			tt += randf_range(0.4, 1.3)
		_take_at = tt + randf_range(0.2, 0.8)
		_style = _style_for(str(hooked["id"]))
		_win_len = {"dip": 1.4, "lift": 1.3, "sink": 1.8, "run": 1.0}[_style]
	else:
		_trem = randf_range(3.0, 9.0)
		_take_at = _trem + randf_range(0.6, 2.0)
		_win_len = 7.0
		_bell_t = 0.3
	state = NIBBLE

func _signal_on() -> bool:
	return rtype() == "feeder" and int(cfg()["sig"]) >= 0

func _nibble_tick(delta: float) -> void:
	var feeder := rtype() == "feeder"
	if not feeder:
		while _nib_i < _nibs.size() and _seq_t >= float(_nibs[_nib_i]):
			_nib_i += 1
			_ring_t = 0.0
	else:
		alert = 1 if _signal_on() else 0
		if _seq_t < _trem:
			_bell_t -= delta
			if _bell_t <= 0.0:
				_bell_t = randf_range(0.5, 1.5)
				_signal_sound(false)
	if _seq_t >= _take_at:
		if _false:
			hooked = {}
			alert = 0
			state = WAIT
			_wait_t = _wait_time() * 0.7
		else:
			state = BITE
			_win_t = 0.0
			_spin_bite = false
			if feeder:
				alert = 2 if _signal_on() else 0
				_signal_sound(true)

func _signal_sound(strong: bool) -> void:
	if not _signal_on():
		return
	if int(cfg()["sig"]) == 0:
		_sfx("rattle" if strong else "bell", -13.0 if strong else -17.0, randf_range(0.95, 1.08))
	else:
		_sfx("beep", -15.0)
		if strong:
			_sfx("beep", -15.0, 1.3)

func _spin(delta: float, o: Vector3, rin: float) -> void:
	var v: float = rin * _k()
	dist -= v * delta
	_fpos = o + _dir * dist
	_wpos = _fpos
	var tgt: float = lerpf(maxf(depth * 0.9, 0.4), 0.3, clampf(v / 1.6, 0.0, 1.0))
	_lure_depth = move_toward(_lure_depth, tgt, 0.8 * delta)
	_cd -= delta
	var wake := int(Time.get_ticks_msec() / 700.0)
	if v > 0.15 and wake != _last_wake:
		_last_wake = wake
		_ring_t = 0.0
	if _cd <= 0.0 and v > 0.15:
		var L: Dictionary = Data.LURES[State.lure]
		var dr: Array = L["depth"]
		var sp: Array = L["speed"]
		var md := 1.0 if (_lure_depth >= float(dr[0]) and _lure_depth <= float(dr[1])) else 0.3
		var ms := 1.0 if (v >= float(sp[0]) and v <= float(sp[1])) else 0.4
		var rate: float = 0.09 * md * ms * float(world.appetite()) * float(world.bite_mod()) * 1.6
		if randf() < rate * delta:
			hooked = _pick_fish(true)
			_spin_bite = true
			state = BITE
			_win_t = 0.0
			_win_len = 0.7
			_sfx("plop", -14.0, 0.8)
			Input.vibrate_handheld(150)
	if dist <= 1.8:
		_say("Проводка закончена")
		_reset()

func _pick_fish(lure: bool) -> Dictionary:
	var r := _weights(lure)
	var ws: Dictionary = r["ws"]
	var total: float = float(r["total"])
	var pick := "roach"
	if total > 0.0:
		var x := randf() * total
		for id in ws:
			x -= float(ws[id])
			if x <= 0.0:
				pick = id
				break
	var fdd: Dictionary = Data.FISH[pick]
	var expo: float = [3.5, 2.5, 1.8][int(cfg()["hook"])]
	if lure:
		expo = [3.0, 2.4, 1.9][int(Data.LURES[State.lure]["size"])]
	var wt: float = lerpf(float(fdd["min"]), float(fdd["max"]), pow(randf(), expo))
	return {"id": pick, "w": snappedf(wt, 0.01)}

# ---------- вываживание ----------

func _fight(delta: float, o: Vector3) -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var rod := _rod()
	var limit: float = _limit()
	var w: float = float(hooked["w"])
	var k: float = _k()
	_phase -= delta
	if _phase <= 0.0:
		rush = not rush
		_phase = randf_range(1.2, 2.4) if rush else randf_range(1.6, 3.2)
		if rush:
			_run_side = 1.0 if randf() < 0.5 else -1.0
			Input.vibrate_handheld(60)
	var sf: float = 0.3 + 0.7 * _stamina
	var pull: float = w * float(fd["pull"]) * sf * (2.2 if rush else 0.5)
	var rin: float = maxf(reel_vel, 0.0)
	var rout: float = maxf(-reel_vel, 0.0)
	var load_kg: float = pull + rin * 0.07 * limit - rout * 0.25 * limit + (0.3 * limit if pump else 0.0)
	var target: float = clampf(load_kg / limit, 0.0, 1.6)
	tension = lerpf(tension, target, clampf(delta * 6.0, 0.0, 1.0))
	var away: float = (pull / limit) * 0.8 * (1.0 if rush else 0.15)
	dist += (away - rin * k * (0.35 if rush else 1.0) + rout * k) * delta
	if pump:
		dist -= 0.9 * delta * (0.35 if rush else 1.0)
	if tension >= 0.4 and tension <= 0.9:
		_stamina = maxf(0.0, _stamina - delta * (0.06 + 0.03 * minf(rin, 6.0) / 6.0) * (1.6 if pump else 1.0))
	elif tension < 0.2:
		_stamina = minf(1.0, _stamina + delta * 0.02)
	_wpos = o + _dir * dist
	_fpos = _wpos
	if tension > 0.85 and _haptic <= 0.0:
		_haptic = 0.35
		Input.vibrate_handheld(20)
	if tension >= 1.0:
		_over += delta
	else:
		_over = maxf(0.0, _over - delta * 1.5)
	if tension < 0.1 and not rush:
		_slack += delta
	else:
		_slack = maxf(0.0, _slack - delta)
	if _over > 0.4:
		_say("Леска порвалась! Рыба ушла")
		_sfx("snap", -12.0)
		_reset()
	elif _slack > 3.0:
		_say("Леска ослабла — рыба сошла с крючка")
		_reset()
	elif dist > float(rod["range"]) * 1.5:
		_say("Рыба утащила всю леску")
		_sfx("snap", -12.0)
		_reset()
	elif dist <= 1.8:
		_sfx("splash", -12.0)
		_catch()

func _catch() -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var w: float = float(hooked["w"])
	var fish := {"id": hooked["id"], "w": w, "len": int(round(float(fd["len"]) * pow(w, 1.0 / 3.0)))}
	var old: int = State.level()
	State.xp += int(10.0 + w * 25.0)
	State.counts[fish["id"]] = int(State.counts.get(fish["id"], 0)) + 1
	if w > float(State.record.get(fish["id"], 0.0)):
		State.record[fish["id"]] = w
	if State.level() > old:
		_say("Новый уровень: %d!" % State.level())
	_reset()
	_sfx("chime", -12.0)
	caught.emit(fish)

func _reset() -> void:
	state = IDLE
	hooked = {}
	tension = 0.0
	rush = false
	pump = false
	alert = 0
	_spin_bite = false
	if audio != null and held:
		audio.set_drag(0.0)

# ---------- картинка ----------

func _tremor() -> float:
	var burst: float = clampf(sin(_seq_t * 2.3 + float(slot)) * 1.6, 0.0, 1.0)
	return sin(_time * 46.0) * 1.3 * burst

func _rod_pose(delta: float) -> void:
	_lift_t = maxf(0.0, _lift_t - delta)
	var nod := 0.0
	var t := rtype()
	match state:
		FIGHT:
			nod = -clampf(tension, 0.0, 1.2) * 9.0 + sin(_time * 14.0) * tension * 1.2
		NIBBLE:
			if t == "feeder" and _seq_t < _trem:
				nod = _tremor()
		BITE:
			if t == "feeder":
				nod = -13.0 * smoothstep(0.0, 0.25, _win_t) + sin(_time * 8.0) * 0.6
			elif t == "spin":
				nod = sin(_time * 38.0) * 3.0
	var lift: float = sin(PI * (1.0 - _lift_t / 0.4)) * 22.0 if _lift_t > 0.0 else 0.0
	if held:
		if pivot != null:
			pivot.rotation_degrees.x = -68.0 + nod + lift
	else:
		_sp.rotation_degrees.x = -62.0 + nod

func _float_fx() -> Array:
	var dy: float = sin(_time * 2.0) * 0.01
	var tilt := 0.0
	if state == NIBBLE:
		for tn in _nibs:
			var ph: float = (_seq_t - float(tn)) / 0.35
			if ph > 0.0 and ph < 1.0:
				dy -= sin(ph * PI) * 0.035
	elif state == BITE:
		var bt := _win_t
		match _style:
			"dip":
				dy -= 0.11 * smoothstep(0.0, 0.45, bt) * (1.0 - smoothstep(_win_len - 0.35, _win_len, bt))
			"lift":
				dy += 0.06 * smoothstep(0.0, 0.4, bt)
				tilt = 70.0 * smoothstep(0.0, 0.5, bt)
			"sink":
				dy -= 0.16 * smoothstep(0.0, 1.2, bt)
			"run":
				dy -= 0.24 * smoothstep(0.0, 0.25, bt)
	elif state == FIGHT:
		dy = -0.02
	return [dy, tilt]

func _visuals(delta: float) -> void:
	var t := rtype()
	var active: bool = state >= FLY and state != NIBBLE or state == NIBBLE
	var in_water: bool = state != IDLE and state != CHARGE
	_line.visible = in_water
	var show_float: bool = in_water and (t == "float" or t == "spin" or state == FLY or state == FIGHT)
	_float.visible = show_float
	if in_water:
		var fx: Array = _float_fx()
		var p := _fpos
		if state == BITE and t == "float" and _style == "run":
			p += _dir.cross(Vector3.UP) * 0.5 * smoothstep(0.0, 0.5, _win_t)
		if state == FIGHT:
			var side := _dir.cross(Vector3.UP)
			p += side * (sin(_time * 1.6) * 0.6 + (_run_side * 0.8 if rush else 0.0)) * minf(2.0, dist * 0.15)
		_float.global_position = Vector3(p.x, p.y + 0.06 + float(fx[0]), p.z)
		_float.rotation_degrees.z = float(fx[1])
		_draw_line(_tip_pos(), Vector3(p.x, p.y + 0.02 + (float(fx[0]) if t == "float" else 0.0), p.z))
	_ring_t += delta / 1.4
	if state == WAIT and active:
		_ring_next -= delta
		if _ring_next <= 0.0:
			_ring_next = randf_range(3.0, 6.0)
			_ring_t = 0.0
	_ring.visible = in_water and _ring_t < 1.0 and state != FLY
	if _ring.visible:
		_ring.global_position = Vector3(_fpos.x, 0.03, _fpos.z)
		var s := lerpf(0.1, 0.9, _ring_t)
		_ring.scale = Vector3(s, 1.0, s)
		_ring_mat.albedo_color = Color(1, 1, 1, 0.6 * (1.0 - _ring_t))

func _draw_line(a: Vector3, b: Vector3) -> void:
	var im: ImmediateMesh = _line.mesh
	im.clear_surfaces()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	var n: int = 14
	var taut: bool = state == FIGHT or (rtype() == "feeder" and state >= WAIT)
	var sag: float = 0.04 if taut else 0.15 + a.distance_to(b) * 0.01
	for i in range(n + 1):
		var t: float = float(i) / float(n)
		var p: Vector3 = a.lerp(b, t)
		p.y -= sin(PI * t) * sag
		im.surface_add_vertex(p)
	im.surface_end()
