extends Node3D
# Рыбалка трёх видов:
#  float  — поплавочная: поклёвка -> подъём удочки (подсечка) -> рыба в руках
#  feeder — донка/фидер: поклёвка -> подсечка -> ручное вываживание колесом катушки
#  spin   — спиннинг: проводка колесом, удар хищника -> подсечка -> вываживание
# Колесо: против часовой = выбирать леску, по часовой = травить.

const Data = preload("res://scripts/data.gd")

const IDLE := 0
const CHARGE := 1
const FLY := 2
const WAIT := 3
const BITE := 4
const FIGHT := 5
const RETRIEVE := 6
const SPIN := 7

signal msg(text: String)
signal caught(fish: Dictionary)

var state: int = IDLE
var power: float = 0.0
var tension: float = 0.0
var dist: float = 0.0
var depth: float = 1.0
var rush: bool = false
var reel_vel: float = 0.0
var world
var audio
var cam: Camera3D
var tip: Node3D
var pivot: Node3D
var hooked: Dictionary = {}
var spot_pos: Vector2 = Vector2.ZERO
var spot_left: float = 0.0
var spot_mix: Dictionary = {}

var _pdir: float = 1.0
var _float: MeshInstance3D
var _float_mat: StandardMaterial3D
var _line: MeshInstance3D
var _ring: MeshInstance3D
var _ring_mat: StandardMaterial3D
var _spot: MeshInstance3D
var _dir: Vector3 = Vector3.FORWARD
var _target: Vector3 = Vector3.ZERO
var _from: Vector3 = Vector3.ZERO
var _fly_t: float = 0.0
var _fpos: Vector3 = Vector3.ZERO
var _timer: float = 0.0
var _stamina: float = 1.0
var _phase: float = 0.0
var _over: float = 0.0
var _slack: float = 0.0
var _time: float = 0.0
var _ring_t: float = 1.0
var _ring_next: float = 2.0
var _run_side: float = 1.0
var _lure_depth: float = 0.5
var _cd: float = 0.0
var _nib: float = 0.0
var _nib_cd: float = 3.0
var _auto_retrieve: bool = false
var _spin_bite: bool = false
var _click_acc: float = 0.0
var _lift_t: float = 0.0
var _haptic: float = 0.0

func _ready() -> void:
	_float = MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.03
	cap.height = 0.2
	_float.mesh = cap
	_float_mat = StandardMaterial3D.new()
	_float_mat.albedo_color = Color(0.95, 0.15, 0.1)
	_float.material_override = _float_mat
	_float.top_level = true
	_float.visible = false
	add_child(_float)

	_line = MeshInstance3D.new()
	_line.mesh = ImmediateMesh.new()
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(1, 1, 1, 0.8)
	lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_line.material_override = lm
	_line.top_level = true
	_line.visible = false
	add_child(_line)

	_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.9
	tm.outer_radius = 1.0
	_ring.mesh = tm
	_ring_mat = StandardMaterial3D.new()
	_ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ring_mat.albedo_color = Color(1, 1, 1, 0.5)
	_ring.material_override = _ring_mat
	_ring.top_level = true
	_ring.visible = false
	add_child(_ring)

	_spot = MeshInstance3D.new()
	var sc := CylinderMesh.new()
	sc.top_radius = 3.0
	sc.bottom_radius = 3.0
	sc.height = 0.02
	sc.radial_segments = 24
	_spot.mesh = sc
	var sm := StandardMaterial3D.new()
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.albedo_color = Color(0.75, 0.6, 0.3, 0.3)
	_spot.material_override = sm
	_spot.top_level = true
	_spot.visible = false
	add_child(_spot)

# ---------- вспомогательное ----------

func rtype() -> String:
	return str(State.rig["type"])

func _rod() -> Dictionary:
	return Data.cur_rod()

func _limit() -> float:
	return minf(float(Data.LINES[State.line]["kg"]), float(_rod()["kg"]))

func _k() -> float:
	return 0.2 * float(_rod()["reel"])

func _say(text: String) -> void:
	msg.emit(text)

func _sfx(name: String, vol: float = -6.0, pitch: float = 1.0) -> void:
	if audio != null:
		audio.play(name, vol, pitch)

func _rig_depth() -> float:
	if rtype() == "feeder":
		return depth
	return minf(float(State.rig["fdepth"]), depth)

func _in_spot() -> bool:
	return spot_left > 0.0 and Vector2(_target.x, _target.z).distance_to(spot_pos) < 6.0

func _add_spot(p: Vector2) -> void:
	spot_pos = p
	spot_left = 300.0
	spot_mix = State.gb_mix.duplicate()

# ---------- действия игрока ----------

func press_cast() -> void:
	if state != IDLE:
		return
	var rod := _rod()
	if rod.is_empty():
		_say("Нет удилища этого типа — купите в магазине")
		return
	var t := rtype()
	if t == "spin":
		if not State.owned.has("lure%d" % State.lure):
			_say("Выберите приманку в меню «Снасть»")
			return
	elif int(State.baits.get(State.bait, 0)) <= 0:
		_say("Нет наживки — купите в магазине")
		return
	if t == "feeder" and int(Data.FEEDERS[int(State.rig["feeder"])]["w"]) > int(rod["cast"]):
		_say("Кормушка слишком тяжёлая для этого удилища")
		return
	state = CHARGE
	power = 0.0
	_pdir = 1.0

func release_cast() -> void:
	if state != CHARGE:
		return
	var rod := _rod()
	var t := rtype()
	var f: Vector3 = -cam.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var d: float = float(rod["range"]) * (0.25 + 0.75 * power)
	var o := Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	_from = tip.global_position
	_dir = f
	_target = o + f * d
	_fly_t = 0.0
	_float_mat.albedo_color = Color(0.85, 0.88, 0.92) if t == "spin" else Color(0.95, 0.15, 0.1)
	_float.scale = Vector3.ONE * (0.6 if t == "spin" else 1.0)
	_lift_t = 0.4
	_sfx("swish")
	state = FLY

func strike() -> void:
	var t := rtype()
	if state == BITE:
		_lift_t = 0.4
		_sfx("swish", -4.0, 1.2)
		if t == "float":
			_lift_catch()
		else:
			state = FIGHT
			_stamina = 1.0
			rush = true
			_phase = randf_range(1.0, 1.8)
			tension = 0.3
			_over = 0.0
			_slack = 0.0
			_say("Подсёк! Крути колесо против часовой, при рывке — по часовой")
	elif state == WAIT:
		_lift_t = 0.4
		_sfx("swish", -8.0, 1.2)
		_say("Пустая подсечка")
		_auto_retrieve = t == "float"
		state = RETRIEVE

func _lift_catch() -> void:
	var w: float = float(hooked["w"])
	if w > _limit() * 1.6:
		_say("Снасть не выдержала — рыба сорвалась")
		_sfx("snap")
		_reset()
		return
	_sfx("splash", -4.0)
	_catch()

func throw_groundbait() -> void:
	if state != IDLE or rtype() == "spin":
		return
	if State.gb_portions <= 0:
		_say("Нет прикормки — замесите в меню «Снасть»")
		return
	var rod := _rod()
	if rod.is_empty():
		return
	var f: Vector3 = -cam.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var o := Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	var t := o + f * (float(rod["range"]) * 0.6)
	if world.height_at(t.x, t.z) > -0.3:
		_say("Прикормку нужно бросать в воду")
		return
	State.gb_portions -= 1
	_target = t
	_add_spot(Vector2(t.x, t.z))
	_sfx("plop", -8.0)
	_say("Прикормка заброшена (≈5 минут)")

# ---------- основной цикл ----------

func _process(delta: float) -> void:
	_time += delta
	spot_left = maxf(0.0, spot_left - delta)
	var o := Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	var rin: float = maxf(reel_vel, 0.0)
	_haptic = maxf(0.0, _haptic - delta)
	match state:
		CHARGE:
			power += _pdir * delta * 0.9
			if power >= 1.0:
				power = 1.0
				_pdir = -1.0
			elif power <= 0.0:
				power = 0.0
				_pdir = 1.0
		FLY:
			_fly_t += delta / 0.9
			var t := minf(_fly_t, 1.0)
			_fpos = _from.lerp(Vector3(_target.x, 0.0, _target.z), t)
			_fpos.y += sin(PI * t) * (1.5 + _from.distance_to(_target) * 0.1)
			if _fly_t >= 1.0:
				_land(o)
		WAIT:
			_fpos = o + _dir * dist
			_nib = maxf(0.0, _nib - delta)
			_nib_cd -= delta
			if _nib_cd <= 0.0:
				_nib = 0.6
				_nib_cd = randf_range(2.0, 6.0)
				if rtype() == "float":
					_sfx("plip", -18.0)
			if rtype() != "float" and rin > 1.5:
				_auto_retrieve = false
				state = RETRIEVE
			_timer -= delta
			if _timer <= 0.0:
				_start_bite()
		BITE:
			_fpos = o + _dir * dist
			_timer -= delta
			if _timer <= 0.0:
				hooked = {}
				if _spin_bite:
					_say("Хищник промахнулся — вози дальше")
					state = SPIN
					_cd = 2.0
				else:
					_say("Не успел подсечь — рыба ушла")
					state = WAIT
					_timer = randf_range(4.0, 9.0)
		FIGHT:
			_fight(delta, o)
		RETRIEVE:
			if _auto_retrieve:
				dist -= 9.0 * delta
			else:
				dist -= rin * _k() * delta
			_fpos = o + _dir * dist
			if dist <= 1.8:
				_reset()
		SPIN:
			_spin(delta, o, rin)
	_click_acc += absf(reel_vel) * delta
	if _click_acc >= 0.9:
		_click_acc = 0.0
		if state == RETRIEVE or state == SPIN or state == FIGHT:
			_sfx("click", -16.0, randf_range(0.95, 1.05))
	if audio != null:
		audio.set_drag(clampf(maxf(-reel_vel, 0.0) / 6.0, 0.0, 1.0) if state == FIGHT else 0.0)
	_rod_pose(delta)
	_visuals(delta)

func _land(o: Vector3) -> void:
	var h: float = world.height_at(_target.x, _target.z)
	if h > -0.3:
		_say("Закиньте в воду")
		_reset()
		return
	depth = -h
	dist = Vector2(_target.x - o.x, _target.z - o.z).length()
	_fpos = Vector3(_target.x, 0.0, _target.z)
	_ring_t = 0.0
	_sfx("plop")
	var t := rtype()
	if t == "spin":
		_lure_depth = 0.3
		_cd = 2.5
		_spin_bite = false
		state = SPIN
		_say("Приманка в воде. Крути колесо против часовой — проводка")
		return
	State.baits[State.bait] = int(State.baits.get(State.bait, 0)) - 1
	state = WAIT
	_nib_cd = randf_range(2.0, 5.0)
	var flat := false
	if t == "feeder":
		if State.gb_portions > 0:
			State.gb_portions -= 1
			_add_spot(Vector2(_target.x, _target.z))
	elif float(State.rig["fdepth"]) > depth + 0.3:
		flat = true
		_say("Поплавок лёг — уменьши глубину в меню «Снасть»")
	var hr: float = world.hour
	var k := 0.7 if ((hr > 4.5 and hr < 9.0) or (hr > 17.0 and hr < 21.5)) else 1.0
	k /= float(world.bite_mod())
	if _in_spot():
		k *= 0.6
	if flat:
		k *= 2.0
	_timer = randf_range(4.0, 13.0) * k

func _start_bite() -> void:
	hooked = _pick_fish(false)
	state = BITE
	_spin_bite = false
	if rtype() == "feeder":
		_timer = 1.6
		_sfx("bell")
		_say("Звонок! Подсекай (свайп вверх)!")
	else:
		var cap: float = float(Data.FLOATS[int(State.rig["float"])]["cap"])
		var sk: float = float(Data.SINKERS[int(State.rig["sinker"])])
		var m := clampf(1.0 - absf(sk - cap) / cap, 0.3, 1.0)
		_timer = 0.8 + 0.7 * m
		_sfx("plip", -8.0)
		_say("ПОКЛЁВКА! Подними удочку (свайп вверх)!")
	Input.vibrate_handheld(150)

func _spin(delta: float, o: Vector3, rin: float) -> void:
	var v: float = rin * _k()
	dist -= v * delta
	_fpos = o + _dir * dist
	var tgt: float = lerpf(maxf(depth * 0.9, 0.4), 0.3, clampf(v / 1.6, 0.0, 1.0))
	_lure_depth = move_toward(_lure_depth, tgt, 0.8 * delta)
	_cd -= delta
	if v > 0.15 and int(Time.get_ticks_msec() / 700) != _last_wake:
		_last_wake = int(Time.get_ticks_msec() / 700)
		_ring_t = 0.0
	if _cd <= 0.0 and v > 0.15:
		var L: Dictionary = Data.LURES[State.lure]
		var dr: Array = L["depth"]
		var sp: Array = L["speed"]
		var md := 1.0 if (_lure_depth >= float(dr[0]) and _lure_depth <= float(dr[1])) else 0.3
		var ms := 1.0 if (v >= float(sp[0]) and v <= float(sp[1])) else 0.4
		var rate: float = 0.09 * md * ms * float(world.bite_mod())
		if randf() < rate * delta:
			hooked = _pick_fish(true)
			_spin_bite = true
			state = BITE
			_timer = 0.7
			_sfx("plop", -4.0, 0.7)
			_say("УДАР! Подсекай!")
			Input.vibrate_handheld(200)
	if dist <= 1.8:
		_say("Проводка закончена")
		_reset()

var _last_wake: int = 0

func _pick_fish(lure: bool) -> Dictionary:
	var rd: float = _lure_depth if lure else _rig_depth()
	var hook: int = int(State.rig["hook"])
	var mix: Dictionary = spot_mix if (_in_spot() and not lure) else {}
	var loc_fish: Dictionary = world.loc_fish
	var ws := {}
	var total := 0.0
	for id in Data.FISH:
		var fd: Dictionary = Data.FISH[id]
		var w: float = float(loc_fish.get(id, 0.0))
		if w <= 0.0:
			continue
		if lure:
			w *= float(Data.LURE_AFF.get(id, 0.02))
		else:
			w *= 1.0 if (State.bait in fd["baits"]) else 0.12
			w *= [1.0, 0.5, 0.12][absi(hook - int(fd["hook"]))]
			w *= Data.gb_effect(id, mix)
		var dr: Array = fd["depth"]
		w *= 1.0 if (rd >= float(dr[0]) and rd <= float(dr[1])) else 0.25
		ws[id] = w
		total += w
	var pick := "roach"
	if total > 0.0:
		var r := randf() * total
		for id in ws:
			r -= float(ws[id])
			if r <= 0.0:
				pick = id
				break
	var fdd: Dictionary = Data.FISH[pick]
	var expo: float = [3.5, 2.5, 1.8][hook]
	if lure:
		expo = [3.0, 2.4, 1.9][int(Data.LURES[State.lure]["size"])]
	var wt: float = lerpf(float(fdd["min"]), float(fdd["max"]), pow(randf(), expo))
	return {"id": pick, "w": snappedf(wt, 0.01)}

# ---------- вываживание ----------

func _fight(delta: float, o: Vector3) -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var rod := _rod()
	var limit: float = _limit()
	var w: float = float(hooked["w"])
	var k: float = _k()
	_phase -= delta
	if _phase <= 0.0:
		rush = not rush
		_phase = randf_range(1.2, 2.4) if rush else randf_range(1.6, 3.2)
		if rush:
			_run_side = 1.0 if randf() < 0.5 else -1.0
			Input.vibrate_handheld(70)
			_sfx("plop", -10.0, 0.6)
	var sf: float = 0.3 + 0.7 * _stamina
	var pull: float = w * float(fd["pull"]) * sf * (2.2 if rush else 0.5)
	var rin: float = maxf(reel_vel, 0.0)
	var rout: float = maxf(-reel_vel, 0.0)
	var load_kg: float = pull + rin * 0.07 * limit - rout * 0.25 * limit
	var target: float = clampf(load_kg / limit, 0.0, 1.6)
	tension = lerpf(tension, target, clampf(delta * 6.0, 0.0, 1.0))
	var away: float = (pull / limit) * 0.8 * (1.0 if rush else 0.15)
	dist += (away - rin * k * (0.35 if rush else 1.0) + rout * k) * delta
	if tension >= 0.4 and tension <= 0.9:
		_stamina = maxf(0.0, _stamina - delta * (0.06 + 0.03 * minf(rin, 6.0) / 6.0))
	elif tension < 0.2:
		_stamina = minf(1.0, _stamina + delta * 0.02)
	_fpos = o + _dir * dist
	if tension > 0.85 and _haptic <= 0.0:
		_haptic = 0.3
		Input.vibrate_handheld(25)
	if tension >= 1.0:
		_over += delta
	else:
		_over = maxf(0.0, _over - delta * 1.5)
	if tension < 0.1 and not rush:
		_slack += delta
	else:
		_slack = maxf(0.0, _slack - delta)
	if _over > 0.4:
		_say("Леска порвалась! Рыба ушла")
		_sfx("snap")
		_reset()
	elif _slack > 3.0:
		_say("Леска ослабла — рыба сошла с крючка")
		_reset()
	elif dist > float(rod["range"]) * 1.5:
		_say("Рыба утащила всю леску")
		_sfx("snap")
		_reset()
	elif dist <= 1.8:
		_sfx("splash", -4.0)
		_catch()

func _catch() -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var w: float = float(hooked["w"])
	var fish := {"id": hooked["id"], "w": w, "len": int(round(float(fd["len"]) * pow(w, 1.0 / 3.0)))}
	var old: int = State.level()
	State.xp += int(10.0 + w * 25.0)
	State.counts[fish["id"]] = int(State.counts.get(fish["id"], 0)) + 1
	if w > float(State.record.get(fish["id"], 0.0)):
		State.record[fish["id"]] = w
	if State.level() > old:
		_say("Новый уровень: %d!" % State.level())
	_reset()
	_sfx("chime", -5.0)
	caught.emit(fish)

func _reset() -> void:
	state = IDLE
	hooked = {}
	tension = 0.0
	rush = false
	_spin_bite = false
	if audio != null:
		audio.set_drag(0.0)

# ---------- картинка ----------

func _rod_pose(delta: float) -> void:
	if pivot == null:
		return
	_lift_t = maxf(0.0, _lift_t - delta)
	var bend: float = 0.0
	if state == FIGHT:
		bend = clampf(tension, 0.0, 1.2) * 9.0 + sin(_time * 14.0) * tension * 1.5
	elif state == BITE:
		bend = sin(_time * 38.0) * 3.0
	var lift: float = sin(PI * (1.0 - _lift_t / 0.4)) * 22.0 if _lift_t > 0.0 else 0.0
	pivot.rotation_degrees.x = -68.0 + bend - lift

func _visuals(delta: float) -> void:
	var vis: bool = state >= FLY
	_float.visible = vis
	_line.visible = vis
	if vis:
		var bob := sin(_time * 2.0) * 0.01
		if state == BITE:
			bob = -0.05 + sin(_time * 35.0) * 0.015
		elif state == WAIT and _nib > 0.0 and rtype() == "float":
			bob += sin(_time * 30.0) * 0.012 - 0.015
		elif state == FIGHT:
			bob = -0.02
		var p := _fpos
		if state == FIGHT:
			var side := _dir.cross(Vector3.UP)
			p += side * (sin(_time * 1.6) * 0.6 + (_run_side * 0.8 if rush else 0.0)) * minf(2.0, dist * 0.15)
		_float.global_position = Vector3(p.x, p.y + 0.06 + bob, p.z)
		_draw_line(tip.global_position, _float.global_position)
	_ring_t += delta / 1.4
	if state == WAIT:
		_ring_next -= delta
		if _ring_next <= 0.0:
			_ring_next = randf_range(2.5, 4.0)
			_ring_t = 0.0
	_ring.visible = vis and _ring_t < 1.0
	if _ring.visible:
		_ring.global_position = Vector3(_fpos.x, 0.03, _fpos.z)
		var s := lerpf(0.1, 0.9, _ring_t)
		_ring.scale = Vector3(s, 1.0, s)
		_ring_mat.albedo_color = Color(1, 1, 1, 0.6 * (1.0 - _ring_t))
	_spot.visible = spot_left > 0.0
	if _spot.visible:
		_spot.global_position = Vector3(spot_pos.x, 0.02, spot_pos.y)

func _draw_line(a: Vector3, b: Vector3) -> void:
	var im: ImmediateMesh = _line.mesh
	im.clear_surfaces()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	var n: int = 14
	var sag: float = 0.03 if state == FIGHT else 0.15 + a.distance_to(b) * 0.01
	for i in range(n + 1):
		var t: float = float(i) / float(n)
		var p: Vector3 = a.lerp(b, t)
		p.y -= sin(PI * t) * sag
		im.surface_add_vertex(p)
	im.surface_end()
