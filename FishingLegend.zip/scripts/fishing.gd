extends Node3D
# Логика рыбалки: заброс, ожидание, поклёвка, подсечка, вываживание

const Data = preload("res://scripts/data.gd")

const IDLE := 0
const CHARGE := 1
const FLY := 2
const WAIT := 3
const BITE := 4
const FIGHT := 5
const RETRIEVE := 6

signal msg(text: String)
signal caught(fish: Dictionary)

var state: int = IDLE
var power: float = 0.0
var tension: float = 0.0
var dist: float = 0.0
var depth: float = 1.0
var reel_held: bool = false
var world
var cam: Camera3D
var tip: Node3D
var hooked: Dictionary = {}

var _pdir: float = 1.0
var _float: MeshInstance3D
var _line: MeshInstance3D
var _ring: MeshInstance3D
var _ring_mat: StandardMaterial3D
var _dir: Vector3 = Vector3.FORWARD
var _target: Vector3 = Vector3.ZERO
var _from: Vector3 = Vector3.ZERO
var _fly_t: float = 0.0
var _fpos: Vector3 = Vector3.ZERO
var _timer: float = 0.0
var _stamina: float = 1.0
var _rush: bool = false
var _phase: float = 0.0
var _over: float = 0.0
var _slack: float = 0.0
var _time: float = 0.0
var _ring_t: float = 1.0
var _ring_next: float = 2.0

func _ready() -> void:
	_float = MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.03
	cap.height = 0.2
	_float.mesh = cap
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.95, 0.15, 0.1)
	_float.material_override = fm
	_float.top_level = true
	_float.visible = false
	add_child(_float)

	_line = MeshInstance3D.new()
	_line.mesh = ImmediateMesh.new()
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(1, 1, 1, 0.8)
	lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_line.material_override = lm
	_line.top_level = true
	_line.visible = false
	add_child(_line)

	_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.9
	tm.outer_radius = 1.0
	_ring.mesh = tm
	_ring_mat = StandardMaterial3D.new()
	_ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ring_mat.albedo_color = Color(1, 1, 1, 0.5)
	_ring.material_override = _ring_mat
	_ring.top_level = true
	_ring.visible = false
	add_child(_ring)

func press_cast() -> void:
	if state != IDLE:
		return
	if int(State.baits.get(State.bait, 0)) <= 0:
		msg.emit("Нет наживки — купите в магазине")
		return
	state = CHARGE
	power = 0.0
	_pdir = 1.0

func release_cast() -> void:
	if state != CHARGE:
		return
	var rod: Dictionary = Data.RODS[State.rod]
	var f: Vector3 = -cam.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var d: float = float(rod["range"]) * (0.25 + 0.75 * power)
	var o := Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	_from = tip.global_position
	_dir = f
	_target = o + f * d
	_fly_t = 0.0
	state = FLY

func strike() -> void:
	if state == BITE:
		state = FIGHT
		_stamina = 1.0
		_rush = true
		_phase = randf_range(1.0, 1.8)
		tension = 0.3
		_over = 0.0
		_slack = 0.0
		msg.emit("Подсёк! Вываживай")
	elif state == WAIT:
		msg.emit("Пустая подсечка")
		state = RETRIEVE

func _process(delta: float) -> void:
	_time += delta
	var o := Vector3(cam.global_position.x, 0.0, cam.global_position.z)
	match state:
		CHARGE:
			power += _pdir * delta * 0.9
			if power >= 1.0:
				power = 1.0
				_pdir = -1.0
			elif power <= 0.0:
				power = 0.0
				_pdir = 1.0
		FLY:
			_fly_t += delta / 0.9
			var t := minf(_fly_t, 1.0)
			_fpos = _from.lerp(Vector3(_target.x, 0.0, _target.z), t)
			_fpos.y += sin(PI * t) * (1.5 + _from.distance_to(_target) * 0.1)
			if _fly_t >= 1.0:
				_land(o)
		WAIT:
			_fpos = o + _dir * dist
			if reel_held:
				state = RETRIEVE
			_timer -= delta
			if _timer <= 0.0:
				_start_bite()
		BITE:
			_fpos = o + _dir * dist
			_timer -= delta
			if _timer <= 0.0:
				hooked = {}
				msg.emit("Не успел подсечь — рыба ушла")
				state = WAIT
				_timer = randf_range(4.0, 9.0)
		FIGHT:
			_fight(delta, o)
		RETRIEVE:
			if reel_held:
				dist -= 6.0 * delta
			_fpos = o + _dir * dist
			if dist <= 1.8:
				_reset()
	_visuals(delta)

func _land(o: Vector3) -> void:
	var h: float = world.height_at(_target.x, _target.z)
	if h > -0.3:
		msg.emit("Закиньте в воду")
		_reset()
		return
	State.baits[State.bait] = int(State.baits.get(State.bait, 0)) - 1
	depth = -h
	dist = Vector2(_target.x - o.x, _target.z - o.z).length()
	state = WAIT
	var hr: float = world.hour
	var k := 0.7 if ((hr > 4.5 and hr < 9.0) or (hr > 17.0 and hr < 21.5)) else 1.0
	_timer = randf_range(4.0, 13.0) * k
	_ring_t = 0.0
	_fpos = Vector3(_target.x, 0.0, _target.z)

func _start_bite() -> void:
	hooked = _pick_fish()
	state = BITE
	_timer = 1.3
	msg.emit("ПОКЛЁВКА! Подсекай!")
	Input.vibrate_handheld(150)

func _pick_fish() -> Dictionary:
	var ws := {}
	var total := 0.0
	for id in Data.FISH:
		var fd: Dictionary = Data.FISH[id]
		var w: float = float(fd["chance"])
		w *= 1.0 if (State.bait in fd["baits"]) else 0.12
		var dr: Array = fd["depth"]
		w *= 1.0 if (depth >= float(dr[0]) and depth <= float(dr[1])) else 0.25
		ws[id] = w
		total += w
	var r := randf() * total
	var pick := "roach"
	for id in ws:
		r -= float(ws[id])
		if r <= 0.0:
			pick = id
			break
	var f: Dictionary = Data.FISH[pick]
	var wt: float = lerpf(float(f["min"]), float(f["max"]), pow(randf(), 2.5))
	return {"id": pick, "w": snappedf(wt, 0.01)}

func _fight(delta: float, o: Vector3) -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var rod: Dictionary = Data.RODS[State.rod]
	var ln: Dictionary = Data.LINES[State.line]
	var limit: float = minf(float(ln["kg"]), float(rod["kg"]))
	var w: float = float(hooked["w"])
	_phase -= delta
	if _phase <= 0.0:
		_rush = not _rush
		_phase = randf_range(1.0, 2.2) if _rush else randf_range(1.2, 2.4)
	var force: float = w * float(fd["pull"]) * (1.0 if _rush else 0.3) * (0.45 + 0.55 * _stamina)
	var load_kg: float = force * (1.0 if reel_held else 0.55)
	if reel_held:
		load_kg += 0.12 * limit
	tension = lerpf(tension, clampf(load_kg / limit, 0.0, 1.4), clampf(delta * 4.0, 0.0, 1.0))
	if reel_held:
		dist -= float(rod["reel"]) * (0.2 if _rush else 1.0) * (0.4 + 0.6 * _stamina) * delta
	elif _rush:
		dist += 1.2 * delta
	_stamina = maxf(0.0, _stamina - delta * (0.05 + (0.04 if reel_held else 0.0)))
	_fpos = o + _dir * dist
	if tension >= 1.0:
		_over += delta
	else:
		_over = maxf(0.0, _over - delta * 1.5)
	if tension < 0.1 and not _rush:
		_slack += delta
	else:
		_slack = maxf(0.0, _slack - delta)
	if _over > 0.4:
		msg.emit("Леска порвалась! Рыба ушла")
		_reset()
	elif _slack > 5.0:
		msg.emit("Рыба сошла с крючка")
		_reset()
	elif dist > float(rod["range"]) * 1.4:
		msg.emit("Рыба утащила всю леску")
		_reset()
	elif dist <= 1.8:
		_catch()

func _catch() -> void:
	var fd: Dictionary = Data.FISH[hooked["id"]]
	var w: float = float(hooked["w"])
	var fish := {"id": hooked["id"], "w": w, "len": int(round(float(fd["len"]) * pow(w, 1.0 / 3.0)))}
	var old: int = State.level()
	State.xp += int(10.0 + w * 25.0)
	if w > float(State.record.get(fish["id"], 0.0)):
		State.record[fish["id"]] = w
	if State.level() > old:
		msg.emit("Новый уровень: %d!" % State.level())
	_reset()
	caught.emit(fish)

func _reset() -> void:
	state = IDLE
	hooked = {}
	tension = 0.0

func _visuals(delta: float) -> void:
	var vis: bool = state >= FLY
	_float.visible = vis
	_line.visible = vis
	if vis:
		var bob := sin(_time * 2.0) * 0.01
		if state == BITE:
			bob = -0.05 + sin(_time * 35.0) * 0.015
		elif state == FIGHT:
			bob = -0.02
		var p := _fpos
		if state == FIGHT:
			var side := _dir.cross(Vector3.UP)
			p += side * sin(_time * 1.6) * minf(2.0, dist * 0.15)
		_float.global_position = Vector3(p.x, p.y + 0.06 + bob, p.z)
		_draw_line(tip.global_position, _float.global_position)
	_ring_t += delta / 1.4
	if state == WAIT:
		_ring_next -= delta
		if _ring_next <= 0.0:
			_ring_next = randf_range(2.5, 4.0)
			_ring_t = 0.0
	_ring.visible = vis and _ring_t < 1.0
	if _ring.visible:
		_ring.global_position = Vector3(_fpos.x, 0.03, _fpos.z)
		var s := lerpf(0.1, 0.9, _ring_t)
		_ring.scale = Vector3(s, 1.0, s)
		_ring_mat.albedo_color = Color(1, 1, 1, 0.6 * (1.0 - _ring_t))

func _draw_line(a: Vector3, b: Vector3) -> void:
	var im: ImmediateMesh = _line.mesh
	im.clear_surfaces()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	var n: int = 14
	var sag: float = 0.03 if state == FIGHT else 0.15 + a.distance_to(b) * 0.01
	for i in range(n + 1):
		var t: float = float(i) / float(n)
		var p: Vector3 = a.lerp(b, t)
		p.y -= sin(PI * t) * sag
		im.surface_add_vertex(p)
	im.surface_end()
