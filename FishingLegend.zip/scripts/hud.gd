extends CanvasLayer
# Интерфейс: сенсорное управление, кнопки, магазин, карточка улова, меню

const Data = preload("res://scripts/data.gd")
const Fishing = preload("res://scripts/fishing.gd")
const RoundBtn = preload("res://scripts/round_btn.gd")
const ReelWheelScript = preload("res://scripts/reel_wheel.gd")

signal strike
signal cast_down
signal cast_up

var move: Vector2 = Vector2.ZERO
var look: Vector2 = Vector2.ZERO
var reel_out: float = 0.0
var reel_vel: float = 0.0
var world
var audio
var _wheel
var _wheel_acc: float = 0.0
var _wheel_last: float = 0.0
var _swiped: Dictionary = {}
var _map: ColorRect
var _map_list: VBoxContainer
var _theme: Theme
var _near_stop: bool = false
var sens: float = 1.0
var modal_open: bool = false
var hour: float = 7.0
var fishing

var _btns: Dictionary = {}
var _touches: Dictionary = {}
var _pad: Control
var _stick_origin: Vector2 = Vector2.ZERO
var _stick_idx: int = -1
var _status: Label
var _hint: Label
var _toast: Label
var _toast_t: float = 0.0
var _power: ProgressBar
var _tension: ProgressBar
var _shop: ColorRect
var _shop_list: VBoxContainer
var _card: ColorRect
var _card_list: VBoxContainer
var _menu: ColorRect
var _menu_list: VBoxContainer
var _tackle: ColorRect
var _tackle_list: VBoxContainer
var _journal: ColorRect
var _journal_list: VBoxContainer
var _card_fish: Dictionary = {}
var _near_shop: bool = false
var _quality: int = 1
var _fps: int = 60

func _ready() -> void:
	layer = 10
	_theme = _make_theme()
	_pad = Control.new()
	_pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_pad)
	_pad.set_anchors_preset(Control.PRESET_FULL_RECT)
	_pad.draw.connect(_draw_pad)

	_wheel = ReelWheelScript.new()
	add_child(_wheel)
	_place(_wheel, 1, 1, 1, 1, -310, -310, -40, -40)
	_wheel.visible = false

	_btns["cast"] = _mk_btn("ЗАБРОС", "cast", "circle", true, true, 340, 50, 150, 150)
	_btns["lift"] = _mk_btn("ПОДСЕЧКА", "lift", "circle", true, true, 350, 220, 125, 125)
	_btns["gb"] = _mk_btn("КОРМ", "drop", "circle", true, true, 510, 60, 100, 100)
	_btns["menu"] = _mk_btn("МЕНЮ", "menu", "circle", true, false, 20, 20, 84, 84)
	_btns["shop"] = _mk_btn("МАГАЗИН", "", "pill", true, false, 120, 28, 190, 64)
	_btns["map"] = _mk_btn("КАРТА", "", "pill", true, false, 120, 28, 190, 64)
	_btns["bait"] = _mk_btn("Наживка", "", "pill", false, false, 20, 120, 360, 56)
	_btns["rig"] = _mk_btn("СНАСТЬ", "", "pill", false, false, 20, 186, 190, 56)

	_status = _lbl("", 24)
	_status.add_theme_stylebox_override("normal", _sb(Color(0.05, 0.08, 0.11, 0.62), 16))
	add_child(_status)
	_place(_status, 0, 0, 0, 0, 20, 16, 560, 96)
	_toast = _lbl("", 32)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_toast)
	_place(_toast, 0.15, 0, 0.85, 0, 0, 170, 0, 240)
	_hint = _lbl("", 24)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_hint)
	_place(_hint, 0.12, 1, 0.58, 1, 0, -135, 0, -50)
	_power = ProgressBar.new()
	_power.max_value = 1.0
	_power.step = 0.001
	_power.show_percentage = false
	_power.add_theme_stylebox_override("fill", _sb(Color(0.3, 0.85, 0.6), 10))
	_power.add_theme_stylebox_override("background", _sb(Color(0.05, 0.08, 0.11, 0.6), 10))
	add_child(_power)
	_place(_power, 0.2, 1, 0.55, 1, 0, -185, 0, -155)

	var m := _make_modal("Магазин", true)
	_shop = m[0]
	_shop_list = m[1]
	m = _make_modal("Улов", false)
	_card = m[0]
	_card_list = m[1]
	m = _make_modal("Меню", true)
	_menu = m[0]
	_menu_list = m[1]
	m = _make_modal("Снасть и прикормка", true)
	_tackle = m[0]
	_tackle_list = m[1]
	m = _make_modal("Журнал рыб", true)
	_journal = m[0]
	_journal_list = m[1]
	m = _make_modal("Автобус — карта", true)
	_map = m[0]
	_map_list = m[1]

func setup(f, w, a) -> void:
	fishing = f
	world = w
	audio = a
	cast_down.connect(f.press_cast)
	cast_up.connect(f.release_cast)
	strike.connect(f.strike)
	f.msg.connect(toast)
	f.caught.connect(show_card)
	_apply_quality()

func set_stop_near(v: bool) -> void:
	_near_stop = v

func set_shop_near(v: bool) -> void:
	_near_shop = v

func toast(text: String) -> void:
	_toast.text = text
	_toast_t = 3.0

# ---------- построение элементов ----------

func _place(c: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, orr: float, ob: float) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = orr
	c.offset_bottom = ob

func _mk_btn(text: String, icon: String, shape: String, right: bool, bottom: bool, mx: float, my: float, w: float, h: float):
	var b = RoundBtn.new()
	b.text = text
	b.icon = icon
	b.shape = shape
	b.font_size = 24 if shape == "circle" else 26
	add_child(b)
	var ax: float = 1.0 if right else 0.0
	var ay: float = 1.0 if bottom else 0.0
	_place(b, ax, ay, ax, ay, -(mx + w) if right else mx, -(my + h) if bottom else my, -mx if right else mx + w, -my if bottom else my + h)
	return b

func _sb(c: Color, rad: int, bc: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(rad)
	s.border_color = bc
	s.set_border_width_all(bw)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func _make_theme() -> Theme:
	var th := Theme.new()
	var edge := Color(0.3, 0.8, 0.75, 0.55)
	th.set_stylebox("normal", "Button", _sb(Color(0.13, 0.19, 0.24), 16, edge, 2))
	th.set_stylebox("hover", "Button", _sb(Color(0.17, 0.25, 0.31), 16, edge, 2))
	th.set_stylebox("pressed", "Button", _sb(Color(0.2, 0.5, 0.5), 16, edge, 2))
	th.set_stylebox("disabled", "Button", _sb(Color(0.1, 0.12, 0.14), 16, Color(1, 1, 1, 0.1), 2))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_stylebox("panel", "PanelContainer", _sb(Color(0.05, 0.08, 0.11, 0.97), 28, edge, 3))
	th.set_font_size("font_size", "Button", 28)
	th.set_font_size("font_size", "Label", 26)
	th.set_color("font_color", "Label", Color(0.93, 0.96, 0.97))
	th.set_color("font_color", "Button", Color(0.95, 0.98, 1.0))
	th.set_color("font_disabled_color", "Button", Color(0.5, 0.55, 0.58))
	return th

func _lbl(text: String, fs: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 6)
	return l

func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(cb)
	return b

func _make_modal(title: String, closable: bool) -> Array:
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.6)
	root.visible = false
	root.theme = _theme
	add_child(root)
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	root.add_child(center)
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(840, 590)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	var t := _lbl(title, 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	sc.add_child(list)
	if closable:
		vb.add_child(_btn("Закрыть", _close_modal.bind(root)))
	return [root, list]

func _clear(list: Control) -> void:
	for c in list.get_children():
		list.remove_child(c)
		c.queue_free()

func _open_modal(m: Control) -> void:
	_release_all()
	modal_open = true
	m.visible = true

func _close_modal(m: Control) -> void:
	m.visible = false
	modal_open = _shop.visible or _card.visible or _menu.visible or _tackle.visible or _journal.visible or _map.visible
	State.save_game()

# ---------- кадр ----------

func _process(delta: float) -> void:
	if fishing == null:
		return
	var st: int = fishing.state
	var t: String = str(State.rig["type"])
	var active: bool = st >= Fishing.WAIT
	_power.visible = st == Fishing.CHARGE
	_power.value = fishing.power
	var wheel_on: bool = t != "float" and active and not modal_open
	_wheel.visible = wheel_on
	_wheel.fighting = st == Fishing.FIGHT
	_wheel.tension = fishing.tension
	_wheel.rush = fishing.rush
	_wheel.dist = fishing.dist
	_wheel.held = _touches.values().has("wheel")
	var inst: float = -_wheel_acc / maxf(delta, 0.001)
	_wheel_acc = 0.0
	reel_vel = lerpf(reel_vel, inst, clampf(delta * 14.0, 0.0, 1.0))
	reel_out = reel_vel if (absf(reel_vel) > 0.6 and wheel_on) else 0.0
	_btns["cast"].visible = (st == Fishing.IDLE or st == Fishing.CHARGE) and not modal_open
	_btns["cast"].held = st == Fishing.CHARGE
	_btns["lift"].visible = active and not modal_open
	_btns["lift"].active = st == Fishing.BITE
	_btns["gb"].visible = st == Fishing.IDLE and t != "spin" and not modal_open
	_btns["shop"].visible = _near_shop and not modal_open and st == Fishing.IDLE
	_btns["map"].visible = _near_stop and not modal_open and st == Fishing.IDLE
	var hint := ""
	match st:
		Fishing.IDLE:
			if t == "float":
				hint = "Удерживай ЗАБРОС — сила, отпусти — бросок. На поклёвку — свайп вверх"
			elif t == "feeder":
				hint = "Забрось фидер. На звонок — свайп вверх, потом колесо"
			else:
				hint = "Забрось приманку, веди колесом против часовой"
		Fishing.CHARGE:
			hint = "Отпусти, когда сила нужная"
		Fishing.WAIT:
			hint = "Ждём поклёвку… глубина %.1f м" % fishing.depth
		Fishing.BITE:
			hint = "ПОКЛЁВКА! Свайп вверх или ПОДСЕЧКА!"
		Fishing.FIGHT:
			if fishing.rush:
				hint = "РЫВОК! Крути колесо ПО часовой — трави леску!"
			else:
				hint = "Рыба устала — крути ПРОТИВ часовой, следи за дугой"
		Fishing.RETRIEVE:
			hint = "Выбираем леску…" if t != "float" else "Поднимаем снасть"
		Fishing.SPIN:
			hint = "Проводка: крути колесо ПРОТИВ часовой. Быстрее/медленнее — меняй темп"
	_hint.text = hint
	var bn: String = State.bait
	if t == "spin":
		_btns["bait"].text = "Приманка: %s" % str(Data.LURES[State.lure]["name"])
	else:
		var bname: String = str(Data.BAITS[bn]["name"]) if Data.BAITS.has(bn) else "—"
		_btns["bait"].text = "Наживка: %s (%d)" % [bname, int(State.baits.get(bn, 0))]
	_status.text = "Серебро %d   Ур. %d   %02d:%02d\n%s · %s   Прикормка: %d" % [State.silver, State.level(), int(hour), int((hour - floorf(hour)) * 60.0), str(world.loc["name"]), str(world.weather_name), State.gb_portions]
	_toast_t -= delta
	_toast.modulate = Color(1, 1, 1, clampf(_toast_t, 0.0, 1.0))

func _draw_pad() -> void:
	if _stick_idx != -1:
		_pad.draw_circle(_stick_origin, 110.0, Color(1, 1, 1, 0.12))
		_pad.draw_arc(_stick_origin, 110.0, 0.0, TAU, 40, Color(1, 1, 1, 0.4), 3.0)
		_pad.draw_circle(_stick_origin + move * 110.0, 42.0, Color(1, 1, 1, 0.45))

# ---------- сенсорный ввод ----------

func _input(event: InputEvent) -> void:
	if modal_open:
		return
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_touch_down(e.index, e.position)
		else:
			_touch_up(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_move(d.index, d.position, d.relative)

func _touch_down(idx: int, pos: Vector2) -> void:
	_swiped.erase(idx)
	if _wheel.visible:
		var rc: Rect2 = _wheel.get_global_rect()
		if pos.distance_to(rc.get_center()) <= rc.size.x * 0.58:
			_touches[idx] = "wheel"
			_wheel_last = (pos - rc.get_center()).angle()
			return
	for key in _btns:
		var b: Control = _btns[key]
		if b.visible and b.get_global_rect().has_point(pos):
			_touches[idx] = key
			_press(key, true)
			return
	var sz := get_viewport().get_visible_rect().size
	if pos.x < sz.x * 0.45 and pos.y > sz.y * 0.25 and _stick_idx == -1:
		_stick_idx = idx
		_stick_origin = pos
		_touches[idx] = "stick"
		_pad.queue_redraw()
	else:
		_touches[idx] = "look"

func _touch_move(idx: int, pos: Vector2, rel: Vector2) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	if role == "stick":
		move = ((pos - _stick_origin) / 110.0).limit_length(1.0)
		_pad.queue_redraw()
	elif role == "look":
		look += rel
		if rel.y < -24.0 and fishing.state == Fishing.BITE and not _swiped.has(idx):
			_swiped[idx] = true
			strike.emit()
	elif role == "wheel":
		var c: Vector2 = _wheel.get_global_rect().get_center()
		if (pos - c).length() < 30.0:
			return
		var a: float = (pos - c).angle()
		var d: float = wrapf(a - _wheel_last, -PI, PI)
		_wheel_last = a
		_wheel_acc += d
		_wheel.angle += d

func _touch_up(idx: int) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	_touches.erase(idx)
	if role == "stick":
		_stick_idx = -1
		move = Vector2.ZERO
		_pad.queue_redraw()
	elif _btns.has(role):
		_press(role, false)

func _release_all() -> void:
	for idx in _touches.keys():
		_touch_up(idx)
	_touches.clear()
	_swiped.clear()
	move = Vector2.ZERO
	reel_vel = 0.0
	reel_out = 0.0
	_wheel_acc = 0.0

func _press(key: String, down: bool) -> void:
	var b = _btns[key]
	b.held = down
	match key:
		"cast":
			if down:
				cast_down.emit()
			else:
				cast_up.emit()
		"lift":
			if down:
				strike.emit()
		"menu":
			if down:
				_open_menu()
		"shop":
			if down:
				_open_shop()
		"map":
			if down:
				_open_map()
		"bait":
			if down:
				_cycle_bait()
		"rig":
			if down:
				_open_tackle()
		"gb":
			if down:
				fishing.throw_groundbait()

func _cycle_bait() -> void:
	if fishing.state != Fishing.IDLE:
		return
	if str(State.rig["type"]) == "spin":
		State.lure = _next_owned("lure", State.lure, Data.LURES.size())
		return
	var ids: Array = []
	for id in Data.BAITS:
		if int(State.baits.get(id, 0)) > 0:
			ids.append(id)
	if ids.is_empty():
		toast("Наживки нет — купите в магазине")
		return
	var i: int = ids.find(State.bait)
	State.bait = ids[(i + 1) % ids.size()]

func _open_shop() -> void:
	_refresh_shop()
	_open_modal(_shop)

func _refresh_shop() -> void:
	_clear(_shop_list)
	_shop_list.add_child(_lbl("Серебро: %d" % State.silver, 32))
	_shop_list.add_child(_lbl("— Удилища —", 30))
	for cls in Data.CLASS_ORDER:
		var tier: int = int(State.rods.get(cls, -1))
		var cur := "нет" if tier < 0 else str(Data.ROD_CLASSES[cls][tier]["name"])
		_shop_list.add_child(_note("%s: %s" % [Data.CLASS_NAMES[cls], cur]))
		if tier < 2:
			var nx: Dictionary = Data.ROD_CLASSES[cls][tier + 1]
			_shop_list.add_child(_btn("Купить: %s (тест %.1f кг, бросок %d м) — %d" % [nx["name"], float(nx["kg"]), int(nx["range"]), int(nx["price"])], _buy_rod.bind(cls, tier + 1)))
	_shop_list.add_child(_lbl("— Лески —", 30))
	for i in Data.LINES.size():
		var l: Dictionary = Data.LINES[i]
		var txt := "%s (до %.1f кг)" % [l["name"], float(l["kg"])]
		txt += "  [надето]" if State.line == i else ("  — куплено" if i < State.line else "  — %d" % int(l["price"]))
		_shop_list.add_child(_btn(txt, _buy_line.bind(i)))
	_shop_list.add_child(_lbl("— Приманки для спиннинга —", 30))
	for i in Data.LURES.size():
		_shop_list.add_child(_gear_btn("lure", i, Data.LURES[i]))
	_shop_list.add_child(_lbl("— Крючки, поплавки, кормушки —", 30))
	for i in Data.HOOKS.size():
		_shop_list.add_child(_gear_btn("hook", i, Data.HOOKS[i]))
	for i in Data.FLOATS.size():
		_shop_list.add_child(_gear_btn("float", i, Data.FLOATS[i]))
	for i in Data.FEEDERS.size():
		_shop_list.add_child(_gear_btn("feeder", i, Data.FEEDERS[i]))
	_shop_list.add_child(_lbl("— Наживка (упаковка 10 шт) —", 30))
	for id in Data.BAITS:
		var b: Dictionary = Data.BAITS[id]
		_shop_list.add_child(_btn("%s ×10 — %d   (есть: %d)" % [b["name"], int(b["price"]), int(State.baits.get(id, 0))], _buy_bait.bind(id)))
	_shop_list.add_child(_lbl("— Садок: %d рыб —" % State.keepnet.size(), 30))
	_shop_list.add_child(_btn("Продать весь улов: +%d" % _net_value(), _sell))

func _buy_rod(cls: String, i: int) -> void:
	var r: Dictionary = Data.ROD_CLASSES[cls][i]
	if i <= int(State.rods.get(cls, -1)):
		return
	if State.silver < int(r["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(r["price"])
	State.rods[cls] = i
	State.save_game()
	_refresh_shop()

func _buy_line(i: int) -> void:
	var l: Dictionary = Data.LINES[i]
	if i <= State.line:
		return
	if State.silver < int(l["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(l["price"])
	State.line = i
	State.save_game()
	_refresh_shop()

func _buy_bait(id: String) -> void:
	var price: int = int(Data.BAITS[id]["price"])
	if State.silver < price:
		toast("Не хватает серебра")
		return
	State.silver -= price
	State.baits[id] = int(State.baits.get(id, 0)) + 10
	State.save_game()
	_refresh_shop()

func _net_value() -> int:
	var t := 0.0
	for f in State.keepnet:
		var fd: Dictionary = Data.FISH[f["id"]]
		t += float(f["w"]) * float(fd["kg_price"])
	return int(t)

func _sell() -> void:
	if State.keepnet.is_empty():
		toast("Садок пуст")
		return
	var total := _net_value()
	State.silver += total
	State.keepnet = []
	State.save_game()
	toast("Продано: +%d серебра" % total)
	_refresh_shop()

# ---------- карточка улова ----------

func _ellipse(rx: float, ry: float, n: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n)
		pts.append(Vector2(cos(a) * rx, sin(a) * ry))
	return pts

func show_card(fish: Dictionary) -> void:
	_card_fish = fish
	_clear(_card_list)
	var fd: Dictionary = Data.FISH[fish["id"]]
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 150)
	_card_list.add_child(holder)
	_fish_art(holder, fd, Vector2(400, 75), 1.0, true)
	var price: int = int(round(float(fish["w"]) * float(fd["kg_price"])))
	var name_l := _lbl(str(fd["name"]), 44)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(name_l)
	var info := _lbl("%.2f кг   %d см   цена %d" % [float(fish["w"]), int(fish["len"]), price], 32)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(info)
	if float(State.record.get(fish["id"], 0.0)) <= float(fish["w"]) + 0.001:
		var rl := _lbl("★ Ваш рекорд по этому виду!", 28)
		rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_card_list.add_child(rl)
	var lk := _lbl(_fish_likes(fd), 22)
	lk.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lk.custom_minimum_size = Vector2(700, 0)
	_card_list.add_child(lk)
	_card_list.add_child(_btn("В садок", _card_keep))
	_card_list.add_child(_btn("Отпустить", _card_release))
	_open_modal(_card)

func _card_keep() -> void:
	if State.keepnet.size() >= 25:
		toast("Садок полон — продайте улов в магазине")
		return
	State.keepnet.append(_card_fish)
	_close_modal(_card)

func _card_release() -> void:
	toast("Рыба отпущена")
	_close_modal(_card)

# ---------- меню и настройки ----------

func _open_menu() -> void:
	_refresh_menu()
	_open_modal(_menu)

func _refresh_menu() -> void:
	_clear(_menu_list)
	_menu_list.add_child(_btn("Магазин", _menu_shop))
	_menu_list.add_child(_btn("Журнал рыб", _menu_journal))
	_menu_list.add_child(_btn("Звук: %s" % ("выкл" if audio.muted else "вкл"), _toggle_sound))
	_menu_list.add_child(_btn("Графика: %s" % ["Низкая", "Средняя", "Высокая"][_quality], _cycle_quality))
	_menu_list.add_child(_btn("Лимит FPS: %d" % _fps, _cycle_fps))
	_menu_list.add_child(_btn("Чувствительность: %.1f" % sens, _cycle_sens))
	var rec := ""
	for id in Data.FISH:
		if State.record.has(id):
			rec += "%s %.2f кг;  " % [Data.FISH[id]["name"], float(State.record[id])]
	_menu_list.add_child(_note("Рекорды: " + (rec if rec != "" else "пока нет")))
	_menu_list.add_child(_btn("Новая игра (сброс)", _new_game))
	_menu_list.add_child(_btn("Выход", _quit))

func _toggle_sound() -> void:
	audio.set_muted(not audio.muted)
	_refresh_menu()

func _menu_shop() -> void:
	_close_modal(_menu)
	_open_shop()

func _cycle_quality() -> void:
	_quality = (_quality + 1) % 3
	_apply_quality()
	_refresh_menu()

func _cycle_fps() -> void:
	_fps = 30 if _fps == 60 else 60
	_apply_quality()
	_refresh_menu()

func _cycle_sens() -> void:
	var vals := [0.6, 1.0, 1.5, 2.0]
	var i: int = vals.find(sens)
	sens = vals[(i + 1) % vals.size()]
	_refresh_menu()

func _new_game() -> void:
	State.reset()
	State.save_game()
	toast("Новая игра")
	_close_modal(_menu)

func _quit() -> void:
	State.save_game()
	get_tree().quit()

func _apply_quality() -> void:
	var vp := get_viewport()
	match _quality:
		0:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.6
		1:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.85
		_:
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = 1.0
	for s in get_tree().get_nodes_in_group("sun"):
		s.shadow_enabled = _quality >= 2
	Engine.max_fps = _fps

# ---------- рисунок рыбы, описание ----------

func _fish_art(parent: Control, fd: Dictionary, pos: Vector2, sc: float, known: bool) -> void:
	var col := Color(float(fd["col"][0]), float(fd["col"][1]), float(fd["col"][2]))
	if not known:
		col = Color(0.15, 0.15, 0.18)
	var body := Polygon2D.new()
	body.polygon = _ellipse(110.0, 42.0, 28)
	body.color = col
	body.position = pos
	body.scale = Vector2(sc, sc)
	parent.add_child(body)
	var tail := Polygon2D.new()
	tail.polygon = PackedVector2Array([Vector2(-100, 0), Vector2(-165, -42), Vector2(-165, 42)])
	tail.color = col.darkened(0.25)
	body.add_child(tail)
	if known:
		var eye := Polygon2D.new()
		eye.polygon = _ellipse(6.0, 6.0, 8)
		eye.color = Color(0, 0, 0)
		eye.position = Vector2(72, -8)
		body.add_child(eye)

func _fish_likes(fd: Dictionary) -> String:
	var names: Array = []
	for b in fd["baits"]:
		names.append(str(Data.BAITS[b]["name"]))
	var dr: Array = fd["depth"]
	return "Любит: %s. Глубина %.1f–%.1f м. %s" % [", ".join(PackedStringArray(names)), float(dr[0]), float(dr[1]), Data.HOOKS[int(fd["hook"])]["name"]]

# ---------- журнал рыб ----------

func _menu_journal() -> void:
	_close_modal(_menu)
	_refresh_journal()
	_open_modal(_journal)

func _refresh_journal() -> void:
	_clear(_journal_list)
	for id in Data.FISH:
		var fd: Dictionary = Data.FISH[id]
		var n: int = int(State.counts.get(id, 0))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		var art := Control.new()
		art.custom_minimum_size = Vector2(210, 100)
		row.add_child(art)
		_fish_art(art, fd, Vector2(110, 50), 0.6, n > 0)
		var vb := VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(vb)
		if n > 0:
			vb.add_child(_lbl(str(fd["name"]), 30))
			vb.add_child(_lbl("Рекорд %.2f кг, поймано: %d" % [float(State.record.get(id, 0.0)), n], 22))
			var lk := _lbl(_fish_likes(fd), 20)
			lk.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lk.custom_minimum_size = Vector2(480, 0)
			vb.add_child(lk)
		else:
			vb.add_child(_lbl("???", 30))
			vb.add_child(_lbl("Ещё не поймана", 22))
		_journal_list.add_child(row)

# ---------- покупка снастей ----------

func _gear_btn(prefix: String, i: int, item: Dictionary) -> Button:
	var key := "%s%d" % [prefix, i]
	var txt: String = str(item["name"])
	txt += "  — есть" if State.owned.has(key) else "  — %d" % int(item["price"])
	return _btn(txt, _buy_gear.bind(key, int(item["price"])))

func _buy_gear(key: String, price: int) -> void:
	if State.owned.has(key):
		return
	if State.silver < price:
		toast("Не хватает серебра")
		return
	State.silver -= price
	State.owned[key] = true
	State.save_game()
	_refresh_shop()

# ---------- сборка снасти и прикормка ----------

func _open_tackle() -> void:
	if fishing.state != Fishing.IDLE:
		toast("Сначала смотай снасть")
		return
	_refresh_tackle()
	_open_modal(_tackle)

func _note(text: String) -> Label:
	var l := _lbl(text, 24)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(700, 0)
	return l

func _refresh_tackle() -> void:
	_clear(_tackle_list)
	var rg: Dictionary = State.rig
	var feeder: bool = rg["type"] == "feeder"
	var rod: Dictionary = Data.cur_rod()
	_tackle_list.add_child(_btn("Тип ловли: %s" % Data.CLASS_NAMES[str(rg["type"])], _t_type))
	_tackle_list.add_child(_note("Удилище: %s (тест до %.1f кг, бросок %d м)" % [rod["name"], float(rod["kg"]), int(rod["range"])]))
	if rg["type"] == "spin":
		_tackle_list.add_child(_btn("Приманка: %s" % Data.LURES[State.lure]["name"], _t_lure))
		_tackle_list.add_child(_note("Блесна и воблер ходят у поверхности, джиг — у дна. Темп проводки задаёшь колесом: слишком быстро или медленно — хищник игнорирует."))
		return
	_tackle_list.add_child(_btn("Крючок: %s" % Data.HOOKS[int(rg["hook"])]["name"], _t_hook))
	var info := ""
	if feeder:
		var fw: int = int(Data.FEEDERS[int(rg["feeder"])]["w"])
		_tackle_list.add_child(_btn("Кормушка: %s" % Data.FEEDERS[int(rg["feeder"])]["name"], _t_feeder))
		info = "Кормушка %d г, удилище бросает до %d г." % [fw, int(rod["cast"])]
		if fw > int(rod["cast"]):
			info += " СЛИШКОМ ТЯЖЁЛАЯ — заброс невозможен."
		else:
			info += " Каждый заброс с прикормкой кормит точку ≈5 минут."
	else:
		var cap: int = int(Data.FLOATS[int(rg["float"])]["cap"])
		var sk: int = int(Data.SINKERS[int(rg["sinker"])])
		_tackle_list.add_child(_btn("Поплавок: %s" % Data.FLOATS[int(rg["float"])]["name"], _t_float))
		_tackle_list.add_child(_btn("Грузило: %d г" % sk, _t_sinker))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var bm := _btn("−", _t_depth.bind(-0.25))
		bm.custom_minimum_size = Vector2(120, 72)
		var lb := _lbl("Глубина: %.2f м" % float(rg["fdepth"]), 30)
		lb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var bp := _btn("+", _t_depth.bind(0.25))
		bp.custom_minimum_size = Vector2(120, 72)
		row.add_child(bm)
		row.add_child(lb)
		row.add_child(bp)
		_tackle_list.add_child(row)
		info = "Поплавок %d г, грузило %d г." % [cap, sk]
		if float(sk) < cap * 0.6:
			info += " Грузила мало — поплавок плавает высоко."
		elif sk > cap:
			info += " Грузило тяжёлое — поплавок тонет, поклёвку видно хуже."
		else:
			info += " Снасть сбалансирована."
		info += " Глубину ставь чуть меньше глубины воды."
	_tackle_list.add_child(_note(info))
	var gs: Dictionary = State.gb_sel
	_tackle_list.add_child(_lbl("— Прикормка (порций: %d) —" % State.gb_portions, 30))
	_tackle_list.add_child(_btn("Основа: %s" % Data.GB_BASES[gs["base"]]["name"], _t_gb.bind("base")))
	_tackle_list.add_child(_btn("Запах: %s" % Data.GB_FLAVORS[gs["flavor"]]["name"], _t_gb.bind("flavor")))
	_tackle_list.add_child(_btn("Добавка: %s" % Data.GB_ADDS[gs["add"]]["name"], _t_gb.bind("add")))
	var likes := ""
	for id in Data.FISH:
		var e: float = Data.gb_effect(id, gs)
		if e >= 1.5:
			likes += "%s ×%.1f;  " % [Data.FISH[id]["name"], e]
	_tackle_list.add_child(_note("Привлекает: " + (likes if likes != "" else "всех слабо")))
	_tackle_list.add_child(_btn("Замесить 10 порций — %d" % _gb_price(), _gb_make))
	_tackle_list.add_child(_note("Кнопка ПРИКОРМКА на экране бросает порцию в воду перед собой."))

func _t_done() -> void:
	State.save_game()
	_refresh_tackle()

func _next_owned(prefix: String, cur: int, count: int) -> int:
	for i in range(1, count + 1):
		var j: int = (cur + i) % count
		if State.owned.has("%s%d" % [prefix, j]):
			return j
	return cur

func _t_type() -> void:
	var order: Array = Data.CLASS_ORDER
	var i: int = order.find(str(State.rig["type"]))
	for step in range(1, order.size() + 1):
		var c: String = order[(i + step) % order.size()]
		if int(State.rods.get(c, -1)) >= 0:
			State.rig["type"] = c
			break
	_t_done()

func _t_lure() -> void:
	State.lure = _next_owned("lure", State.lure, Data.LURES.size())
	_t_done()

func _t_hook() -> void:
	State.rig["hook"] = _next_owned("hook", int(State.rig["hook"]), Data.HOOKS.size())
	_t_done()

func _t_feeder() -> void:
	State.rig["feeder"] = _next_owned("feeder", int(State.rig["feeder"]), Data.FEEDERS.size())
	_t_done()

func _t_float() -> void:
	State.rig["float"] = _next_owned("float", int(State.rig["float"]), Data.FLOATS.size())
	_t_done()

func _t_sinker() -> void:
	State.rig["sinker"] = (int(State.rig["sinker"]) + 1) % Data.SINKERS.size()
	_t_done()

func _t_depth(d: float) -> void:
	State.rig["fdepth"] = clampf(float(State.rig["fdepth"]) + d, 0.5, 6.0)
	_t_done()

func _t_gb(which: String) -> void:
	var tbl: Dictionary = Data.GB_BASES
	if which == "flavor":
		tbl = Data.GB_FLAVORS
	elif which == "add":
		tbl = Data.GB_ADDS
	var keys: Array = tbl.keys()
	var i: int = keys.find(State.gb_sel[which])
	State.gb_sel[which] = keys[(i + 1) % keys.size()]
	_t_done()

func _gb_price() -> int:
	var gs: Dictionary = State.gb_sel
	return int(Data.GB_BASES[gs["base"]]["price"]) + int(Data.GB_FLAVORS[gs["flavor"]]["price"]) + int(Data.GB_ADDS[gs["add"]]["price"])

func _gb_make() -> void:
	var p := _gb_price()
	if State.silver < p:
		toast("Не хватает серебра")
		return
	State.silver -= p
	State.gb_mix = State.gb_sel.duplicate()
	State.gb_portions = 10
	toast("Прикормка готова: 10 порций")
	_t_done()

# ---------- карта (автобус) ----------

func _open_map() -> void:
	if fishing.state != Fishing.IDLE:
		toast("Сначала смотай снасть")
		return
	_clear(_map_list)
	for id in Data.LOCS:
		var L: Dictionary = Data.LOCS[id]
		var ok: bool = State.level() >= int(L["lvl"])
		var txt := "%s — нужен ур. %d" % [L["name"], int(L["lvl"])]
		if id == world.loc_id:
			txt += "  (вы здесь)"
		elif not ok:
			txt += "  — закрыто"
		var b := _btn(txt, _go_loc.bind(id))
		b.disabled = (not ok) or id == world.loc_id
		_map_list.add_child(b)
	_open_modal(_map)

func _go_loc(id: String) -> void:
	_close_modal(_map)
	world.travel(id)
	toast("Вы приехали: %s" % str(Data.LOCS[id]["name"]))
