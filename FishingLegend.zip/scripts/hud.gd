extends CanvasLayer
# Интерфейс: сенсорное управление, кнопки, магазин, карточка улова, меню

const Data = preload("res://scripts/data.gd")
const Fishing = preload("res://scripts/fishing.gd")

signal strike
signal cast_down
signal cast_up

var move: Vector2 = Vector2.ZERO
var look: Vector2 = Vector2.ZERO
var reel_held: bool = false
var sens: float = 1.0
var modal_open: bool = false
var hour: float = 7.0
var fishing

var _btns: Dictionary = {}
var _touches: Dictionary = {}
var _pad: Control
var _stick_origin: Vector2 = Vector2.ZERO
var _stick_idx: int = -1
var _status: Label
var _hint: Label
var _toast: Label
var _toast_t: float = 0.0
var _power: ProgressBar
var _tension: ProgressBar
var _shop: ColorRect
var _shop_list: VBoxContainer
var _card: ColorRect
var _card_list: VBoxContainer
var _menu: ColorRect
var _menu_list: VBoxContainer
var _card_fish: Dictionary = {}
var _near_shop: bool = false
var _quality: int = 1
var _fps: int = 60

func _ready() -> void:
	layer = 10
	_pad = Control.new()
	_pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_pad)
	_pad.set_anchors_preset(Control.PRESET_FULL_RECT)
	_pad.draw.connect(_draw_pad)

	_btns["cast"] = _mk_btn("ЗАБРОС", true, true, 30, 40, 170, 170, 30)
	_btns["reel"] = _mk_btn("ВЫВОДИ", true, true, 45, 230, 140, 140, 24)
	_btns["strike"] = _mk_btn("ПОДСЕЧКА", true, true, 230, 40, 150, 150, 24)
	_btns["menu"] = _mk_btn("МЕНЮ", true, false, 20, 20, 130, 64, 26)
	_btns["shop"] = _mk_btn("МАГАЗИН", true, false, 20, 100, 190, 64, 26)
	_btns["bait"] = _mk_btn("Наживка", false, false, 20, 80, 400, 60, 26)

	_status = _lbl("", 28)
	add_child(_status)
	_place(_status, 0, 0, 0, 0, 20, 16, 700, 60)
	_toast = _lbl("", 34)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_toast)
	_place(_toast, 0.2, 0, 0.8, 0, 0, 160, 0, 230)
	_hint = _lbl("", 26)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_hint)
	_place(_hint, 0.2, 1, 0.8, 1, 0, -125, 0, -60)
	_power = ProgressBar.new()
	_tension = ProgressBar.new()
	for pb in [_power, _tension]:
		pb.max_value = 1.0
		pb.step = 0.001
		pb.show_percentage = false
		add_child(pb)
		_place(pb, 0.25, 1, 0.75, 1, 0, -175, 0, -140)

	var m := _make_modal("Магазин", true)
	_shop = m[0]
	_shop_list = m[1]
	m = _make_modal("Улов", false)
	_card = m[0]
	_card_list = m[1]
	m = _make_modal("Меню", true)
	_menu = m[0]
	_menu_list = m[1]

func setup(f) -> void:
	fishing = f
	cast_down.connect(f.press_cast)
	cast_up.connect(f.release_cast)
	strike.connect(f.strike)
	f.msg.connect(toast)
	f.caught.connect(show_card)
	_apply_quality()

func set_shop_near(v: bool) -> void:
	_near_shop = v

func toast(text: String) -> void:
	_toast.text = text
	_toast_t = 3.0

# ---------- построение элементов ----------

func _place(c: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, orr: float, ob: float) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = orr
	c.offset_bottom = ob

func _mk_btn(text: String, right: bool, bottom: bool, mx: float, my: float, w: float, h: float, fs: int) -> Button:
	var b := Button.new()
	b.text = text
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", fs)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.15, 0.2, 0.55)
	sb.set_corner_radius_all(int(minf(w, h) * 0.5))
	sb.border_color = Color(1, 1, 1, 0.5)
	sb.set_border_width_all(3)
	b.add_theme_stylebox_override("normal", sb)
	add_child(b)
	var ax: float = 1.0 if right else 0.0
	var ay: float = 1.0 if bottom else 0.0
	_place(b, ax, ay, ax, ay, -(mx + w) if right else mx, -(my + h) if bottom else my, -mx if right else mx + w, -my if bottom else my + h)
	return b

func _lbl(text: String, fs: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 6)
	return l

func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(cb)
	return b

func _make_modal(title: String, closable: bool) -> Array:
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.6)
	root.visible = false
	add_child(root)
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	root.add_child(center)
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(820, 580)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	var t := _lbl(title, 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	sc.add_child(list)
	if closable:
		vb.add_child(_btn("Закрыть", _close_modal.bind(root)))
	return [root, list]

func _clear(list: Control) -> void:
	for c in list.get_children():
		list.remove_child(c)
		c.queue_free()

func _open_modal(m: Control) -> void:
	_release_all()
	modal_open = true
	m.visible = true

func _close_modal(m: Control) -> void:
	m.visible = false
	modal_open = _shop.visible or _card.visible or _menu.visible
	State.save_game()

# ---------- кадр ----------

func _process(delta: float) -> void:
	if fishing == null:
		return
	var st: int = fishing.state
	_power.visible = st == Fishing.CHARGE
	_tension.visible = st == Fishing.FIGHT
	_power.value = fishing.power
	_tension.value = clampf(fishing.tension, 0.0, 1.0)
	_tension.modulate = Color(1.0, 0.4, 0.3) if fishing.tension > 0.8 else Color(1, 1, 1)
	_btns["shop"].visible = _near_shop and not modal_open
	var hint := ""
	match st:
		Fishing.IDLE:
			hint = "Удерживай ЗАБРОС — сила, отпусти — бросок"
		Fishing.CHARGE:
			hint = "Отпусти, когда сила нужная"
		Fishing.WAIT:
			hint = "Ждём поклёвку… глубина %.1f м" % fishing.depth
		Fishing.BITE:
			hint = "ПОКЛЁВКА! Жми ПОДСЕЧКА!"
		Fishing.FIGHT:
			hint = "Рывок — отпусти ВЫВОДИ. Спокойно — выводи!   %.0f м" % fishing.dist
		Fishing.RETRIEVE:
			hint = "Выбираем леску…"
	_hint.text = hint
	var bn: String = State.bait
	var bname: String = str(Data.BAITS[bn]["name"]) if Data.BAITS.has(bn) else "—"
	_btns["bait"].text = "Наживка: %s (%d)" % [bname, int(State.baits.get(bn, 0))]
	_status.text = "Серебро %d   Ур. %d   %02d:%02d" % [State.silver, State.level(), int(hour), int((hour - floorf(hour)) * 60.0)]
	_toast_t -= delta
	_toast.modulate = Color(1, 1, 1, clampf(_toast_t, 0.0, 1.0))

func _draw_pad() -> void:
	if _stick_idx != -1:
		_pad.draw_circle(_stick_origin, 110.0, Color(1, 1, 1, 0.12))
		_pad.draw_arc(_stick_origin, 110.0, 0.0, TAU, 40, Color(1, 1, 1, 0.4), 3.0)
		_pad.draw_circle(_stick_origin + move * 110.0, 42.0, Color(1, 1, 1, 0.45))

# ---------- сенсорный ввод ----------

func _input(event: InputEvent) -> void:
	if modal_open:
		return
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_touch_down(e.index, e.position)
		else:
			_touch_up(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_move(d.index, d.position, d.relative)

func _touch_down(idx: int, pos: Vector2) -> void:
	for key in _btns:
		var b: Button = _btns[key]
		if b.visible and b.get_global_rect().has_point(pos):
			_touches[idx] = key
			_press(key, true)
			return
	var sz := get_viewport().get_visible_rect().size
	if pos.x < sz.x * 0.45 and pos.y > sz.y * 0.25 and _stick_idx == -1:
		_stick_idx = idx
		_stick_origin = pos
		_touches[idx] = "stick"
		_pad.queue_redraw()
	else:
		_touches[idx] = "look"

func _touch_move(idx: int, pos: Vector2, rel: Vector2) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	if role == "stick":
		move = ((pos - _stick_origin) / 110.0).limit_length(1.0)
		_pad.queue_redraw()
	elif role == "look":
		look += rel

func _touch_up(idx: int) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	_touches.erase(idx)
	if role == "stick":
		_stick_idx = -1
		move = Vector2.ZERO
		_pad.queue_redraw()
	elif _btns.has(role):
		_press(role, false)

func _release_all() -> void:
	for idx in _touches.keys():
		_touch_up(idx)
	_touches.clear()
	move = Vector2.ZERO
	reel_held = false

func _press(key: String, down: bool) -> void:
	var b: Button = _btns[key]
	b.modulate = Color(0.6, 0.6, 0.6) if down else Color(1, 1, 1)
	match key:
		"cast":
			if down:
				cast_down.emit()
			else:
				cast_up.emit()
		"reel":
			reel_held = down
		"strike":
			if down:
				strike.emit()
		"menu":
			if down:
				_open_menu()
		"shop":
			if down:
				_open_shop()
		"bait":
			if down:
				_cycle_bait()

func _cycle_bait() -> void:
	if fishing.state != Fishing.IDLE:
		return
	var ids: Array = []
	for id in Data.BAITS:
		if int(State.baits.get(id, 0)) > 0:
			ids.append(id)
	if ids.is_empty():
		toast("Наживки нет — купите в магазине")
		return
	var i: int = ids.find(State.bait)
	State.bait = ids[(i + 1) % ids.size()]

# ---------- магазин ----------

func _open_shop() -> void:
	_refresh_shop()
	_open_modal(_shop)

func _refresh_shop() -> void:
	_clear(_shop_list)
	_shop_list.add_child(_lbl("Серебро: %d" % State.silver, 32))
	_shop_list.add_child(_lbl("— Удилища —", 30))
	for i in Data.RODS.size():
		var r: Dictionary = Data.RODS[i]
		var txt := "%s (дальность %d м, до %.1f кг)" % [r["name"], int(r["range"]), float(r["kg"])]
		txt += "  [надето]" if State.rod == i else ("  — куплено" if i < State.rod else "  — %d" % int(r["price"]))
		_shop_list.add_child(_btn(txt, _buy_rod.bind(i)))
	_shop_list.add_child(_lbl("— Лески —", 30))
	for i in Data.LINES.size():
		var l: Dictionary = Data.LINES[i]
		var txt := "%s (до %.1f кг)" % [l["name"], float(l["kg"])]
		txt += "  [надето]" if State.line == i else ("  — куплено" if i < State.line else "  — %d" % int(l["price"]))
		_shop_list.add_child(_btn(txt, _buy_line.bind(i)))
	_shop_list.add_child(_lbl("— Наживка (упаковка 10 шт) —", 30))
	for id in Data.BAITS:
		var b: Dictionary = Data.BAITS[id]
		_shop_list.add_child(_btn("%s ×10 — %d   (есть: %d)" % [b["name"], int(b["price"]), int(State.baits.get(id, 0))], _buy_bait.bind(id)))
	_shop_list.add_child(_lbl("— Садок: %d рыб —" % State.keepnet.size(), 30))
	_shop_list.add_child(_btn("Продать весь улов: +%d" % _net_value(), _sell))

func _buy_rod(i: int) -> void:
	var r: Dictionary = Data.RODS[i]
	if i <= State.rod:
		return
	if State.silver < int(r["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(r["price"])
	State.rod = i
	State.save_game()
	_refresh_shop()

func _buy_line(i: int) -> void:
	var l: Dictionary = Data.LINES[i]
	if i <= State.line:
		return
	if State.silver < int(l["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(l["price"])
	State.line = i
	State.save_game()
	_refresh_shop()

func _buy_bait(id: String) -> void:
	var price: int = int(Data.BAITS[id]["price"])
	if State.silver < price:
		toast("Не хватает серебра")
		return
	State.silver -= price
	State.baits[id] = int(State.baits.get(id, 0)) + 10
	State.save_game()
	_refresh_shop()

func _net_value() -> int:
	var t := 0.0
	for f in State.keepnet:
		var fd: Dictionary = Data.FISH[f["id"]]
		t += float(f["w"]) * float(fd["kg_price"])
	return int(t)

func _sell() -> void:
	if State.keepnet.is_empty():
		toast("Садок пуст")
		return
	var total := _net_value()
	State.silver += total
	State.keepnet = []
	State.save_game()
	toast("Продано: +%d серебра" % total)
	_refresh_shop()

# ---------- карточка улова ----------

func _ellipse(rx: float, ry: float, n: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n)
		pts.append(Vector2(cos(a) * rx, sin(a) * ry))
	return pts

func show_card(fish: Dictionary) -> void:
	_card_fish = fish
	_clear(_card_list)
	var fd: Dictionary = Data.FISH[fish["id"]]
	var col := Color(float(fd["col"][0]), float(fd["col"][1]), float(fd["col"][2]))
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 150)
	_card_list.add_child(holder)
	var body := Polygon2D.new()
	body.polygon = _ellipse(110.0, 42.0, 28)
	body.color = col
	body.position = Vector2(400, 75)
	holder.add_child(body)
	var tail := Polygon2D.new()
	tail.polygon = PackedVector2Array([Vector2(-100, 0), Vector2(-165, -42), Vector2(-165, 42)])
	tail.color = col.darkened(0.25)
	body.add_child(tail)
	var eye := Polygon2D.new()
	eye.polygon = _ellipse(6.0, 6.0, 8)
	eye.color = Color(0, 0, 0)
	eye.position = Vector2(72, -8)
	body.add_child(eye)
	var price: int = int(round(float(fish["w"]) * float(fd["kg_price"])))
	var name_l := _lbl(str(fd["name"]), 44)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(name_l)
	var info := _lbl("%.2f кг   %d см   цена %d" % [float(fish["w"]), int(fish["len"]), price], 32)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(info)
	_card_list.add_child(_btn("В садок", _card_keep))
	_card_list.add_child(_btn("Отпустить", _card_release))
	_open_modal(_card)

func _card_keep() -> void:
	if State.keepnet.size() >= 25:
		toast("Садок полон — продайте улов в магазине")
		return
	State.keepnet.append(_card_fish)
	_close_modal(_card)

func _card_release() -> void:
	toast("Рыба отпущена")
	_close_modal(_card)

# ---------- меню и настройки ----------

func _open_menu() -> void:
	_refresh_menu()
	_open_modal(_menu)

func _refresh_menu() -> void:
	_clear(_menu_list)
	_menu_list.add_child(_btn("Магазин", _menu_shop))
	_menu_list.add_child(_btn("Графика: %s" % ["Низкая", "Средняя", "Высокая"][_quality], _cycle_quality))
	_menu_list.add_child(_btn("Лимит FPS: %d" % _fps, _cycle_fps))
	_menu_list.add_child(_btn("Чувствительность: %.1f" % sens, _cycle_sens))
	var rec := ""
	for id in Data.FISH:
		if State.record.has(id):
			rec += "%s %.2f кг;  " % [Data.FISH[id]["name"], float(State.record[id])]
	var rl := _lbl("Рекорды: " + (rec if rec != "" else "пока нет"), 24)
	rl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rl.custom_minimum_size = Vector2(700, 0)
	_menu_list.add_child(rl)
	_menu_list.add_child(_btn("Новая игра (сброс)", _new_game))
	_menu_list.add_child(_btn("Выход", _quit))

func _menu_shop() -> void:
	_close_modal(_menu)
	_open_shop()

func _cycle_quality() -> void:
	_quality = (_quality + 1) % 3
	_apply_quality()
	_refresh_menu()

func _cycle_fps() -> void:
	_fps = 30 if _fps == 60 else 60
	_apply_quality()
	_refresh_menu()

func _cycle_sens() -> void:
	var vals := [0.6, 1.0, 1.5, 2.0]
	var i: int = vals.find(sens)
	sens = vals[(i + 1) % vals.size()]
	_refresh_menu()

func _new_game() -> void:
	State.reset()
	State.save_game()
	toast("Новая игра")
	_close_modal(_menu)

func _quit() -> void:
	State.save_game()
	get_tree().quit()

func _apply_quality() -> void:
	var vp := get_viewport()
	match _quality:
		0:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.6
		1:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.85
		_:
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = 1.0
	for s in get_tree().get_nodes_in_group("sun"):
		s.shadow_enabled = _quality >= 2
	Engine.max_fps = _fps
