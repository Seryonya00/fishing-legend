extends CanvasLayer
# Интерфейс: сенсорное управление, кнопки, магазин, карточка улова, меню

const Data = preload("res://scripts/data.gd")
const Fishing = preload("res://scripts/fishing.gd")

signal strike
signal cast_down
signal cast_up

var move: Vector2 = Vector2.ZERO
var look: Vector2 = Vector2.ZERO
var reel_held: bool = false
var sens: float = 1.0
var modal_open: bool = false
var hour: float = 7.0
var fishing

var _btns: Dictionary = {}
var _touches: Dictionary = {}
var _pad: Control
var _stick_origin: Vector2 = Vector2.ZERO
var _stick_idx: int = -1
var _status: Label
var _hint: Label
var _toast: Label
var _toast_t: float = 0.0
var _power: ProgressBar
var _tension: ProgressBar
var _shop: ColorRect
var _shop_list: VBoxContainer
var _card: ColorRect
var _card_list: VBoxContainer
var _menu: ColorRect
var _menu_list: VBoxContainer
var _tackle: ColorRect
var _tackle_list: VBoxContainer
var _journal: ColorRect
var _journal_list: VBoxContainer
var _card_fish: Dictionary = {}
var _near_shop: bool = false
var _quality: int = 1
var _fps: int = 60

func _ready() -> void:
	layer = 10
	_pad = Control.new()
	_pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_pad)
	_pad.set_anchors_preset(Control.PRESET_FULL_RECT)
	_pad.draw.connect(_draw_pad)

	_btns["cast"] = _mk_btn("ЗАБРОС", true, true, 30, 40, 170, 170, 30)
	_btns["reel"] = _mk_btn("ВЫВОДИ", true, true, 45, 230, 140, 140, 24)
	_btns["strike"] = _mk_btn("ПОДСЕЧКА", true, true, 230, 40, 150, 150, 24)
	_btns["menu"] = _mk_btn("МЕНЮ", true, false, 20, 20, 130, 64, 26)
	_btns["shop"] = _mk_btn("МАГАЗИН", true, false, 20, 100, 190, 64, 26)
	_btns["bait"] = _mk_btn("Наживка", false, false, 20, 80, 400, 60, 26)
	_btns["rig"] = _mk_btn("СНАСТЬ", false, false, 20, 150, 200, 60, 26)
	_btns["gb"] = _mk_btn("ПРИКОРМКА", true, true, 410, 40, 140, 140, 20)

	_status = _lbl("", 28)
	add_child(_status)
	_place(_status, 0, 0, 0, 0, 20, 16, 700, 60)
	_toast = _lbl("", 34)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_toast)
	_place(_toast, 0.2, 0, 0.8, 0, 0, 160, 0, 230)
	_hint = _lbl("", 26)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_hint)
	_place(_hint, 0.2, 1, 0.8, 1, 0, -125, 0, -60)
	_power = ProgressBar.new()
	_tension = ProgressBar.new()
	for pb in [_power, _tension]:
		pb.max_value = 1.0
		pb.step = 0.001
		pb.show_percentage = false
		add_child(pb)
		_place(pb, 0.25, 1, 0.75, 1, 0, -175, 0, -140)

	var m := _make_modal("Магазин", true)
	_shop = m[0]
	_shop_list = m[1]
	m = _make_modal("Улов", false)
	_card = m[0]
	_card_list = m[1]
	m = _make_modal("Меню", true)
	_menu = m[0]
	_menu_list = m[1]
	m = _make_modal("Снасть и прикормка", true)
	_tackle = m[0]
	_tackle_list = m[1]
	m = _make_modal("Журнал рыб", true)
	_journal = m[0]
	_journal_list = m[1]

func setup(f) -> void:
	fishing = f
	cast_down.connect(f.press_cast)
	cast_up.connect(f.release_cast)
	strike.connect(f.strike)
	f.msg.connect(toast)
	f.caught.connect(show_card)
	_apply_quality()

func set_shop_near(v: bool) -> void:
	_near_shop = v

func toast(text: String) -> void:
	_toast.text = text
	_toast_t = 3.0

# ---------- построение элементов ----------

func _place(c: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, orr: float, ob: float) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = orr
	c.offset_bottom = ob

func _mk_btn(text: String, right: bool, bottom: bool, mx: float, my: float, w: float, h: float, fs: int) -> Button:
	var b := Button.new()
	b.text = text
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", fs)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.15, 0.2, 0.55)
	sb.set_corner_radius_all(int(minf(w, h) * 0.5))
	sb.border_color = Color(1, 1, 1, 0.5)
	sb.set_border_width_all(3)
	b.add_theme_stylebox_override("normal", sb)
	add_child(b)
	var ax: float = 1.0 if right else 0.0
	var ay: float = 1.0 if bottom else 0.0
	_place(b, ax, ay, ax, ay, -(mx + w) if right else mx, -(my + h) if bottom else my, -mx if right else mx + w, -my if bottom else my + h)
	return b

func _lbl(text: String, fs: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 6)
	return l

func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(cb)
	return b

func _make_modal(title: String, closable: bool) -> Array:
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.6)
	root.visible = false
	add_child(root)
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	root.add_child(center)
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(820, 580)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	var t := _lbl(title, 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	sc.add_child(list)
	if closable:
		vb.add_child(_btn("Закрыть", _close_modal.bind(root)))
	return [root, list]

func _clear(list: Control) -> void:
	for c in list.get_children():
		list.remove_child(c)
		c.queue_free()

func _open_modal(m: Control) -> void:
	_release_all()
	modal_open = true
	m.visible = true

func _close_modal(m: Control) -> void:
	m.visible = false
	modal_open = _shop.visible or _card.visible or _menu.visible or _tackle.visible or _journal.visible
	State.save_game()

# ---------- кадр ----------

func _process(delta: float) -> void:
	if fishing == null:
		return
	var st: int = fishing.state
	_power.visible = st == Fishing.CHARGE
	_tension.visible = st == Fishing.FIGHT
	_power.value = fishing.power
	_tension.value = clampf(fishing.tension, 0.0, 1.0)
	_tension.modulate = Color(1.0, 0.4, 0.3) if fishing.tension > 0.8 else Color(1, 1, 1)
	_btns["shop"].visible = _near_shop and not modal_open
	var hint := ""
	match st:
		Fishing.IDLE:
			hint = "Удерживай ЗАБРОС — сила, отпусти — бросок"
		Fishing.CHARGE:
			hint = "Отпусти, когда сила нужная"
		Fishing.WAIT:
			hint = "Ждём поклёвку… глубина %.1f м" % fishing.depth
		Fishing.BITE:
			hint = "ПОКЛЁВКА! Жми ПОДСЕЧКА!"
		Fishing.FIGHT:
			hint = "Рывок — отпусти ВЫВОДИ. Спокойно — выводи!   %.0f м" % fishing.dist
		Fishing.RETRIEVE:
			hint = "Выбираем леску…"
	_hint.text = hint
	var bn: String = State.bait
	var bname: String = str(Data.BAITS[bn]["name"]) if Data.BAITS.has(bn) else "—"
	_btns["bait"].text = "Наживка: %s (%d)" % [bname, int(State.baits.get(bn, 0))]
	_status.text = "Серебро %d   Ур. %d   %02d:%02d   Прикормка: %d" % [State.silver, State.level(), int(hour), int((hour - floorf(hour)) * 60.0), State.gb_portions]
	_toast_t -= delta
	_toast.modulate = Color(1, 1, 1, clampf(_toast_t, 0.0, 1.0))

func _draw_pad() -> void:
	if _stick_idx != -1:
		_pad.draw_circle(_stick_origin, 110.0, Color(1, 1, 1, 0.12))
		_pad.draw_arc(_stick_origin, 110.0, 0.0, TAU, 40, Color(1, 1, 1, 0.4), 3.0)
		_pad.draw_circle(_stick_origin + move * 110.0, 42.0, Color(1, 1, 1, 0.45))

# ---------- сенсорный ввод ----------

func _input(event: InputEvent) -> void:
	if modal_open:
		return
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_touch_down(e.index, e.position)
		else:
			_touch_up(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_move(d.index, d.position, d.relative)

func _touch_down(idx: int, pos: Vector2) -> void:
	for key in _btns:
		var b: Button = _btns[key]
		if b.visible and b.get_global_rect().has_point(pos):
			_touches[idx] = key
			_press(key, true)
			return
	var sz := get_viewport().get_visible_rect().size
	if pos.x < sz.x * 0.45 and pos.y > sz.y * 0.25 and _stick_idx == -1:
		_stick_idx = idx
		_stick_origin = pos
		_touches[idx] = "stick"
		_pad.queue_redraw()
	else:
		_touches[idx] = "look"

func _touch_move(idx: int, pos: Vector2, rel: Vector2) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	if role == "stick":
		move = ((pos - _stick_origin) / 110.0).limit_length(1.0)
		_pad.queue_redraw()
	elif role == "look":
		look += rel

func _touch_up(idx: int) -> void:
	if not _touches.has(idx):
		return
	var role: String = _touches[idx]
	_touches.erase(idx)
	if role == "stick":
		_stick_idx = -1
		move = Vector2.ZERO
		_pad.queue_redraw()
	elif _btns.has(role):
		_press(role, false)

func _release_all() -> void:
	for idx in _touches.keys():
		_touch_up(idx)
	_touches.clear()
	move = Vector2.ZERO
	reel_held = false

func _press(key: String, down: bool) -> void:
	var b: Button = _btns[key]
	b.modulate = Color(0.6, 0.6, 0.6) if down else Color(1, 1, 1)
	match key:
		"cast":
			if down:
				cast_down.emit()
			else:
				cast_up.emit()
		"reel":
			reel_held = down
		"strike":
			if down:
				strike.emit()
		"menu":
			if down:
				_open_menu()
		"shop":
			if down:
				_open_shop()
		"bait":
			if down:
				_cycle_bait()
		"rig":
			if down:
				_open_tackle()
		"gb":
			if down:
				fishing.throw_groundbait()

func _cycle_bait() -> void:
	if fishing.state != Fishing.IDLE:
		return
	var ids: Array = []
	for id in Data.BAITS:
		if int(State.baits.get(id, 0)) > 0:
			ids.append(id)
	if ids.is_empty():
		toast("Наживки нет — купите в магазине")
		return
	var i: int = ids.find(State.bait)
	State.bait = ids[(i + 1) % ids.size()]

# ---------- магазин ----------

func _open_shop() -> void:
	_refresh_shop()
	_open_modal(_shop)

func _refresh_shop() -> void:
	_clear(_shop_list)
	_shop_list.add_child(_lbl("Серебро: %d" % State.silver, 32))
	_shop_list.add_child(_lbl("— Удилища —", 30))
	for i in Data.RODS.size():
		var r: Dictionary = Data.RODS[i]
		var txt := "%s (дальность %d м, до %.1f кг)" % [r["name"], int(r["range"]), float(r["kg"])]
		txt += "  [надето]" if State.rod == i else ("  — куплено" if i < State.rod else "  — %d" % int(r["price"]))
		_shop_list.add_child(_btn(txt, _buy_rod.bind(i)))
	_shop_list.add_child(_lbl("— Лески —", 30))
	for i in Data.LINES.size():
		var l: Dictionary = Data.LINES[i]
		var txt := "%s (до %.1f кг)" % [l["name"], float(l["kg"])]
		txt += "  [надето]" if State.line == i else ("  — куплено" if i < State.line else "  — %d" % int(l["price"]))
		_shop_list.add_child(_btn(txt, _buy_line.bind(i)))
	_shop_list.add_child(_lbl("— Крючки, поплавки, кормушки —", 30))
	for i in Data.HOOKS.size():
		_shop_list.add_child(_gear_btn("hook", i, Data.HOOKS[i]))
	for i in Data.FLOATS.size():
		_shop_list.add_child(_gear_btn("float", i, Data.FLOATS[i]))
	for i in Data.FEEDERS.size():
		_shop_list.add_child(_gear_btn("feeder", i, Data.FEEDERS[i]))
	_shop_list.add_child(_lbl("— Наживка (упаковка 10 шт) —", 30))
	for id in Data.BAITS:
		var b: Dictionary = Data.BAITS[id]
		_shop_list.add_child(_btn("%s ×10 — %d   (есть: %d)" % [b["name"], int(b["price"]), int(State.baits.get(id, 0))], _buy_bait.bind(id)))
	_shop_list.add_child(_lbl("— Садок: %d рыб —" % State.keepnet.size(), 30))
	_shop_list.add_child(_btn("Продать весь улов: +%d" % _net_value(), _sell))

func _buy_rod(i: int) -> void:
	var r: Dictionary = Data.RODS[i]
	if i <= State.rod:
		return
	if State.silver < int(r["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(r["price"])
	State.rod = i
	State.save_game()
	_refresh_shop()

func _buy_line(i: int) -> void:
	var l: Dictionary = Data.LINES[i]
	if i <= State.line:
		return
	if State.silver < int(l["price"]):
		toast("Не хватает серебра")
		return
	State.silver -= int(l["price"])
	State.line = i
	State.save_game()
	_refresh_shop()

func _buy_bait(id: String) -> void:
	var price: int = int(Data.BAITS[id]["price"])
	if State.silver < price:
		toast("Не хватает серебра")
		return
	State.silver -= price
	State.baits[id] = int(State.baits.get(id, 0)) + 10
	State.save_game()
	_refresh_shop()

func _net_value() -> int:
	var t := 0.0
	for f in State.keepnet:
		var fd: Dictionary = Data.FISH[f["id"]]
		t += float(f["w"]) * float(fd["kg_price"])
	return int(t)

func _sell() -> void:
	if State.keepnet.is_empty():
		toast("Садок пуст")
		return
	var total := _net_value()
	State.silver += total
	State.keepnet = []
	State.save_game()
	toast("Продано: +%d серебра" % total)
	_refresh_shop()

# ---------- карточка улова ----------

func _ellipse(rx: float, ry: float, n: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n)
		pts.append(Vector2(cos(a) * rx, sin(a) * ry))
	return pts

func show_card(fish: Dictionary) -> void:
	_card_fish = fish
	_clear(_card_list)
	var fd: Dictionary = Data.FISH[fish["id"]]
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 150)
	_card_list.add_child(holder)
	_fish_art(holder, fd, Vector2(400, 75), 1.0, true)
	var price: int = int(round(float(fish["w"]) * float(fd["kg_price"])))
	var name_l := _lbl(str(fd["name"]), 44)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(name_l)
	var info := _lbl("%.2f кг   %d см   цена %d" % [float(fish["w"]), int(fish["len"]), price], 32)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_card_list.add_child(info)
	if float(State.record.get(fish["id"], 0.0)) <= float(fish["w"]) + 0.001:
		var rl := _lbl("★ Ваш рекорд по этому виду!", 28)
		rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_card_list.add_child(rl)
	var lk := _lbl(_fish_likes(fd), 22)
	lk.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lk.custom_minimum_size = Vector2(700, 0)
	_card_list.add_child(lk)
	_card_list.add_child(_btn("В садок", _card_keep))
	_card_list.add_child(_btn("Отпустить", _card_release))
	_open_modal(_card)

func _card_keep() -> void:
	if State.keepnet.size() >= 25:
		toast("Садок полон — продайте улов в магазине")
		return
	State.keepnet.append(_card_fish)
	_close_modal(_card)

func _card_release() -> void:
	toast("Рыба отпущена")
	_close_modal(_card)

# ---------- меню и настройки ----------

func _open_menu() -> void:
	_refresh_menu()
	_open_modal(_menu)

func _refresh_menu() -> void:
	_clear(_menu_list)
	_menu_list.add_child(_btn("Магазин", _menu_shop))
	_menu_list.add_child(_btn("Журнал рыб", _menu_journal))
	_menu_list.add_child(_btn("Графика: %s" % ["Низкая", "Средняя", "Высокая"][_quality], _cycle_quality))
	_menu_list.add_child(_btn("Лимит FPS: %d" % _fps, _cycle_fps))
	_menu_list.add_child(_btn("Чувствительность: %.1f" % sens, _cycle_sens))
	var rec := ""
	for id in Data.FISH:
		if State.record.has(id):
			rec += "%s %.2f кг;  " % [Data.FISH[id]["name"], float(State.record[id])]
	var rl := _lbl("Рекорды: " + (rec if rec != "" else "пока нет"), 24)
	rl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rl.custom_minimum_size = Vector2(700, 0)
	_menu_list.add_child(rl)
	_menu_list.add_child(_btn("Новая игра (сброс)", _new_game))
	_menu_list.add_child(_btn("Выход", _quit))

func _menu_shop() -> void:
	_close_modal(_menu)
	_open_shop()

func _cycle_quality() -> void:
	_quality = (_quality + 1) % 3
	_apply_quality()
	_refresh_menu()

func _cycle_fps() -> void:
	_fps = 30 if _fps == 60 else 60
	_apply_quality()
	_refresh_menu()

func _cycle_sens() -> void:
	var vals := [0.6, 1.0, 1.5, 2.0]
	var i: int = vals.find(sens)
	sens = vals[(i + 1) % vals.size()]
	_refresh_menu()

func _new_game() -> void:
	State.reset()
	State.save_game()
	toast("Новая игра")
	_close_modal(_menu)

func _quit() -> void:
	State.save_game()
	get_tree().quit()

func _apply_quality() -> void:
	var vp := get_viewport()
	match _quality:
		0:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.6
		1:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.85
		_:
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = 1.0
	for s in get_tree().get_nodes_in_group("sun"):
		s.shadow_enabled = _quality >= 2
	Engine.max_fps = _fps

# ---------- рисунок рыбы, описание ----------

func _fish_art(parent: Control, fd: Dictionary, pos: Vector2, sc: float, known: bool) -> void:
	var col := Color(float(fd["col"][0]), float(fd["col"][1]), float(fd["col"][2]))
	if not known:
		col = Color(0.15, 0.15, 0.18)
	var body := Polygon2D.new()
	body.polygon = _ellipse(110.0, 42.0, 28)
	body.color = col
	body.position = pos
	body.scale = Vector2(sc, sc)
	parent.add_child(body)
	var tail := Polygon2D.new()
	tail.polygon = PackedVector2Array([Vector2(-100, 0), Vector2(-165, -42), Vector2(-165, 42)])
	tail.color = col.darkened(0.25)
	body.add_child(tail)
	if known:
		var eye := Polygon2D.new()
		eye.polygon = _ellipse(6.0, 6.0, 8)
		eye.color = Color(0, 0, 0)
		eye.position = Vector2(72, -8)
		body.add_child(eye)

func _fish_likes(fd: Dictionary) -> String:
	var names: Array = []
	for b in fd["baits"]:
		names.append(str(Data.BAITS[b]["name"]))
	var dr: Array = fd["depth"]
	return "Любит: %s. Глубина %.1f–%.1f м. %s" % [", ".join(PackedStringArray(names)), float(dr[0]), float(dr[1]), Data.HOOKS[int(fd["hook"])]["name"]]

# ---------- журнал рыб ----------

func _menu_journal() -> void:
	_close_modal(_menu)
	_refresh_journal()
	_open_modal(_journal)

func _refresh_journal() -> void:
	_clear(_journal_list)
	for id in Data.FISH:
		var fd: Dictionary = Data.FISH[id]
		var n: int = int(State.counts.get(id, 0))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		var art := Control.new()
		art.custom_minimum_size = Vector2(210, 100)
		row.add_child(art)
		_fish_art(art, fd, Vector2(110, 50), 0.6, n > 0)
		var vb := VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(vb)
		if n > 0:
			vb.add_child(_lbl(str(fd["name"]), 30))
			vb.add_child(_lbl("Рекорд %.2f кг, поймано: %d" % [float(State.record.get(id, 0.0)), n], 22))
			var lk := _lbl(_fish_likes(fd), 20)
			lk.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lk.custom_minimum_size = Vector2(480, 0)
			vb.add_child(lk)
		else:
			vb.add_child(_lbl("???", 30))
			vb.add_child(_lbl("Ещё не поймана", 22))
		_journal_list.add_child(row)

# ---------- покупка снастей ----------

func _gear_btn(prefix: String, i: int, item: Dictionary) -> Button:
	var key := "%s%d" % [prefix, i]
	var txt: String = str(item["name"])
	txt += "  — есть" if State.owned.has(key) else "  — %d" % int(item["price"])
	return _btn(txt, _buy_gear.bind(key, int(item["price"])))

func _buy_gear(key: String, price: int) -> void:
	if State.owned.has(key):
		return
	if State.silver < price:
		toast("Не хватает серебра")
		return
	State.silver -= price
	State.owned[key] = true
	State.save_game()
	_refresh_shop()

# ---------- сборка снасти и прикормка ----------

func _open_tackle() -> void:
	if fishing.state != Fishing.IDLE:
		toast("Сначала смотай снасть")
		return
	_refresh_tackle()
	_open_modal(_tackle)

func _note(text: String) -> Label:
	var l := _lbl(text, 24)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(700, 0)
	return l

func _refresh_tackle() -> void:
	_clear(_tackle_list)
	var rg: Dictionary = State.rig
	var feeder: bool = rg["type"] == "feeder"
	var rod: Dictionary = Data.RODS[State.rod]
	_tackle_list.add_child(_btn("Тип ловли: %s" % ("Фидер (донка)" if feeder else "Поплавочная"), _t_type))
	_tackle_list.add_child(_btn("Крючок: %s" % Data.HOOKS[int(rg["hook"])]["name"], _t_hook))
	var info := ""
	if feeder:
		var fw: int = int(Data.FEEDERS[int(rg["feeder"])]["w"])
		_tackle_list.add_child(_btn("Кормушка: %s" % Data.FEEDERS[int(rg["feeder"])]["name"], _t_feeder))
		info = "Кормушка %d г, удилище бросает до %d г." % [fw, int(rod["cast"])]
		if fw > int(rod["cast"]):
			info += " СЛИШКОМ ТЯЖЁЛАЯ — заброс невозможен."
		else:
			info += " Каждый заброс с прикормкой кормит точку ≈5 минут."
	else:
		var cap: int = int(Data.FLOATS[int(rg["float"])]["cap"])
		var sk: int = int(Data.SINKERS[int(rg["sinker"])])
		_tackle_list.add_child(_btn("Поплавок: %s" % Data.FLOATS[int(rg["float"])]["name"], _t_float))
		_tackle_list.add_child(_btn("Грузило: %d г" % sk, _t_sinker))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var bm := _btn("−", _t_depth.bind(-0.25))
		bm.custom_minimum_size = Vector2(120, 72)
		var lb := _lbl("Глубина: %.2f м" % float(rg["fdepth"]), 30)
		lb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var bp := _btn("+", _t_depth.bind(0.25))
		bp.custom_minimum_size = Vector2(120, 72)
		row.add_child(bm)
		row.add_child(lb)
		row.add_child(bp)
		_tackle_list.add_child(row)
		info = "Поплавок %d г, грузило %d г." % [cap, sk]
		if float(sk) < cap * 0.6:
			info += " Грузила мало — поплавок плавает высоко."
		elif sk > cap:
			info += " Грузило тяжёлое — поплавок тонет, поклёвку видно хуже."
		else:
			info += " Снасть сбалансирована."
		info += " Глубину ставь чуть меньше глубины воды."
	_tackle_list.add_child(_note(info))
	var gs: Dictionary = State.gb_sel
	_tackle_list.add_child(_lbl("— Прикормка (порций: %d) —" % State.gb_portions, 30))
	_tackle_list.add_child(_btn("Основа: %s" % Data.GB_BASES[gs["base"]]["name"], _t_gb.bind("base")))
	_tackle_list.add_child(_btn("Запах: %s" % Data.GB_FLAVORS[gs["flavor"]]["name"], _t_gb.bind("flavor")))
	_tackle_list.add_child(_btn("Добавка: %s" % Data.GB_ADDS[gs["add"]]["name"], _t_gb.bind("add")))
	var likes := ""
	for id in Data.FISH:
		var e: float = Data.gb_effect(id, gs)
		if e >= 1.5:
			likes += "%s ×%.1f;  " % [Data.FISH[id]["name"], e]
	_tackle_list.add_child(_note("Привлекает: " + (likes if likes != "" else "всех слабо")))
	_tackle_list.add_child(_btn("Замесить 10 порций — %d" % _gb_price(), _gb_make))
	_tackle_list.add_child(_note("Кнопка ПРИКОРМКА на экране бросает порцию в воду перед собой."))

func _t_done() -> void:
	State.save_game()
	_refresh_tackle()

func _next_owned(prefix: String, cur: int, count: int) -> int:
	for i in range(1, count + 1):
		var j: int = (cur + i) % count
		if State.owned.has("%s%d" % [prefix, j]):
			return j
	return cur

func _t_type() -> void:
	State.rig["type"] = "feeder" if State.rig["type"] == "float" else "float"
	_t_done()

func _t_hook() -> void:
	State.rig["hook"] = _next_owned("hook", int(State.rig["hook"]), Data.HOOKS.size())
	_t_done()

func _t_feeder() -> void:
	State.rig["feeder"] = _next_owned("feeder", int(State.rig["feeder"]), Data.FEEDERS.size())
	_t_done()

func _t_float() -> void:
	State.rig["float"] = _next_owned("float", int(State.rig["float"]), Data.FLOATS.size())
	_t_done()

func _t_sinker() -> void:
	State.rig["sinker"] = (int(State.rig["sinker"]) + 1) % Data.SINKERS.size()
	_t_done()

func _t_depth(d: float) -> void:
	State.rig["fdepth"] = clampf(float(State.rig["fdepth"]) + d, 0.5, 6.0)
	_t_done()

func _t_gb(which: String) -> void:
	var tbl: Dictionary = Data.GB_BASES
	if which == "flavor":
		tbl = Data.GB_FLAVORS
	elif which == "add":
		tbl = Data.GB_ADDS
	var keys: Array = tbl.keys()
	var i: int = keys.find(State.gb_sel[which])
	State.gb_sel[which] = keys[(i + 1) % keys.size()]
	_t_done()

func _gb_price() -> int:
	var gs: Dictionary = State.gb_sel
	return int(Data.GB_BASES[gs["base"]]["price"]) + int(Data.GB_FLAVORS[gs["flavor"]]["price"]) + int(Data.GB_ADDS[gs["add"]]["price"])

func _gb_make() -> void:
	var p := _gb_price()
	if State.silver < p:
		toast("Не хватает серебра")
		return
	State.silver -= p
	State.gb_mix = State.gb_sel.duplicate()
	State.gb_portions = 10
	toast("Прикормка готова: 10 порций")
	_t_done()
