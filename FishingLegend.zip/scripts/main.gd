extends Node3D
# Fishing Legend — мир: 3 локации (пруд, озеро, река), деревня, погода, время суток, звук

const Data = preload("res://scripts/data.gd")
const FishingScript = preload("res://scripts/fishing.gd")
const HudScript = preload("res://scripts/hud.gd")
const AudioScript = preload("res://scripts/audio.gd")

const PIER_Y := 0.55

const WEATHERS := {
	"clear": {"name": "Ясно", "cloud": 0.05, "rain": 0.0, "fog": 0.0, "wind": 0.2, "bite": 0.9},
	"cloudy": {"name": "Облачно", "cloud": 0.7, "rain": 0.0, "fog": 0.0, "wind": 0.4, "bite": 1.15},
	"fog": {"name": "Туман", "cloud": 0.4, "rain": 0.0, "fog": 1.0, "wind": 0.1, "bite": 1.1},
	"rain": {"name": "Дождь", "cloud": 0.9, "rain": 0.7, "fog": 0.2, "wind": 0.5, "bite": 1.2},
	"storm": {"name": "Гроза", "cloud": 1.0, "rain": 1.0, "fog": 0.3, "wind": 0.9, "bite": 0.6},
}

const WATER_SHADER := """
shader_type spatial;
render_mode blend_mix;
uniform vec2 flow = vec2(0.0, 0.0);
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 p = wpos.xz - flow * TIME;
	float t = TIME;
	vec3 n = normalize(vec3(
		cos(p.x * 1.3 + t * 1.1) * 0.06 + cos(p.x * 3.1 - t * 1.7 + p.y) * 0.03,
		1.0,
		cos(p.y * 1.7 - t * 0.9) * 0.06 + cos(p.y * 2.9 + t * 1.3 + p.x) * 0.03));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float f = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 4.0);
	vec3 deep = vec3(0.02, 0.18, 0.22);
	vec3 skyc = vec3(0.55, 0.72, 0.85);
	ALBEDO = mix(deep, skyc, f);
	ALPHA = mix(0.8, 0.97, f);
	ROUGHNESS = 0.04;
	SPECULAR = 0.9;
}
"""

var noise := FastNoiseLite.new()
var loc_id: String = "pond"
var loc: Dictionary = {}
var loc_fish: Dictionary = {}
var hour: float = 7.0
var weather: String = "clear"
var weather_name: String = "Ясно"
var w_cloud: float = 0.05
var w_rain: float = 0.0
var w_fog: float = 0.0
var w_wind: float = 0.2
var player: Node3D
var cam: Camera3D
var tip: Node3D
var pivot: Node3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var lamp: OmniLight3D
var fishing
var hud
var audio
var units: Array = []
var spot_pos: Vector2 = Vector2.ZERO
var spot_left: float = 0.0
var spot_mix: Dictionary = {}
var _spot_mesh: MeshInstance3D
var _mood: float = 0.7
var _mood_target: float = 0.7
var _mood_t: float = 150.0
var yaw: float = 0.0
var pitch: float = 0.0
var py: float = 0.0
var circles: Array = []   # Vector3(x, z, радиус)
var rects: Array = []     # Rect2(x, z, w, d)
var roads: Array = []
var shop_pos: Vector2 = Vector2(-14, 4)
var stop_pos: Vector2 = Vector2(7, 3)

var _world: Node3D
var _water_mat: ShaderMaterial
var _rain: CPUParticles3D
var _w_timer: float = 150.0
var _flash: float = 0.0
var _thunder_t: float = 20.0
var _thunder_delay: float = -1.0
var _step_acc: float = 0.0
var _water_near: float = 0.0
var _water_t: float = 0.0

func _ready() -> void:
	noise.seed = 7
	noise.frequency = 0.03
	_build_env()
	_build_player()
	audio = AudioScript.new()
	add_child(audio)
	for i in 3:
		var u = FishingScript.new()
		u.slot = i
		u.world = self
		u.audio = audio
		u.cam = cam
		u.pivot = pivot
		u.hand_tip = tip
		add_child(u)
		units.append(u)
	fishing = units[State.cur]
	hud = HudScript.new()
	add_child(hud)
	hud.setup(fishing, self, audio)
	for u in units:
		u.msg.connect(hud.toast)
		u.caught.connect(hud.show_card)
	fishing.take()
	var id: String = State.loc if Data.LOCS.has(State.loc) else "pond"
	travel(id)
	weather = ["clear", "cloudy"][randi() % 2]
	_apply_weather_now()

# ---------- локации ----------

func travel(id: String) -> void:
	for u in units:
		u._reset()
		u.hide_rod()
	if units.size() > 0:
		units[State.cur].take()
	spot_left = 0.0
	loc_id = id
	loc = Data.LOCS[id]
	loc_fish = loc["fish"]
	State.loc = id
	State.save_game()
	if _world != null:
		_world.queue_free()
	_world = Node3D.new()
	add_child(_world)
	circles = []
	rects = []
	roads = []
	var door := shop_pos + Vector2(3.8, 0.0)
	var pr: Array = loc["pier"]
	roads.append([Vector2(0, 0), door])
	roads.append([Vector2(0, 0), stop_pos])
	roads.append([Vector2(0, 0), Vector2(float(pr[0]), float(pr[1]) + 1.0)])
	_build_terrain()
	_build_water()
	_build_pier()
	_build_village()
	_build_trees()
	_build_reeds()
	player.position = Vector3(0, 0, 0)
	py = ground_at(0.0, 0.0)
	yaw = 0.0
	pitch = 0.0
	_water_mat.set_shader_parameter("flow", loc["flow"])

# ---------- рельеф ----------

func ground_at(x: float, z: float) -> float:
	var kind: String = loc["kind"]
	var c: Vector2 = loc["center"]
	var r: float = loc["r"]
	var dep: float = loc["depth"]
	var wd: float
	if kind == "river":
		wd = absf(z - (c.y + 14.0 * sin(x * 0.035))) - r
	else:
		var dx := x - c.x
		var dz := z - c.y
		var ln := maxf(0.001, sqrt(dx * dx + dz * dz))
		var amp := 0.08 if kind == "pond" else 0.12
		wd = ln - r * (1.0 + amp * noise.get_noise_2d(dx / ln * 2.5, dz / ln * 2.5))
	var h: float
	if wd < 0.0:
		h = maxf(0.15 + wd * (dep + 0.15) / r, -dep)
	else:
		var k := smoothstep(0.0, 30.0, wd)
		h = 0.15 + wd * 0.02 + noise.get_noise_2d(x, z) * 3.0 * k
	var e := maxf(maxf(x - (float(loc["x1"]) - 30.0), (float(loc["x0"]) + 30.0) - x), maxf(z - (float(loc["z1"]) - 30.0), (float(loc["z0"]) + 30.0) - z))
	h += smoothstep(0.0, 25.0, e) * 10.0
	return h

func height_at(x: float, z: float) -> float:
	var pr: Array = loc["pier"]
	if absf(x - float(pr[0])) < 1.0 and z < float(pr[1]) and z > float(pr[2]):
		return PIER_Y
	return ground_at(x, z)

func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.001), 0.0, 1.0)
	return p.distance_to(a + ab * t)

func _vert(st: SurfaceTool, x: float, z: float) -> void:
	var h := ground_at(x, z)
	var n := noise.get_noise_2d(x * 3.0, z * 3.0) * 0.5 + 0.5
	var grass := Color(0.2, 0.42, 0.13).lerp(Color(0.32, 0.5, 0.18), n)
	var c := Color(0.22, 0.2, 0.14).lerp(Color(0.52, 0.47, 0.32), smoothstep(-0.5, 0.0, h))
	c = c.lerp(grass, smoothstep(0.25, 0.7, h))
	c = c.lerp(Color(0.42, 0.4, 0.37), smoothstep(5.0, 9.0, h))
	for seg in roads:
		var d := _seg_dist(Vector2(x, z), seg[0], seg[1])
		if d < 1.7 and h > 0.0:
			c = c.lerp(Color(0.5, 0.4, 0.27), 1.0 - smoothstep(0.9, 1.7, d))
	st.set_color(c)
	st.add_vertex(Vector3(x, h, z))

func _build_terrain() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var x0: float = loc["x0"]
	var z0: float = loc["z0"]
	var s: float = loc["cell"]
	var nx: int = int((float(loc["x1"]) - x0) / s)
	var nz: int = int((float(loc["z1"]) - z0) / s)
	for iz in nz:
		for ix in nx:
			var xa := x0 + ix * s
			var xb := xa + s
			var za := z0 + iz * s
			var zb := za + s
			_vert(st, xa, za)
			_vert(st, xb, za)
			_vert(st, xb, zb)
			_vert(st, xa, za)
			_vert(st, xb, zb)
			_vert(st, xa, zb)
	st.index()
	st.generate_normals()
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.95
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if ResourceLoader.exists("res://assets/ground_diff.jpg"):
		m.albedo_texture = load("res://assets/ground_diff.jpg")
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(0.25, 0.25, 0.25)
	mi.material_override = m
	_world.add_child(mi)

func _build_water() -> void:
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(900, 900)
	mi.mesh = pm
	var sh := Shader.new()
	sh.code = WATER_SHADER
	_water_mat = ShaderMaterial.new()
	_water_mat.shader = sh
	mi.material_override = _water_mat
	var c: Vector2 = loc["center"]
	mi.position = Vector3(c.x, 0, c.y)
	_world.add_child(mi)

# ---------- окружение, время суток, погода ----------

func _build_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_density = 0.006
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = false
	sun.directional_shadow_max_distance = 60.0
	sun.add_to_group("sun")
	add_child(sun)
	_spot_mesh = MeshInstance3D.new()
	var spc := CylinderMesh.new()
	spc.top_radius = 3.0
	spc.bottom_radius = 3.0
	spc.height = 0.02
	spc.radial_segments = 24
	_spot_mesh.mesh = spc
	var spm := StandardMaterial3D.new()
	spm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	spm.albedo_color = Color(0.75, 0.6, 0.3, 0.3)
	_spot_mesh.material_override = spm
	_spot_mesh.visible = false
	add_child(_spot_mesh)
	_rain = CPUParticles3D.new()
	_rain.amount = 700
	_rain.lifetime = 0.8
	_rain.preprocess = 0.8
	_rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_rain.emission_box_extents = Vector3(14, 0.1, 14)
	_rain.direction = Vector3(0.1, -1, 0)
	_rain.spread = 2.0
	_rain.gravity = Vector3(0, -25, 0)
	_rain.initial_velocity_min = 12.0
	_rain.initial_velocity_max = 16.0
	var qm := BoxMesh.new()
	qm.size = Vector3(0.012, 0.5, 0.012)
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color(0.8, 0.85, 0.95, 0.5)
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	qm.material = rm
	_rain.mesh = qm
	_rain.emitting = false
	add_child(_rain)

func _apply_weather_now() -> void:
	var w: Dictionary = WEATHERS[weather]
	weather_name = str(w["name"])
	w_cloud = float(w["cloud"])
	w_rain = float(w["rain"])
	w_fog = float(w["fog"])
	w_wind = float(w["wind"])

func add_spot(p: Vector2, mix: Dictionary) -> void:
	spot_pos = p
	spot_left = 300.0
	spot_mix = mix

# Аппетит рыбы: время суток × настроение (меняется каждые несколько минут)
func appetite() -> float:
	var d := 0.55
	if (hour >= 4.5 and hour <= 9.5) or (hour >= 17.0 and hour <= 21.5):
		d = 1.0
	elif hour >= 11.0 and hour <= 15.0:
		d = 0.5
	elif hour < 4.0 or hour > 22.5:
		d = 0.4
	return clampf(d * _mood, 0.08, 1.2)

func held_unit():
	for u in units:
		if u.held:
			return u
	return null

func skip_ok() -> bool:
	var any := false
	for u in units:
		if u.state == 3:
			any = true
		elif u.state != 0:
			return false
	return any

func select_slot(i: int) -> void:
	if i >= State.stands:
		hud.toast("Нужна подставка — купите в магазине")
		return
	var hu = held_unit()
	if hu != null and hu.slot == i:
		if hu.state == 0:
			hu.hide_rod()
		elif hu.is_waiting():
			_place(hu)
		else:
			hud.toast("Сначала закончи с этой удочкой")
		return
	if hu != null:
		if hu.is_waiting():
			_place(hu)
		elif hu.state == 0:
			hu.hide_rod()
		else:
			hud.toast("Сначала закончи с этой удочкой")
			return
	State.set_cur(i)
	fishing = units[i]
	fishing.take()
	hud.fishing = fishing

func _place(u) -> void:
	var right := player.global_transform.basis.x
	var fwd := -player.global_transform.basis.z
	var p := player.global_position + right * (float(u.slot - 1) * 1.4) + fwd * 1.2
	p.y = ground_at(p.x, p.z)
	u.place_on_stand(p)

func bite_mod() -> float:
	return float(WEATHERS[weather]["bite"])

func _next_weather() -> void:
	var opts: Array = ["clear", "cloudy", "fog", "rain"]
	if weather == "rain":
		opts = ["cloudy", "rain", "storm", "clear"]
	opts.erase(weather)
	weather = opts[randi() % opts.size()]
	weather_name = str(WEATHERS[weather]["name"])
	hud.toast("Погода: %s" % weather_name)

func _update_time(delta: float) -> void:
	hour = fmod(hour + delta / 60.0, 24.0)
	_mood_t -= delta
	if _mood_t <= 0.0:
		_mood_t = randf_range(180.0, 480.0)
		_mood_target = randf_range(0.35, 1.15)
	_mood = lerpf(_mood, _mood_target, clampf(delta * 0.02, 0.0, 1.0))
	spot_left = maxf(0.0, spot_left - delta)
	_spot_mesh.visible = spot_left > 0.0
	_spot_mesh.global_position = Vector3(spot_pos.x, 0.02, spot_pos.y)
	_w_timer -= delta
	if _w_timer <= 0.0 and hud != null:
		_w_timer = randf_range(150.0, 330.0)
		_next_weather()
	var w: Dictionary = WEATHERS[weather]
	var a: float = clampf(delta * 0.25, 0.0, 1.0)
	w_cloud = lerpf(w_cloud, float(w["cloud"]), a)
	w_rain = lerpf(w_rain, float(w["rain"]), a)
	w_fog = lerpf(w_fog, float(w["fog"]), a)
	w_wind = lerpf(w_wind, float(w["wind"]), a)
	var day := clampf(sin((hour - 6.0) / 12.0 * PI), 0.0, 1.0)
	sun.rotation_degrees = Vector3(-(hour - 6.0) * 15.0, 30.0, 0.0)
	sun.light_energy = day * 1.3 * (1.0 - 0.6 * w_cloud)
	sun.visible = day > 0.02
	var top: Color
	var hor: Color
	if day < 0.3:
		var k := day / 0.3
		top = Color(0.02, 0.03, 0.08).lerp(Color(0.2, 0.25, 0.45), k)
		hor = Color(0.05, 0.07, 0.15).lerp(Color(0.95, 0.55, 0.3), k)
	else:
		var k2 := (day - 0.3) / 0.7
		top = Color(0.2, 0.25, 0.45).lerp(Color(0.25, 0.5, 0.85), k2)
		hor = Color(0.95, 0.55, 0.3).lerp(Color(0.7, 0.82, 0.92), k2)
	var gray := Color(0.5, 0.53, 0.58) * (0.2 + 0.8 * day)
	top = top.lerp(gray, w_cloud * 0.8)
	hor = hor.lerp(gray.lightened(0.1), w_cloud * 0.8)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = top.darkened(0.4)
	env.fog_light_color = hor
	_flash = maxf(0.0, _flash - delta * 2.5)
	env.ambient_light_color = hor.lerp(top, 0.4)
	env.ambient_light_energy = lerpf(0.25, 0.8, day) + _flash * 2.5
	env.fog_density = 0.006 + 0.03 * w_fog + 0.004 * w_rain
	if lamp != null:
		lamp.visible = day < 0.2
	_rain.emitting = w_rain > 0.08
	_rain.global_position = cam.global_position + Vector3(0, 8, 0)
	if weather == "storm":
		_thunder_t -= delta
		if _thunder_t <= 0.0:
			_thunder_t = randf_range(14.0, 35.0)
			_flash = 1.0
			_thunder_delay = randf_range(0.6, 2.2)
	if _thunder_delay > 0.0:
		_thunder_delay -= delta
		if _thunder_delay <= 0.0:
			audio.play("thunder", -8.0)
	_water_t -= delta
	if _water_t <= 0.0:
		_water_t = 0.6
		var cnt := 0
		for i in 8:
			var ang := TAU * float(i) / 8.0
			if ground_at(player.position.x + cos(ang) * 10.0, player.position.z + sin(ang) * 10.0) < 0.1:
				cnt += 1
		_water_near = clampf(float(cnt) / 3.0, 0.0, 1.0)
	audio.update_ambience(day, w_wind, w_rain, _water_near)
	audio.tick(delta, day, w_rain, _water_near)

# ---------- объекты мира ----------

func _mat(c: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

func _box(size: Vector3, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	_world.add_child(mi)
	return mi

func _mm(mesh: Mesh, mat: Material, xforms: Array) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat
	_world.add_child(mi)

func _build_pier() -> void:
	var pr: Array = loc["pier"]
	var px: float = pr[0]
	var z0: float = pr[1]
	var z1: float = pr[2]
	var wood := _mat(Color(0.45, 0.3, 0.15))
	_box(Vector3(2.0, 0.12, z0 - z1), wood, Vector3(px, PIER_Y - 0.06, (z0 + z1) * 0.5))
	var z := z0 - 1.5
	while z > z1:
		_box(Vector3(0.16, 2.8, 0.16), wood, Vector3(px - 0.92, PIER_Y - 1.3, z))
		_box(Vector3(0.16, 2.8, 0.16), wood, Vector3(px + 0.92, PIER_Y - 1.3, z))
		z -= 3.0

func _house(x: float, z: float, w: float, d: float, wall: Color, roof: Color, label: String) -> void:
	var base := ground_at(x, z)
	_box(Vector3(w, 4.0, d), _mat(wall), Vector3(x, base + 1.4, z))
	var r := MeshInstance3D.new()
	var pm := PrismMesh.new()
	pm.size = Vector3(w + 0.8, 1.8, d + 0.8)
	r.mesh = pm
	r.material_override = _mat(roof)
	r.position = Vector3(x, base + 4.3, z)
	_world.add_child(r)
	_box(Vector3(0.1, 2.0, 1.2), _mat(Color(0.25, 0.15, 0.08)), Vector3(x + w * 0.5 + 0.02, base + 0.85, z))
	_box(Vector3(0.1, 0.9, 1.0), _mat(Color(0.5, 0.7, 0.85), 0.2), Vector3(x + w * 0.5 + 0.02, base + 1.6, z - d * 0.34))
	rects.append(Rect2(x - w * 0.5 - 0.5, z - d * 0.5 - 0.5, w + 1.0, d + 1.0))
	if label != "":
		var l := Label3D.new()
		l.text = label
		l.font_size = 64
		l.pixel_size = 0.012
		l.outline_size = 12
		l.rotation_degrees = Vector3(0, 90, 0)
		l.position = Vector3(x + w * 0.5 + 0.06, base + 2.7, z)
		_world.add_child(l)

func _build_village() -> void:
	_house(shop_pos.x, shop_pos.y, 6.0, 5.0, Color(0.62, 0.48, 0.32), Color(0.5, 0.18, 0.12), "МАГАЗИН")
	_house(-27.0, -6.0, 6.0, 5.0, Color(0.75, 0.7, 0.55), Color(0.3, 0.25, 0.2), "")
	_house(-27.0, 14.0, 7.0, 5.0, Color(0.55, 0.62, 0.7), Color(0.45, 0.2, 0.15), "")
	_house(-12.0, 19.0, 5.0, 5.0, Color(0.7, 0.55, 0.5), Color(0.25, 0.3, 0.35), "")
	_house(-2.0, 24.0, 6.0, 5.0, Color(0.8, 0.75, 0.6), Color(0.4, 0.2, 0.15), "")
	var gh := ground_at(stop_pos.x, stop_pos.y)
	_box(Vector3(0.15, 2.6, 0.15), _mat(Color(0.3, 0.3, 0.32)), Vector3(stop_pos.x, gh + 1.3, stop_pos.y))
	_box(Vector3(1.6, 0.5, 0.1), _mat(Color(0.15, 0.4, 0.7)), Vector3(stop_pos.x, gh + 2.5, stop_pos.y))
	_box(Vector3(1.8, 0.12, 0.5), _mat(Color(0.4, 0.28, 0.15)), Vector3(stop_pos.x + 1.4, gh + 0.5, stop_pos.y))
	var l := Label3D.new()
	l.text = "АВТОБУС"
	l.font_size = 48
	l.pixel_size = 0.01
	l.position = Vector3(stop_pos.x, gh + 2.5, stop_pos.y + 0.07)
	_world.add_child(l)
	circles.append(Vector3(stop_pos.x, stop_pos.y, 0.4))

func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var trunks: Array = []
	var crowns: Array = []
	var bushes: Array = []
	var village := Rect2(-42.0, -14.0, 50.0, 46.0)
	var x0: float = float(loc["x0"]) + 14.0
	var x1: float = float(loc["x1"]) - 14.0
	var z0: float = float(loc["z0"]) + 14.0
	var z1: float = float(loc["z1"]) - 10.0
	var want: int = int(loc["trees"])
	var tries := 0
	while trunks.size() < want and tries < 1500:
		tries += 1
		var x := rng.randf_range(x0, x1)
		var z := rng.randf_range(z0, z1)
		if Vector2(x, z).length() < 12.0 or village.has_point(Vector2(x, z)):
			continue
		var h := ground_at(x, z)
		if h < 0.6:
			continue
		var s := rng.randf_range(0.8, 1.5)
		var sc := Vector3(s, s, s)
		trunks.append(Transform3D(Basis().scaled(sc), Vector3(x, h + 1.25 * s, z)))
		crowns.append(Transform3D(Basis().scaled(sc), Vector3(x, h + 3.75 * s, z)))
		circles.append(Vector3(x, z, 0.7 * s))
	tries = 0
	while bushes.size() < 50 and tries < 600:
		tries += 1
		var bx := rng.randf_range(x0, x1)
		var bz := rng.randf_range(z0, z1)
		var bh := ground_at(bx, bz)
		if bh < 0.4 or village.has_point(Vector2(bx, bz)):
			continue
		var bs := rng.randf_range(0.7, 1.3)
		bushes.append(Transform3D(Basis().scaled(Vector3(bs, bs * 0.8, bs)), Vector3(bx, bh + 0.3, bz)))
	var tm := CylinderMesh.new()
	tm.top_radius = 0.14
	tm.bottom_radius = 0.2
	tm.height = 2.5
	tm.radial_segments = 6
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 1.5
	cm.height = 4.5
	cm.radial_segments = 8
	var bm := SphereMesh.new()
	bm.radius = 0.7
	bm.height = 1.2
	bm.radial_segments = 8
	bm.rings = 4
	_mm(tm, _mat(Color(0.32, 0.2, 0.1)), trunks)
	_mm(cm, _mat(Color(0.1, 0.3, 0.12)), crowns)
	_mm(bm, _mat(Color(0.16, 0.36, 0.14)), bushes)

func _build_reeds() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var reeds: Array = []
	var pr: Array = loc["pier"]
	var x0: float = float(loc["x0"]) + 14.0
	var x1: float = float(loc["x1"]) - 14.0
	var z0: float = float(loc["z0"]) + 14.0
	var z1: float = float(loc["z1"]) - 14.0
	var tries := 0
	while reeds.size() < 300 and tries < 6000:
		tries += 1
		var x := rng.randf_range(x0, x1)
		var z := rng.randf_range(z0, z1)
		if absf(x - float(pr[0])) < 3.0 and z < float(pr[1]) + 3.0 and z > float(pr[2]) - 3.0:
			continue
		var h := ground_at(x, z)
		if h > 0.25 or h < -0.8:
			continue
		var s := rng.randf_range(0.7, 1.4)
		reeds.append(Transform3D(Basis().scaled(Vector3(1, s, 1)), Vector3(x, h + 0.8 * s, z)))
	var rm := CylinderMesh.new()
	rm.top_radius = 0.008
	rm.bottom_radius = 0.016
	rm.height = 1.6
	rm.radial_segments = 4
	rm.rings = 1
	_mm(rm, _mat(Color(0.5, 0.55, 0.2)), reeds)

# ---------- игрок ----------

func _build_player() -> void:
	player = Node3D.new()
	add_child(player)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 500.0
	cam.position = Vector3(0, 1.65, 0)
	player.add_child(cam)
	cam.current = true
	lamp = OmniLight3D.new()
	lamp.omni_range = 14.0
	lamp.light_energy = 0.7
	lamp.position = Vector3(0, 0.2, 0)
	lamp.visible = false
	cam.add_child(lamp)
	pivot = Node3D.new()
	pivot.position = Vector3(0.28, -0.32, -0.35)
	pivot.rotation_degrees = Vector3(-68, 0, 0)
	cam.add_child(pivot)
	var rod := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.004
	cm.bottom_radius = 0.014
	cm.height = 2.2
	cm.radial_segments = 6
	rod.mesh = cm
	rod.material_override = _mat(Color(0.1, 0.1, 0.1), 0.4)
	rod.position = Vector3(0, 1.1, 0)
	pivot.add_child(rod)
	tip = Node3D.new()
	tip.position = Vector3(0, 2.2, 0)
	pivot.add_child(tip)

func _blocked(p: Vector2) -> bool:
	if p.x < float(loc["x0"]) + 14.0 or p.x > float(loc["x1"]) - 14.0 or p.y < float(loc["z0"]) + 14.0 or p.y > float(loc["z1"]) - 10.0:
		return true
	if height_at(p.x, p.y) < -0.45:
		return true
	for r in rects:
		if r.has_point(p):
			return true
	for o in circles:
		if Vector2(o.x, o.y).distance_to(p) < o.z + 0.3:
			return true
	return false

func _process(delta: float) -> void:
	_update_time(delta)
	var l: Vector2 = hud.look
	hud.look = Vector2.ZERO
	yaw -= l.x * 0.004 * hud.sens
	pitch = clampf(pitch - l.y * 0.004 * hud.sens, -1.3, 1.3)
	player.rotation.y = yaw
	cam.rotation.x = pitch
	fishing = units[State.cur]
	for u in units:
		u.reel_vel = hud.reel_out if u.held else 0.0
	pivot.visible = held_unit() != null
	var skipping: bool = hud.skip_held and skip_ok() and not hud.modal_open
	Engine.time_scale = 4.0 if skipping else 1.0
	hud.hour = hour
	var mv: Vector2 = hud.move
	var hu = held_unit()
	if (hu == null or hu.state == 0) and mv.length() > 0.05 and not hud.modal_open:
		var spd := lerpf(1.7, 4.2, smoothstep(0.6, 1.0, mv.length())) * minf(mv.length(), 1.0)
		var dir := (player.global_transform.basis * Vector3(mv.x, 0.0, mv.y)).normalized()
		var step := Vector2(dir.x, dir.z) * spd * delta
		var p := Vector2(player.position.x, player.position.z)
		var before := p
		if not _blocked(p + step):
			p += step
		elif not _blocked(p + Vector2(step.x, 0.0)):
			p.x += step.x
		elif not _blocked(p + Vector2(0.0, step.y)):
			p.y += step.y
		player.position.x = p.x
		player.position.z = p.y
		_step_acc += before.distance_to(p)
		if _step_acc > 1.5:
			_step_acc = 0.0
			audio.play("step_wood" if height_at(p.x, p.y) == PIER_Y else "step_grass", -14.0, randf_range(0.9, 1.1))
	var g := maxf(height_at(player.position.x, player.position.z), -0.45)
	py = lerpf(py, g, clampf(delta * 12.0, 0.0, 1.0))
	player.position.y = py
	var pp := Vector2(player.position.x, player.position.z)
	hud.set_shop_near(pp.distance_to(shop_pos + Vector2(3.8, 0.0)) < 3.2)
	hud.set_stop_near(pp.distance_to(stop_pos) < 3.0)
