extends Node3D
# Fishing Legend — этап 1: озеро, ходьба, заброс, поклёвка, вываживание, магазин

const FishingScript = preload("res://scripts/fishing.gd")
const HudScript = preload("res://scripts/hud.gd")

const LAKE_C := Vector2(0.0, -45.0)
const LAKE_R := 35.0
const PIER_Y := 0.55
const SHOP_POS := Vector3(-14.0, 0.0, 4.0)

const WATER_SHADER := """
shader_type spatial;
render_mode blend_mix;
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 p = wpos.xz;
	float t = TIME;
	vec3 n = normalize(vec3(
		cos(p.x * 1.3 + t * 1.1) * 0.06 + cos(p.x * 3.1 - t * 1.7 + p.y) * 0.03,
		1.0,
		cos(p.y * 1.7 - t * 0.9) * 0.06 + cos(p.y * 2.9 + t * 1.3 + p.x) * 0.03));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float f = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 4.0);
	vec3 deep = vec3(0.02, 0.18, 0.22);
	vec3 skyc = vec3(0.55, 0.72, 0.85);
	ALBEDO = mix(deep, skyc, f);
	ALPHA = mix(0.8, 0.97, f);
	ROUGHNESS = 0.04;
	SPECULAR = 0.9;
}
"""

var noise := FastNoiseLite.new()
var hour: float = 7.0
var player: Node3D
var cam: Camera3D
var tip: Node3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var fishing
var hud
var yaw: float = 0.0
var pitch: float = 0.0
var py: float = 0.0
var obstacles: Array = []   # Vector3(x, z, радиус)

func _ready() -> void:
	noise.seed = 7
	noise.frequency = 0.03
	_build_env()
	_build_terrain()
	_build_water()
	_build_pier()
	_build_shop()
	_build_trees()
	_build_reeds()
	_build_player()
	fishing = FishingScript.new()
	fishing.world = self
	fishing.cam = cam
	fishing.tip = tip
	add_child(fishing)
	hud = HudScript.new()
	add_child(hud)
	hud.setup(fishing)

# ---------- рельеф ----------

func ground_at(x: float, z: float) -> float:
	var d := Vector2(x - LAKE_C.x, z - LAKE_C.y).length()
	var h: float
	if d < LAKE_R:
		h = maxf(0.15 + (d - LAKE_R) * 0.17, -4.5)
	else:
		var k := smoothstep(LAKE_R, LAKE_R + 30.0, d)
		h = 0.15 + (d - LAKE_R) * 0.02 + noise.get_noise_2d(x, z) * 3.0 * k
	var e := maxf(maxf(absf(x) - 60.0, -z - 85.0), z - 35.0)
	h += smoothstep(0.0, 20.0, e) * 10.0
	return h

func height_at(x: float, z: float) -> float:
	if absf(x) < 1.0 and z < -6.5 and z > -21.0:
		return PIER_Y
	return ground_at(x, z)

func _vert(st: SurfaceTool, x: float, z: float) -> void:
	var h := ground_at(x, z)
	var mud := Color(0.22, 0.2, 0.14)
	var sand := Color(0.52, 0.47, 0.32)
	var n := noise.get_noise_2d(x * 3.0, z * 3.0) * 0.5 + 0.5
	var grass := Color(0.2, 0.42, 0.13).lerp(Color(0.32, 0.5, 0.18), n)
	var c := mud.lerp(sand, smoothstep(-0.5, 0.0, h))
	c = c.lerp(grass, smoothstep(0.25, 0.7, h))
	c = c.lerp(Color(0.42, 0.4, 0.37), smoothstep(5.0, 9.0, h))
	st.set_color(c)
	st.add_vertex(Vector3(x, h, z))

func _build_terrain() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var x0 := -80.0
	var z0 := -110.0
	var s := 2.0
	for iz in 80:
		for ix in 80:
			var xa := x0 + ix * s
			var xb := xa + s
			var za := z0 + iz * s
			var zb := za + s
			_vert(st, xa, za)
			_vert(st, xb, za)
			_vert(st, xb, zb)
			_vert(st, xa, za)
			_vert(st, xb, zb)
			_vert(st, xa, zb)
	st.index()
	st.generate_normals()
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.95
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if ResourceLoader.exists("res://assets/ground_diff.jpg"):
		m.albedo_texture = load("res://assets/ground_diff.jpg")
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(0.25, 0.25, 0.25)
	mi.material_override = m
	add_child(mi)

func _build_water() -> void:
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(600, 600)
	mi.mesh = pm
	var sh := Shader.new()
	sh.code = WATER_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	mi.material_override = m
	mi.position = Vector3(0, 0, -45)
	add_child(mi)

# ---------- окружение, время суток ----------

func _build_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_density = 0.006
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = false
	sun.directional_shadow_max_distance = 60.0
	sun.add_to_group("sun")
	add_child(sun)
	_update_time(0.0)

func _update_time(delta: float) -> void:
	hour = fmod(hour + delta / 60.0, 24.0)
	var day := clampf(sin((hour - 6.0) / 12.0 * PI), 0.0, 1.0)
	sun.rotation_degrees = Vector3(-(hour - 6.0) * 15.0, 30.0, 0.0)
	sun.light_energy = day * 1.3
	sun.visible = day > 0.02
	var top: Color
	var hor: Color
	if day < 0.3:
		var k := day / 0.3
		top = Color(0.02, 0.03, 0.08).lerp(Color(0.2, 0.25, 0.45), k)
		hor = Color(0.05, 0.07, 0.15).lerp(Color(0.95, 0.55, 0.3), k)
	else:
		var k := (day - 0.3) / 0.7
		top = Color(0.2, 0.25, 0.45).lerp(Color(0.25, 0.5, 0.85), k)
		hor = Color(0.95, 0.55, 0.3).lerp(Color(0.7, 0.82, 0.92), k)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor
	sky_mat.ground_bottom_color = top.darkened(0.4)
	env.fog_light_color = hor
	env.ambient_light_color = hor.lerp(top, 0.4)
	env.ambient_light_energy = lerpf(0.25, 0.8, day)

# ---------- объекты мира ----------

func _mat(c: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

func _box(size: Vector3, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi

func _mm(mesh: Mesh, mat: Material, xforms: Array) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat
	add_child(mi)

func _build_pier() -> void:
	var wood := _mat(Color(0.45, 0.3, 0.15))
	_box(Vector3(2.0, 0.12, 14.5), wood, Vector3(0, PIER_Y - 0.06, -13.75))
	for i in 5:
		var z := -8.0 - i * 3.0
		_box(Vector3(0.16, 2.8, 0.16), wood, Vector3(-0.92, PIER_Y - 1.3, z))
		_box(Vector3(0.16, 2.8, 0.16), wood, Vector3(0.92, PIER_Y - 1.3, z))

func _build_shop() -> void:
	var base := ground_at(SHOP_POS.x, SHOP_POS.z)
	var x := SHOP_POS.x
	var z := SHOP_POS.z
	_box(Vector3(6, 4, 5), _mat(Color(0.62, 0.48, 0.32)), Vector3(x, base + 1.4, z))
	var roof := MeshInstance3D.new()
	var pm := PrismMesh.new()
	pm.size = Vector3(6.8, 1.8, 5.8)
	roof.mesh = pm
	roof.material_override = _mat(Color(0.5, 0.18, 0.12))
	roof.position = Vector3(x, base + 4.3, z)
	add_child(roof)
	_box(Vector3(0.1, 2.0, 1.2), _mat(Color(0.25, 0.15, 0.08)), Vector3(x + 3.02, base + 0.85, z))
	_box(Vector3(0.1, 0.9, 1.0), _mat(Color(0.5, 0.7, 0.85), 0.2), Vector3(x + 3.02, base + 1.6, z - 1.7))
	var sign_l := Label3D.new()
	sign_l.text = "МАГАЗИН"
	sign_l.font_size = 64
	sign_l.pixel_size = 0.012
	sign_l.outline_size = 12
	sign_l.rotation_degrees = Vector3(0, 90, 0)
	sign_l.position = Vector3(x + 3.06, base + 2.7, z)
	add_child(sign_l)

func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var trunks: Array = []
	var crowns: Array = []
	var bushes: Array = []
	var tries := 0
	while trunks.size() < 80 and tries < 800:
		tries += 1
		var x := rng.randf_range(-72.0, 72.0)
		var z := rng.randf_range(-100.0, 40.0)
		if Vector2(x - LAKE_C.x, z - LAKE_C.y).length() < LAKE_R + 7.0:
			continue
		if Vector2(x, z).length() < 12.0:
			continue
		if Vector2(x - SHOP_POS.x, z - SHOP_POS.z).length() < 9.0:
			continue
		var h := ground_at(x, z)
		var s := rng.randf_range(0.8, 1.5)
		var sc := Vector3(s, s, s)
		trunks.append(Transform3D(Basis().scaled(sc), Vector3(x, h + 1.25 * s, z)))
		crowns.append(Transform3D(Basis().scaled(sc), Vector3(x, h + 3.75 * s, z)))
		obstacles.append(Vector3(x, z, 0.7 * s))
	tries = 0
	while bushes.size() < 50 and tries < 400:
		tries += 1
		var bx := rng.randf_range(-70.0, 70.0)
		var bz := rng.randf_range(-100.0, 40.0)
		if Vector2(bx - LAKE_C.x, bz - LAKE_C.y).length() < LAKE_R + 3.0:
			continue
		var bh := ground_at(bx, bz)
		var bs := rng.randf_range(0.7, 1.3)
		bushes.append(Transform3D(Basis().scaled(Vector3(bs, bs * 0.8, bs)), Vector3(bx, bh + 0.3, bz)))
	var tm := CylinderMesh.new()
	tm.top_radius = 0.14
	tm.bottom_radius = 0.2
	tm.height = 2.5
	tm.radial_segments = 6
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 1.5
	cm.height = 4.5
	cm.radial_segments = 8
	var bm := SphereMesh.new()
	bm.radius = 0.7
	bm.height = 1.2
	bm.radial_segments = 8
	bm.rings = 4
	_mm(tm, _mat(Color(0.32, 0.2, 0.1)), trunks)
	_mm(cm, _mat(Color(0.1, 0.3, 0.12)), crowns)
	_mm(bm, _mat(Color(0.16, 0.36, 0.14)), bushes)

func _build_reeds() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var reeds: Array = []
	for i in 300:
		var a := rng.randf() * TAU
		var r := LAKE_R + rng.randf_range(-2.5, 0.5)
		var x := LAKE_C.x + cos(a) * r
		var z := LAKE_C.y + sin(a) * r
		if absf(x) < 3.0 and z < -4.0:
			continue
		var h := ground_at(x, z)
		if h > 0.3 or h < -0.9:
			continue
		var s := rng.randf_range(0.7, 1.4)
		reeds.append(Transform3D(Basis().scaled(Vector3(1, s, 1)), Vector3(x, h + 0.8 * s, z)))
	var rm := CylinderMesh.new()
	rm.top_radius = 0.008
	rm.bottom_radius = 0.016
	rm.height = 1.6
	rm.radial_segments = 4
	rm.rings = 1
	_mm(rm, _mat(Color(0.5, 0.55, 0.2)), reeds)

# ---------- игрок ----------

func _build_player() -> void:
	player = Node3D.new()
	add_child(player)
	player.position = Vector3(0, 0, 0)
	py = ground_at(0.0, 0.0)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 400.0
	cam.position = Vector3(0, 1.65, 0)
	player.add_child(cam)
	cam.current = true
	var pivot := Node3D.new()
	pivot.position = Vector3(0.28, -0.32, -0.35)
	pivot.rotation_degrees = Vector3(-68, 0, 0)
	cam.add_child(pivot)
	var rod := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.004
	cm.bottom_radius = 0.014
	cm.height = 2.2
	cm.radial_segments = 6
	rod.mesh = cm
	rod.material_override = _mat(Color(0.1, 0.1, 0.1), 0.4)
	rod.position = Vector3(0, 1.1, 0)
	pivot.add_child(rod)
	tip = Node3D.new()
	tip.position = Vector3(0, 2.2, 0)
	pivot.add_child(tip)

func _blocked(p: Vector2) -> bool:
	if absf(p.x) > 70.0 or p.y < -100.0 or p.y > 40.0:
		return true
	if height_at(p.x, p.y) < -0.45:
		return true
	if p.x > SHOP_POS.x - 3.5 and p.x < SHOP_POS.x + 3.5 and p.y > SHOP_POS.z - 3.0 and p.y < SHOP_POS.z + 3.0:
		return true
	for o in obstacles:
		if Vector2(o.x, o.y).distance_to(p) < o.z + 0.3:
			return true
	return false

func _process(delta: float) -> void:
	_update_time(delta)
	var l: Vector2 = hud.look
	hud.look = Vector2.ZERO
	yaw -= l.x * 0.004 * hud.sens
	pitch = clampf(pitch - l.y * 0.004 * hud.sens, -1.3, 1.3)
	player.rotation.y = yaw
	cam.rotation.x = pitch
	fishing.reel_held = hud.reel_held
	hud.hour = hour
	var mv: Vector2 = hud.move
	if fishing.state == 0 and mv.length() > 0.05 and not hud.modal_open:
		var spd := lerpf(1.7, 4.2, smoothstep(0.6, 1.0, mv.length())) * minf(mv.length(), 1.0)
		var dir := (player.global_transform.basis * Vector3(mv.x, 0.0, mv.y)).normalized()
		var step := Vector2(dir.x, dir.z) * spd * delta
		var p := Vector2(player.position.x, player.position.z)
		if not _blocked(p + step):
			p += step
		elif not _blocked(p + Vector2(step.x, 0.0)):
			p.x += step.x
		elif not _blocked(p + Vector2(0.0, step.y)):
			p.y += step.y
		player.position.x = p.x
		player.position.z = p.y
	var g := maxf(height_at(player.position.x, player.position.z), -0.45)
	py = lerpf(py, g, clampf(delta * 12.0, 0.0, 1.0))
	player.position.y = py
	var sp := Vector2(player.position.x - (SHOP_POS.x + 3.8), player.position.z - SHOP_POS.z)
	hud.set_shop_near(sp.length() < 3.2)
