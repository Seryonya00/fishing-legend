extends Control
# Акционный баннер магазина

var head: String = "АКЦИЯ!"
var line1: String = "Скидка 30% на удочки «ПРО»!"
var line2: String = "Успей купить!"

func _init() -> void:
	custom_minimum_size = Vector2(0, 118)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var f := ThemeDB.fallback_font
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.13, 0.17, 0.22)
	sb.set_corner_radius_all(22)
	sb.border_color = Color(0.45, 0.5, 0.58)
	sb.set_border_width_all(3)
	draw_style_box(sb, Rect2(Vector2.ZERO, size))
	var r := Rect2(Vector2(10, 10), size - Vector2(20, 20))
	draw_dashed_line(r.position, Vector2(r.end.x, r.position.y), Color(0.6, 0.65, 0.72, 0.6), 2.0, 8.0)
	draw_dashed_line(Vector2(r.position.x, r.end.y), r.end, Color(0.6, 0.65, 0.72, 0.6), 2.0, 8.0)
	draw_dashed_line(r.position, Vector2(r.position.x, r.end.y), Color(0.6, 0.65, 0.72, 0.6), 2.0, 8.0)
	draw_dashed_line(Vector2(r.end.x, r.position.y), r.end, Color(0.6, 0.65, 0.72, 0.6), 2.0, 8.0)
	draw_string(f, Vector2(34, 54), head, HORIZONTAL_ALIGNMENT_LEFT, 300, 42, Color(0.93, 0.72, 0.25))
	draw_string(f, Vector2(34, 82), line1, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.6, 22, Color(0.95, 0.97, 1.0))
	draw_string(f, Vector2(34, 104), line2, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.6, 22, Color(0.95, 0.97, 1.0))
	var a := Vector2(size.x - 40, 22)
	var b := Vector2(size.x * 0.52, size.y - 18)
	draw_line(b, a, Color(0.1, 0.1, 0.12), 6.0, true)
	draw_line(b, b.lerp(a, 0.22), Color(0.72, 0.52, 0.28), 10.0, true)
	draw_line(b.lerp(a, 0.2), b.lerp(a, 0.23), Color(0.8, 0.82, 0.86), 11.0, true)
	for i in 5:
		var p := b.lerp(a, 0.4 + 0.12 * float(i))
		draw_arc(p + Vector2(0, -6), 5, 0.0, TAU, 12, Color(0.85, 0.87, 0.9), 1.5)
	for i in 3:
		draw_circle(Vector2(size.x * 0.5 + (i - 1) * 18, size.y - 8), 5, Color(0.95, 0.75, 0.25) if i == 0 else Color(0.5, 0.52, 0.56))
