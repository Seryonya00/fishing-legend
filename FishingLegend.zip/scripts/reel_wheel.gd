extends Control
# Колесо катушки: крути пальцем против часовой — выбирать леску, по часовой — травить.
# Дуга по краю — натяжение лески.

var tension: float = 0.0
var dist: float = 0.0
var angle: float = 0.0
var rush: bool = false
var held: bool = false
var fighting: bool = false

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_d: float) -> void:
	if visible:
		queue_redraw()

func _draw() -> void:
	var c := size * 0.5
	var R := minf(size.x, size.y) * 0.5
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.016)
	var base := Color(0.06, 0.1, 0.13, 0.6)
	if rush and fighting:
		base = Color(0.3 + 0.2 * pulse, 0.08, 0.08, 0.7)
	draw_circle(c, R, base)
	draw_arc(c, R - 9.0, 0.0, TAU, 64, Color(1, 1, 1, 0.12), 11.0, true)
	if fighting:
		var tc := Color(0.3, 0.85, 0.5).lerp(Color(0.95, 0.2, 0.15), clampf((tension - 0.55) * 2.2, 0.0, 1.0))
		draw_arc(c, R - 9.0, -PI * 0.5, -PI * 0.5 + TAU * clampf(tension, 0.0, 1.0), 64, tc, 11.0, true)
	draw_arc(c, R * 0.64, 0.0, TAU, 48, Color(1, 1, 1, 0.28), 2.0, true)
	for i in 3:
		var a := angle + TAU * float(i) / 3.0
		draw_line(c + Vector2(cos(a), sin(a)) * R * 0.22, c + Vector2(cos(a), sin(a)) * R * 0.6, Color(1, 1, 1, 0.3), 3.0)
	var knob := c + Vector2(cos(angle), sin(angle)) * R * 0.5
	draw_circle(knob, R * 0.16, Color(0.55, 0.95, 0.9, 0.9) if held else Color(0.85, 0.92, 0.98, 0.8))
	var f := ThemeDB.fallback_font
	draw_string(f, Vector2(0, c.y + 12.0), "%.0f м" % dist, HORIZONTAL_ALIGNMENT_CENTER, size.x, 34, Color(1, 1, 1, 0.95))
	draw_string(f, Vector2(0, c.y + 40.0), "РЫВОК!" if (rush and fighting) else "колесо", HORIZONTAL_ALIGNMENT_CENTER, size.x, 20, Color(1, 0.8, 0.7, 0.9) if (rush and fighting) else Color(1, 1, 1, 0.5))
