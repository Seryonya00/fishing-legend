extends Control
# Колесо катушки: против часовой — выбирать леску, по часовой — травить.
# Дуга по краю — нагрузка на слабейшее звено (зелёный → красный). В центре — дистанция и фрикцион.

var tension: float = 0.0
var dist: float = 0.0
var angle: float = 0.0
var rush: bool = false
var held: bool = false
var fighting: bool = false
var drag_pct: float = 0.6
var slip: float = 0.0
var weak: String = ""

const NAMES := {"hook": "крючок", "line": "леска", "reel": "катушка", "rod": "удилище"}

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(_d: float) -> void:
	if visible:
		queue_redraw()

func _draw() -> void:
	var c := size * 0.5
	var R := minf(size.x, size.y) * 0.5
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.016)
	var base := Color(0.06, 0.1, 0.13, 0.6)
	if rush and fighting:
		base = Color(0.3 + 0.2 * pulse, 0.08, 0.08, 0.7)
	draw_circle(c, R, base)
	draw_arc(c, R - 9.0, 0.0, TAU, 64, Color(1, 1, 1, 0.12), 11.0, true)
	if fighting:
		var tc := Color(0.3, 0.85, 0.5).lerp(Color(0.95, 0.2, 0.15), clampf((tension - 0.5) * 2.0, 0.0, 1.0))
		draw_arc(c, R - 9.0, -PI * 0.5, -PI * 0.5 + TAU * clampf(tension, 0.0, 1.0), 64, tc, 11.0, true)
		draw_arc(c, R - 9.0, -PI * 0.5 - 0.03, -PI * 0.5 + 0.03, 6, Color(1, 1, 1, 0.8), 14.0)
	draw_arc(c, R * 0.64, 0.0, TAU, 48, Color(1, 1, 1, 0.28), 2.0, true)
	for i in 3:
		var a := angle + TAU * float(i) / 3.0
		draw_line(c + Vector2(cos(a), sin(a)) * R * 0.22, c + Vector2(cos(a), sin(a)) * R * 0.6, Color(1, 1, 1, 0.3), 3.0)
	var knob := c + Vector2(cos(angle), sin(angle)) * R * 0.5
	draw_circle(knob, R * 0.16, Color(0.55, 0.95, 0.9, 0.9) if held else Color(0.85, 0.92, 0.98, 0.8))
	var f := ThemeDB.fallback_font
	draw_string(f, Vector2(0, c.y + 8.0), "%.0f м" % dist, HORIZONTAL_ALIGNMENT_CENTER, size.x, 34, Color(1, 1, 1, 0.95))
	if fighting:
		var line2 := "фрикцион %d%%" % int(round(drag_pct * 100.0))
		var col2 := Color(1, 1, 1, 0.6)
		if slip > 0.05:
			line2 = "ТРЕЩИТ, СТРАВЛИВАЕТ"
			col2 = Color(1.0, 0.85, 0.3, 0.95)
		elif rush:
			line2 = "ПАРОВОЗ!"
			col2 = Color(1, 0.7, 0.6, 0.95)
		draw_string(f, Vector2(0, c.y + 34.0), line2, HORIZONTAL_ALIGNMENT_CENTER, size.x, 19, col2)
		draw_string(f, Vector2(0, c.y + 56.0), "слабое звено: %s" % str(NAMES.get(weak, weak)), HORIZONTAL_ALIGNMENT_CENTER, size.x, 16, Color(1, 1, 1, 0.5))
	else:
		draw_string(f, Vector2(0, c.y + 34.0), "колесо", HORIZONTAL_ALIGNMENT_CENTER, size.x, 20, Color(1, 1, 1, 0.5))
