extends Control
# Крупный рисунок удилища для инвентаря

var type: String = "float"

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var a := Vector2(size.x * 0.12, size.y * 0.92)
	var b := Vector2(size.x * 0.9, size.y * 0.06)
	var d := (b - a)
	var cork := Color(0.74, 0.55, 0.3)
	var blank := Color(0.08, 0.08, 0.1)
	var metal := Color(0.8, 0.82, 0.87)
	draw_line(a, a + d * 0.12, Color(0.06, 0.06, 0.07), 18.0, true)
	draw_line(a + d * 0.12, a + d * 0.3, cork, 16.0, true)
	draw_line(a + d * 0.3, a + d * 0.33, metal, 17.0, true)
	draw_line(a + d * 0.33, b, blank, 8.0, true)
	for i in 6:
		var p := a + d * (0.45 + 0.1 * float(i))
		draw_arc(p + Vector2(8, 8), 8.0 - float(i) * 0.8, 0.0, TAU, 14, metal, 2.0)
	if type != "float":
		var rc := a + d * 0.4 + Vector2(30, 30)
		draw_circle(rc, 34, Color(0.2, 0.22, 0.26))
		draw_circle(rc, 26, Color(0.75, 0.6, 0.25))
		draw_circle(rc, 10, Color(0.15, 0.16, 0.2))
		draw_arc(rc, 36, 0.0, TAU, 28, metal, 3.0)
		draw_line(rc + Vector2(30, 6), rc + Vector2(58, 34), metal, 5.0)
		draw_circle(rc + Vector2(60, 36), 7, metal)
		draw_line(rc, a + d * 0.5, Color(1, 1, 1, 0.25), 1.5)
	else:
		draw_circle(a + d * 0.5, 6, Color(0.95, 0.25, 0.2))
