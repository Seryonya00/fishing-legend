extends Control
# Плоская круглая / «таблеточная» кнопка, рисуется кодом (без картинок)

var text: String = "":
	set(v):
		text = v
		queue_redraw()
var icon: String = ""
var shape: String = "circle"
var accent: Color = Color(0.3, 0.8, 0.75)
var font_size: int = 24
var held: bool = false:
	set(v):
		held = v
		queue_redraw()
var active: bool = false:
	set(v):
		if v != active:
			active = v
			queue_redraw()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var fill := Color(0.06, 0.1, 0.13, 0.66)
	var ring := accent
	if held:
		fill = Color(accent.r * 0.5, accent.g * 0.5, accent.b * 0.5, 0.9)
	if active:
		fill = Color(0.75, 0.22, 0.18, 0.85)
		ring = Color(1.0, 0.75, 0.65)
	var c := size * 0.5
	var rad := minf(size.x, size.y) * 0.5
	if shape == "circle":
		draw_circle(c, rad, fill)
		draw_arc(c, rad - 2.0, 0.0, TAU, 56, ring, 3.0, true)
	else:
		var sb := StyleBoxFlat.new()
		sb.bg_color = fill
		sb.set_corner_radius_all(int(rad))
		sb.border_color = ring
		sb.set_border_width_all(2)
		draw_style_box(sb, Rect2(Vector2.ZERO, size))
	var col := Color(0.95, 0.98, 1.0)
	var ty: float = c.y + font_size * 0.35
	if icon != "" and shape == "circle":
		_icon(c + Vector2(0, -rad * 0.22), rad * 0.38, col)
		ty = size.y - rad * 0.2
		draw_string(ThemeDB.fallback_font, Vector2(0, ty), text, HORIZONTAL_ALIGNMENT_CENTER, size.x, int(font_size * 0.72), col)
	else:
		draw_string(ThemeDB.fallback_font, Vector2(0, ty), text, HORIZONTAL_ALIGNMENT_CENTER, size.x, font_size, col)

func _icon(p: Vector2, r: float, col: Color) -> void:
	match icon:
		"cast":
			draw_arc(p + Vector2(0, r * 0.5), r, PI * 1.05, PI * 1.95, 24, col, 4.0, true)
			draw_colored_polygon(PackedVector2Array([p + Vector2(r * 1.15, r * 0.35), p + Vector2(r * 0.55, r * 0.35), p + Vector2(r * 0.9, r * 0.95)]), col)
		"lift":
			draw_colored_polygon(PackedVector2Array([p + Vector2(0, -r), p + Vector2(r * 0.9, r * 0.1), p + Vector2(-r * 0.9, r * 0.1)]), col)
			draw_rect(Rect2(p + Vector2(-r * 0.28, r * 0.1), Vector2(r * 0.56, r * 0.9)), col)
		"menu":
			for i in 3:
				draw_rect(Rect2(p + Vector2(-r * 0.8, -r * 0.7 + i * r * 0.7), Vector2(r * 1.6, r * 0.22)), col)
		"drop":
			for i in 5:
				var a := TAU * float(i) / 5.0
				draw_circle(p + Vector2(cos(a), sin(a)) * r * 0.7, r * 0.2, col)
			draw_circle(p, r * 0.22, col)
