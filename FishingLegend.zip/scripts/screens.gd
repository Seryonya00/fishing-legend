extends Node
# Полноэкранные экраны в едином стиле: главное меню, слоты сохранений, настройки,
# валюта, поддержка, магазин, приём рыбы, рынок, инвентарь, задания.

const Data = preload("res://scripts/data.gd")
const ShopCard = preload("res://scripts/shop_card.gd")
const FancyBg = preload("res://scripts/fancy_bg.gd")
const Pill = preload("res://scripts/currency_pill.gd")
const Banner = preload("res://scripts/promo_banner.gd")
const TitleArt = preload("res://scripts/title_art.gd")
const RodArt = preload("res://scripts/rod_art.gd")

const SHOP_TABS := [["rods", "Удочки"], ["line", "Леска"], ["gear", "Снасти"], ["lures", "Приманки"], ["bait", "Наживка"], ["acc", "Аксессуары"]]

var hud
var world
var audio

var _theme: Theme
var _roots: Array = []
var _pills: Array = []
var _msg: Label
var _msg_t: float = 0.0
var _title: Control
var _title_col: VBoxContainer
var _btn_continue: Button
var _slots_scr: Control
var _slots_list: VBoxContainer
var _slots_mode: String = "load"
var _slots_confirm: int = -1
var _settings: Control
var _settings_list: VBoxContainer
var _currency: Control
var _support: Control
var _shop: Control
var _shop_cat: String = "rods"
var _shop_tabs: HBoxContainer
var _shop_grid: GridContainer
var _shop_banner: Control
var _sell: Control
var _sell_grid: GridContainer
var _sell_info: Label
var _sell_all: Button
var _market: Control
var _market_grid: GridContainer
var _market_info: Label
var _quests: Control
var _quests_grid: GridContainer
var _inv: Control
var _inv_slot: int = 0
var _inv_tabs: HBoxContainer
var _inv_left: VBoxContainer
var _inv_right: VBoxContainer
var _inv_chips: HBoxContainer
var _inv_art
var _inv_info: Label
var _picker: Control
var _picker_title: Label
var _picker_body: ScrollContainer

func setup(h, w, a) -> void:
	hud = h
	world = w
	audio = a
	_theme = Theme.new()
	_theme.set_font_size("font_size", "Label", 26)
	_theme.set_color("font_color", "Label", Color(0.93, 0.96, 0.98))
	_msg = _lbl("", 28)
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(_msg)
	_msg.anchor_left = 0.15
	_msg.anchor_right = 0.85
	_msg.anchor_top = 1.0
	_msg.anchor_bottom = 1.0
	_msg.offset_top = -150
	_msg.offset_bottom = -90

func _process(delta: float) -> void:
	_msg_t -= delta
	if _msg != null:
		_msg.modulate = Color(1, 1, 1, clampf(_msg_t, 0.0, 1.0))
	for p in _pills:
		var v: int = State.silver if p.kind == "silver" else State.gold
		if p.amount != v:
			p.amount = v

func say(text: String) -> void:
	if _msg == null:
		hud.toast(text)
		return
	_msg.text = text
	_msg_t = 2.6
	_msg.move_to_front()

# ---------- общие элементы ----------

func _box(c: Color, rad: int, bc: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(rad)
	s.border_color = bc
	s.set_border_width_all(bw)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func _lbl(text: String, fs: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 5)
	return l

func _bbtn(text: String, cb: Callable, h: int = 62) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_font_size_override("font_size", 26)
	b.add_theme_color_override("font_color", Color(1, 1, 1))
	b.add_theme_color_override("font_disabled_color", Color(0.55, 0.58, 0.62))
	b.add_theme_stylebox_override("normal", _box(Color(0.13, 0.32, 0.56), 28, Color(0.9, 0.75, 0.4), 3))
	b.add_theme_stylebox_override("hover", _box(Color(0.17, 0.38, 0.64), 28, Color(0.95, 0.8, 0.45), 3))
	b.add_theme_stylebox_override("pressed", _box(Color(0.09, 0.24, 0.45), 28, Color(0.9, 0.75, 0.4), 3))
	b.add_theme_stylebox_override("disabled", _box(Color(0.14, 0.17, 0.21), 28, Color(0.35, 0.37, 0.4), 3))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(cb)
	return b

func _clear(c: Node) -> void:
	for ch in c.get_children():
		c.remove_child(ch)
		ch.queue_free()

func _screen(title: String, pills: bool = true, closable: bool = true) -> Dictionary:
	var root := ColorRect.new()
	root.color = Color(0.03, 0.08, 0.14, 1.0)
	root.theme = _theme
	root.visible = false
	hud.add_child(root)
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := FancyBg.new()
	root.add_child(bg)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var mg := MarginContainer.new()
	for side in ["left", "right"]:
		mg.add_theme_constant_override("margin_" + side, 28)
	mg.add_theme_constant_override("margin_top", 16)
	mg.add_theme_constant_override("margin_bottom", 16)
	root.add_child(mg)
	mg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	mg.add_child(vb)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	vb.add_child(head)
	var t := _lbl(title, 44)
	t.add_theme_color_override("font_color", Color(0.72, 0.8, 0.88))
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	if pills:
		var p1 = Pill.new()
		p1.kind = "silver"
		head.add_child(p1)
		var p2 = Pill.new()
		p2.kind = "gold"
		head.add_child(p2)
		_pills.append(p1)
		_pills.append(p2)
	if closable:
		var cb := _bbtn("Назад", _close.bind(root), 52)
		cb.custom_minimum_size = Vector2(150, 52)
		head.add_child(cb)
	_roots.append(root)
	return {"root": root, "vb": vb}

func _tabbar(tabs: Array, current: String, cb: Callable, hb: HBoxContainer) -> void:
	_clear(hb)
	for tb in tabs:
		var b := Button.new()
		b.text = str(tb[1])
		b.flat = true
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.custom_minimum_size = Vector2(0, 54)
		b.add_theme_font_size_override("font_size", 24)
		var on: bool = tb[0] == current
		b.add_theme_color_override("font_color", Color(1, 1, 1) if on else Color(0.75, 0.8, 0.86))
		b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
		b.add_theme_color_override("font_pressed_color", Color(1, 1, 1))
		var empty := StyleBoxEmpty.new()
		var sel := _box(Color(0.3, 0.34, 0.4), 20, Color(0.75, 0.8, 0.86), 2)
		b.add_theme_stylebox_override("normal", sel if on else empty)
		b.add_theme_stylebox_override("hover", sel if on else empty)
		b.add_theme_stylebox_override("pressed", sel)
		b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		b.pressed.connect(cb.bind(tb[0]))
		hb.add_child(b)

func _tabholder(parent: Control) -> HBoxContainer:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", _box(Color(0.2, 0.23, 0.27, 0.95), 24, Color(0.5, 0.54, 0.6), 2))
	parent.add_child(pc)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 6)
	pc.add_child(hb)
	return hb

func _scroll_grid(parent: Control, cols: int) -> GridContainer:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	parent.add_child(sc)
	var g := GridContainer.new()
	g.columns = cols
	g.add_theme_constant_override("h_separation", 14)
	g.add_theme_constant_override("v_separation", 14)
	sc.add_child(g)
	return g

func _card(it: Dictionary) -> Control:
	var c = ShopCard.new()
	c.kind = str(it.get("kind", ""))
	c.title = str(it.get("title", ""))
	c.stat = str(it.get("stat", ""))
	c.price = int(it.get("price", 0))
	c.status = str(it.get("status", "buy"))
	c.lvl = int(it.get("lvl", 1))
	c.btn_text = str(it.get("btn", ""))
	c.price_text = str(it.get("ptext", ""))
	c.coin = str(it.get("coin", "silver"))
	if it.has("tint"):
		c.tint = it["tint"]
	c.custom_minimum_size = Vector2(268, 338)
	c.activated.connect(it["cb"])
	return c

func _noop() -> void:
	pass

func _open(root: Control) -> void:
	root.visible = true
	root.move_to_front()
	if _msg != null:
		_msg.move_to_front()
	_fit(root)
	hud.screen_open = true
	hud._release_all()
	hud._recalc_modal()
	hud.get_tree().create_timer(0.4).timeout.connect(_verify.bind(root))

func _fit(root: Control) -> void:
	var vp: Vector2 = hud.get_viewport().get_visible_rect().size
	root.position = Vector2.ZERO
	root.size = vp
	for ch in root.get_children():
		if ch is Control and ch != _title_col:
			var c := ch as Control
			if c.anchor_left == 0.0 and c.anchor_top == 0.0 and c.anchor_right == 1.0 and c.anchor_bottom == 1.0:
				c.position = Vector2.ZERO
				c.size = vp
	if root == _title and _title_col != null:
		_title_col.position = Vector2(vp.x - 470.0, 40.0)
		_title_col.size = Vector2(434.0, vp.y - 76.0)

# защита: если экран не удалось показать (нулевой размер), не блокируем игру
func _verify(root: Control) -> void:
	if not root.visible:
		return
	var r: Rect2 = root.get_global_rect()
	if r.size.x < 200.0 or r.size.y < 100.0:
		root.visible = false
		hud.screen_open = is_open()
		hud._recalc_modal()
		hud.toast("Не удалось показать экран")

func _close(root: Control) -> void:
	root.visible = false
	hud.screen_open = is_open()
	hud._recalc_modal()
	if world != null and world.started:
		State.save_game()

func is_open() -> bool:
	for r in _roots:
		if r.visible:
			return true
	return false

func open_door(id: String) -> void:
	match id:
		"shop":
			_build_shop()
			_shop_refresh()
			_open(_shop)
		"sell":
			_build_sell()
			_sell_refresh()
			_open(_sell)
		"market":
			_build_market()
			_market_refresh()
			_open(_market)
		"boat":
			world.toggle_boat()

func open_inventory() -> void:
	_build_inventory()
	_build_picker()
	_inv_slot = clampi(State.cur, 0, 2)
	_inv_refresh()
	_open(_inv)

func open_quests() -> void:
	_build_quests()
	_quests_refresh()
	_open(_quests)

func open_settings() -> void:
	_build_settings()
	_settings_refresh()
	_open(_settings)

func _build_title() -> void:
	if _title != null:
		return
	var s := _screen("", false, false)
	_title = s["root"]
	var vb: VBoxContainer = s["vb"]
	vb.get_parent().queue_free()
	var art = TitleArt.new()
	_title.add_child(art)
	art.set_anchors_preset(Control.PRESET_FULL_RECT)
	var logo := _lbl("FISHING\nLEGEND", 84)
	logo.add_theme_color_override("font_color", Color(0.78, 0.86, 0.94))
	logo.add_theme_constant_override("outline_size", 12)
	logo.add_theme_constant_override("line_spacing", -14)
	_title.add_child(logo)
	logo.position = Vector2(48, 36)
	var sub := _lbl("Рыбалка нового уровня", 28)
	sub.add_theme_color_override("font_color", Color(0.93, 0.75, 0.3))
	_title.add_child(sub)
	sub.position = Vector2(56, 232)
	var col := VBoxContainer.new()
	_title_col = col
	col.add_theme_constant_override("separation", 9)
	_title.add_child(col)
	col.anchor_left = 1.0
	col.anchor_right = 1.0
	col.anchor_top = 0.0
	col.anchor_bottom = 1.0
	col.offset_left = -470
	col.offset_right = -36
	col.offset_top = 40
	col.offset_bottom = -36
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(_bbtn("Новая игра", _on_new))
	_btn_continue = _bbtn("Продолжить игру", _on_continue)
	col.add_child(_btn_continue)
	col.add_child(_bbtn("Загрузить игру", _on_load))
	col.add_child(_bbtn("Настройки", open_settings))
	col.add_child(_bbtn("Покупка валюты", _open_currency))
	col.add_child(_bbtn("Поддержка разработчиков", _open_support))
	col.add_child(_bbtn("Выход", _quit))

func show_title() -> void:
	_build_title()
	_btn_continue.disabled = not State.has_any()
	_open(_title)

func _on_new() -> void:
	_build_slots()
	_slots_mode = "new"
	_slots_confirm = -1
	_slots_refresh()
	_open(_slots_scr)

func _on_load() -> void:
	_build_slots()
	_slots_mode = "load"
	_slots_refresh()
	_open(_slots_scr)

func _on_continue() -> void:
	_close(_title)

func _start() -> void:
	if _slots_scr != null:
		_slots_scr.visible = false
	if _title != null:
		_title.visible = false
	hud.screen_open = is_open()
	hud._recalc_modal()
	world.start_game()

func _open_currency() -> void:
	_build_currency()
	_open(_currency)

func _open_support() -> void:
	_build_support()
	_open(_support)

func _quit() -> void:
	State.save_game()
	get_tree().quit()

# ---------- слоты сохранений ----------

func _build_slots() -> void:
	if _slots_scr != null:
		return
	var s := _screen("СОХРАНЕНИЯ", false)
	_slots_scr = s["root"]
	var vb: VBoxContainer = s["vb"]
	_slots_list = VBoxContainer.new()
	_slots_list.add_theme_constant_override("separation", 14)
	_slots_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(_slots_list)

func _slots_refresh() -> void:
	_clear(_slots_list)
	var hint := "Выберите слот для новой игры" if _slots_mode == "new" else "Выберите сохранение для загрузки"
	_slots_list.add_child(_lbl(hint, 28))
	for i in range(1, State.SLOTS + 1):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var info: Dictionary = State.slot_info(i)
		var txt := "Слот %d — пусто" % i
		if not info.is_empty():
			txt = "Слот %d\nУр. %d · %d серебра · %s · рыб поймано: %d" % [i, int(info["level"]), int(info["silver"]), str(Data.LOCS.get(info["loc"], Data.LOCS["pond"])["name"]), int(info["fish"])]
		if _slots_mode == "new" and _slots_confirm == i:
			txt = "Слот %d будет ПЕРЕЗАПИСАН.\nНажмите ещё раз для подтверждения" % i
		var b := _bbtn(txt, _slot_pressed.bind(i), 110)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.disabled = _slots_mode == "load" and info.is_empty()
		row.add_child(b)
		if _slots_mode == "load" and not info.is_empty():
			var d := _bbtn("Удалить", _slot_delete.bind(i), 110)
			d.custom_minimum_size = Vector2(170, 110)
			row.add_child(d)
		_slots_list.add_child(row)
	_slots_list.add_child(_bbtn("Войти через Google Play Игры (облако)", _google_play, 66))

func _slot_pressed(i: int) -> void:
	if _slots_mode == "load":
		if State.load_slot(i):
			_start()
		return
	if State.has_save(i) and _slots_confirm != i:
		_slots_confirm = i
		_slots_refresh()
		return
	State.new_game(i)
	_start()

func _slot_delete(i: int) -> void:
	State.delete_slot(i)
	say("Сохранение удалено")
	_slots_refresh()

func _google_play() -> void:
	say("Google Play Игры: нужны плагин и приложение в Play Console — подключим при публикации")

# ---------- настройки ----------

func _build_settings() -> void:
	if _settings != null:
		return
	var s := _screen("НАСТРОЙКИ", false)
	_settings = s["root"]
	var vb: VBoxContainer = s["vb"]
	_settings_list = VBoxContainer.new()
	_settings_list.add_theme_constant_override("separation", 12)
	vb.add_child(_settings_list)

func _settings_refresh() -> void:
	_clear(_settings_list)
	_settings_list.add_child(_bbtn("Звук: %s" % ("выкл" if audio.muted else "вкл"), _set_sound))
	_settings_list.add_child(_bbtn("Музыка: %s" % ("вкл" if audio.music_on else "выкл"), _set_music))
	_settings_list.add_child(_bbtn("Графика: %s" % ["Низкая", "Средняя", "Высокая"][hud._quality], _set_quality))
	_settings_list.add_child(_bbtn("Лимит FPS: %d" % hud._fps, _set_fps))
	_settings_list.add_child(_bbtn("Чувствительность обзора: %.1f" % hud.sens, _set_sens))

func _set_sound() -> void:
	audio.set_muted(not audio.muted)
	_settings_refresh()

func _set_music() -> void:
	audio.music_on = not audio.music_on
	_settings_refresh()

func _set_quality() -> void:
	hud._cycle_quality()
	_settings_refresh()

func _set_fps() -> void:
	hud._cycle_fps()
	_settings_refresh()

func _set_sens() -> void:
	hud._cycle_sens()
	_settings_refresh()

# ---------- валюта и поддержка ----------

func _build_currency() -> void:
	if _currency != null:
		return
	var s := _screen("ПОКУПКА ВАЛЮТЫ")
	_currency = s["root"]
	var g := _scroll_grid(s["vb"], 4)
	for pk in [["100 золота", "Стартовый набор", "99 ₽"], ["550 золота", "+10% бонус", "449 ₽"], ["1 200 золота", "+20% бонус", "899 ₽"], ["2 600 золота", "+30% бонус", "1 790 ₽"]]:
		g.add_child(_card({"kind": "gold", "title": pk[0], "stat": pk[1], "status": "buy", "ptext": pk[2], "coin": "gold", "cb": _pay_placeholder}))

func _pay_placeholder() -> void:
	say("Покупки Google Play будут подключены при публикации игры")

func _build_support() -> void:
	if _support != null:
		return
	var s := _screen("ПОДДЕРЖКА РАЗРАБОТЧИКОВ", false)
	_support = s["root"]
	var vb: VBoxContainer = s["vb"]
	var l := _lbl("Спасибо, что играете в Fishing Legend!\nЕсли игра нравится — оставьте отзыв и расскажите друзьям.\nСсылки на страницу игры и поддержку появятся после публикации.", 28)
	vb.add_child(l)
	vb.add_child(_bbtn("Оценить игру", _pay_placeholder))
	vb.add_child(_bbtn("Поддержать разработчиков", _pay_placeholder))

# ---------- магазин (здание «Магазин») ----------

func _build_shop() -> void:
	if _shop != null:
		return
	var s := _screen("МАГАЗИН РЫБАЛКИ")
	_shop = s["root"]
	var vb: VBoxContainer = s["vb"]
	_shop_tabs = _tabholder(vb)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 14)
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(inner)
	_shop_banner = Banner.new()
	inner.add_child(_shop_banner)
	_shop_grid = GridContainer.new()
	_shop_grid.columns = 4
	_shop_grid.add_theme_constant_override("h_separation", 14)
	_shop_grid.add_theme_constant_override("v_separation", 14)
	inner.add_child(_shop_grid)

func _shop_tab(cat: String) -> void:
	_shop_cat = cat
	_shop_refresh()

func _shop_refresh() -> void:
	_tabbar(SHOP_TABS, _shop_cat, _shop_tab, _shop_tabs)
	_shop_banner.visible = _shop_cat == "rods"
	_clear(_shop_grid)
	for it in _shop_items(_shop_cat):
		_shop_grid.add_child(_card(it))

func _pay(price: int) -> bool:
	if State.silver < price:
		say("Не хватает серебра")
		return false
	State.silver -= price
	return true

func _bought(text: String) -> void:
	State.save_game()
	say(text)
	_shop_refresh()

func _shop_items(cat: String) -> Array:
	var out: Array = []
	match cat:
		"rods":
			for cls in Data.CLASS_ORDER:
				var tier: int = int(State.rods.get(cls, -1))
				for i in 3:
					var r: Dictionary = Data.ROD_CLASSES[cls][i]
					var stt := "locked"
					if i == tier:
						stt = "equipped"
					elif i < tier:
						stt = "owned"
					elif i == tier + 1 and State.level() >= int(r["lvl"]):
						stt = "buy"
					out.append({"kind": "rod", "title": r["name"], "stat": "Тест %.1f кг, бросок %d м. %s" % [float(r["kg"]), int(r["range"]), Data.CLASS_NAMES[cls]], "price": Data.rod_price(i, int(r["price"])), "lvl": int(r["lvl"]), "status": stt, "cb": _buy_rod.bind(cls, i)})
		"line":
			for i in Data.LINES.size():
				var l: Dictionary = Data.LINES[i]
				var st2 := "buy"
				if i == State.line:
					st2 = "equipped"
				elif i <= State.line_best:
					st2 = "owned"
				out.append({"kind": "line", "title": l["name"], "stat": "Выдерживает до %.1f кг" % float(l["kg"]), "price": l["price"], "status": st2, "cb": _buy_line.bind(i)})
		"gear":
			for i in Data.HOOKS.size():
				out.append(_gear_item("hook", i, Data.HOOKS[i], "Размер рыбы: " + ["мелкая", "средняя", "крупная"][i]))
			for i in Data.FLOATS.size():
				out.append(_gear_item("float", i, Data.FLOATS[i], "Грузоподъёмность %d г" % int(Data.FLOATS[i]["cap"])))
			for i in Data.FEEDERS.size():
				out.append(_gear_item("feeder", i, Data.FEEDERS[i], "Вес %d г, держит прикормку" % int(Data.FEEDERS[i]["w"])))
		"lures":
			for i in Data.LURES.size():
				var lu: Dictionary = Data.LURES[i]
				var dr: Array = lu["depth"]
				out.append(_gear_item("lure", i, lu, "Работает на глубине %.1f–%.1f м" % [float(dr[0]), float(dr[1])]))
		"bait":
			for id in Data.BAITS:
				var bd: Dictionary = Data.BAITS[id]
				out.append({"kind": id, "title": "%s ×10" % bd["name"], "stat": "В запасе: %d шт." % int(State.baits.get(id, 0)), "price": bd["price"], "status": "buy", "cb": _buy_bait.bind(id)})
		"acc":
			for i in Data.SIGNALS.size():
				out.append(_gear_item("sig", i, Data.SIGNALS[i], "Сигнал поклёвки для фидера"))
				out[out.size() - 1]["kind"] = "bell" if i == 0 else "alarm"
			for i in [1, 2]:
				var sst := "locked"
				if State.stands > i:
					sst = "owned"
				elif State.stands == i:
					sst = "buy"
				out.append({"kind": "stand", "title": "Подставка №%d" % (i + 1), "stat": "Ещё одна удочка в воде", "price": Data.STAND_PRICES[i], "status": sst, "cb": _buy_stand.bind(i)})
			out.append({"kind": "line", "title": "Замена лески", "stat": "Износ лески: %d%%. Новая леска — как с завода" % int(100.0 - State.line_cond), "price": 60, "status": "buy", "cb": _buy_spool})
			out.append({"kind": "rod", "title": "Ремонт удилища и колец", "stat": "Износ удилища %d%%, колец %d%%" % [int(100.0 - State.rod_cond), int(100.0 - State.guide_cond)], "price": 90, "status": "buy", "cb": _buy_rod_fix})
			out.append({"kind": "reel", "title": "Обслуживание катушки", "stat": "Износ катушки %d%%" % int(100.0 - State.reel_cond), "price": 70, "status": "buy", "cb": _buy_reel_fix})
	return out

func _gear_item(prefix: String, i: int, item: Dictionary, stat: String) -> Dictionary:
	var key := "%s%d" % [prefix, i]
	return {"kind": prefix, "title": item["name"], "stat": stat, "price": item["price"], "status": "owned" if State.owned.has(key) else "buy", "cb": _buy_gear.bind(key, int(item["price"]))}

func _buy_rod(cls: String, i: int) -> void:
	var r: Dictionary = Data.ROD_CLASSES[cls][i]
	if i != int(State.rods.get(cls, -1)) + 1:
		return
	if State.level() < int(r["lvl"]):
		say("Нужен уровень %d" % int(r["lvl"]))
		return
	if not _pay(Data.rod_price(i, int(r["price"]))):
		return
	State.rods[cls] = i
	_bought("Куплено: %s" % str(r["name"]))

func _buy_line(i: int) -> void:
	if i == State.line:
		return
	if i <= State.line_best:
		State.line = i
		State.save_game()
		say("Леска выбрана")
		_shop_refresh()
		return
	if not _pay(int(Data.LINES[i]["price"])):
		return
	State.line_best = i
	State.line = i
	State.line_cond = 100.0
	_bought("Куплена новая леска")

func _buy_gear(key: String, price: int) -> void:
	if State.owned.has(key):
		return
	if not _pay(price):
		return
	State.owned[key] = true
	_bought("Покупка совершена")

func _buy_bait(id: String) -> void:
	if not _pay(int(Data.BAITS[id]["price"])):
		return
	State.baits[id] = int(State.baits.get(id, 0)) + 10
	_bought("Куплено 10 шт.")

func _buy_stand(i: int) -> void:
	if State.stands > i:
		return
	if i != State.stands:
		say("Сначала купите предыдущую подставку")
		return
	if not _pay(int(Data.STAND_PRICES[i])):
		return
	State.stands = i + 1
	_bought("Куплена подставка №%d" % (i + 1))

func _buy_rod_fix() -> void:
	if not _pay(90):
		return
	State.rod_cond = 100.0
	State.guide_cond = 100.0
	_bought("Удилище и кольца отремонтированы")

func _buy_reel_fix() -> void:
	if not _pay(70):
		return
	State.reel_cond = 100.0
	_bought("Катушка обслужена")

func _buy_spool() -> void:
	if not _pay(60):
		return
	State.line_cond = 100.0
	_bought("Леска заменена")

# ---------- приём рыбы ----------

func _build_sell() -> void:
	if _sell != null:
		return
	var s := _screen("ПРИЁМ РЫБЫ")
	_sell = s["root"]
	var vb: VBoxContainer = s["vb"]
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	vb.add_child(row)
	_sell_info = _lbl("", 28)
	_sell_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(_sell_info)
	_sell_all = _bbtn("Продать всё", _sell_everything)
	_sell_all.custom_minimum_size = Vector2(330, 62)
	row.add_child(_sell_all)
	_sell_grid = _scroll_grid(vb, 4)

func _net_value() -> int:
	var t := 0.0
	for f in State.keepnet:
		t += float(f["w"]) * float(Data.FISH[f["id"]]["kg_price"])
	return int(t)

func _fish_tint(id: String) -> Color:
	var c: Array = Data.FISH[id]["col"]
	return Color(float(c[0]), float(c[1]), float(c[2]))

func _sell_refresh() -> void:
	_sell_info.text = "В садке рыб: %d" % State.keepnet.size()
	_sell_all.text = "Продать всё (+%d)" % _net_value()
	_sell_all.disabled = State.keepnet.is_empty()
	_clear(_sell_grid)
	for i in State.keepnet.size():
		var f: Dictionary = State.keepnet[i]
		var fd: Dictionary = Data.FISH[f["id"]]
		var pr: int = int(round(float(f["w"]) * float(fd["kg_price"])))
		_sell_grid.add_child(_card({"kind": "fish", "title": fd["name"], "stat": "%.2f кг · %d см" % [float(f["w"]), int(f.get("len", 0))], "price": pr, "status": "sell", "tint": _fish_tint(f["id"]), "cb": _sell_one.bind(i)}))

func _sell_one(i: int) -> void:
	if i >= State.keepnet.size():
		return
	var f: Dictionary = State.keepnet[i]
	var pr: int = int(round(float(f["w"]) * float(Data.FISH[f["id"]]["kg_price"])))
	State.silver += pr
	State.keepnet.remove_at(i)
	State.save_game()
	say("Продано: +%d серебра" % pr)
	_sell_refresh()

func _sell_everything() -> void:
	var t := _net_value()
	State.silver += t
	State.keepnet = []
	State.save_game()
	say("Продано всё: +%d серебра" % t)
	_sell_refresh()

# ---------- рынок: эксклюзивные заказы ×2 ----------

func _build_market() -> void:
	if _market != null:
		return
	var s := _screen("РЫНОК")
	_market = s["root"]
	var vb: VBoxContainer = s["vb"]
	_market_info = _lbl("", 26)
	vb.add_child(_market_info)
	_market_grid = _scroll_grid(vb, 4)

func _market_cycle() -> int:
	var cyc: int = int(State.total_hours / 48.0)
	if int(State.market.get("cycle", -1)) != cyc:
		State.market = {"cycle": cyc, "n": [0, 0, 0, 0]}
	return cyc

func _market_refresh() -> void:
	var cyc := _market_cycle()
	var left: float = 48.0 - fmod(State.total_hours, 48.0)
	_market_info.text = "Редкая рыба от 3 кг — цена ×2. Новые заказы через %d ч (игровое время)" % int(ceil(left))
	_clear(_market_grid)
	var orders: Array = Data.market_orders(cyc)
	for i in orders.size():
		var o: Dictionary = orders[i]
		var fd: Dictionary = Data.FISH[o["fish"]]
		var done: int = int(State.market["n"][i])
		var rest: int = int(o["need"]) - done
		_market_grid.add_child(_card({"kind": "fish", "title": fd["name"], "stat": "От %.1f кг. Нужно: %d, осталось: %d" % [float(o["min"]), int(o["need"]), rest], "ptext": "×2: %d/кг" % (int(fd["kg_price"]) * 2), "status": "sell" if rest > 0 else "done", "tint": _fish_tint(o["fish"]), "cb": _market_sell.bind(i)}))

func _market_sell(i: int) -> void:
	var cyc := _market_cycle()
	var orders: Array = Data.market_orders(cyc)
	var o: Dictionary = orders[i]
	if int(State.market["n"][i]) >= int(o["need"]):
		return
	var best := -1
	for k in State.keepnet.size():
		var f: Dictionary = State.keepnet[k]
		if str(f["id"]) == str(o["fish"]) and float(f["w"]) >= float(o["min"]):
			if best < 0 or float(f["w"]) < float(State.keepnet[best]["w"]):
				best = k
	if best < 0:
		say("В садке нет подходящей рыбы")
		return
	var fish: Dictionary = State.keepnet[best]
	var pr: int = int(round(float(fish["w"]) * float(Data.FISH[fish["id"]]["kg_price"]) * Data.MARKET_MULT))
	State.silver += pr
	State.keepnet.remove_at(best)
	State.market["n"][i] = int(State.market["n"][i]) + 1
	State.save_game()
	say("Продано на рынке: +%d серебра" % pr)
	_market_refresh()

# ---------- задания и достижения ----------

func _build_quests() -> void:
	if _quests != null:
		return
	var s := _screen("ЗАДАНИЯ")
	_quests = s["root"]
	_quests_grid = _scroll_grid(s["vb"], 4)

func _quests_refresh() -> void:
	_clear(_quests_grid)
	for i in State.quests.size():
		var q: Dictionary = State.quests[i]
		var done: bool = bool(q["done"])
		_quests_grid.add_child(_card({"kind": "quest", "title": "Задание %d" % (i + 1), "stat": "%s. Награда: %d серебра. %d/%d" % [State.quest_text(q), int(q["silver"]), int(q["got"]), int(q["need"])], "status": "sell" if done else "owned", "btn": "ЗАБРАТЬ" if done else "В ПРОЦЕССЕ", "ptext": "+%d опыта" % int(q["xp"]), "cb": _claim.bind(i)}))
	for a in Data.ACH:
		var got: bool = State.ach.has(a["id"])
		_quests_grid.add_child(_card({"kind": "gold", "title": a["name"], "stat": a["desc"], "status": "done" if got else "owned", "btn": "" if got else "НЕ ПОЛУЧЕНО", "cb": _noop}))

func _claim(i: int) -> void:
	if State.claim_quest(i):
		say("Награда получена")
		_quests_refresh()

# ---------- инвентарь (сборка снасти) ----------

func _build_inventory() -> void:
	if _inv != null:
		return
	var s := _screen("ИНВЕНТАРЬ")
	_inv = s["root"]
	var vb: VBoxContainer = s["vb"]
	_inv_tabs = _tabholder(vb)
	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 18)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(body)
	_inv_left = VBoxContainer.new()
	_inv_left.add_theme_constant_override("separation", 8)
	body.add_child(_inv_left)
	var mid := VBoxContainer.new()
	mid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mid.add_theme_constant_override("separation", 8)
	body.add_child(mid)
	_inv_art = RodArt.new()
	_inv_art.custom_minimum_size = Vector2(380, 290)
	_inv_art.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid.add_child(_inv_art)
	_inv_chips = HBoxContainer.new()
	_inv_chips.add_theme_constant_override("separation", 8)
	mid.add_child(_inv_chips)
	_inv_right = VBoxContainer.new()
	_inv_right.add_theme_constant_override("separation", 8)
	body.add_child(_inv_right)
	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 14)
	vb.add_child(bottom)
	_inv_info = _lbl("", 22)
	_inv_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_inv_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bottom.add_child(_inv_info)
	var sv := _bbtn("СОХРАНИТЬ", _inv_save)
	sv.custom_minimum_size = Vector2(300, 62)
	bottom.add_child(sv)

func _inv_tab(key: String) -> void:
	var i: int = int(key)
	if i >= State.stands:
		say("Нужна подставка — купите в магазине")
		return
	_inv_slot = i
	_inv_refresh()

func _inv_save() -> void:
	State.save_game()
	say("Снасть сохранена")
	_close(_inv)

func _tile(kind: String, title: String, stat: String, status: String, cb: Callable) -> Control:
	var t = ShopCard.new()
	t.mode = "tile"
	t.kind = kind
	t.title = title
	t.stat = stat
	t.status = status
	t.custom_minimum_size = Vector2(200, 112)
	t.activated.connect(cb)
	return t

func _inv_busy() -> bool:
	if world.units[_inv_slot].state != 0:
		say("Сначала смотай эту удочку")
		return true
	return false

func _inv_refresh() -> void:
	var tabs: Array = []
	for i in 3:
		tabs.append([str(i), "Удочка %d%s" % [i + 1, "" if i < State.stands else " (закрыта)"]])
	_tabbar(tabs, str(_inv_slot), _inv_tab, _inv_tabs)
	var c: Dictionary = State.slots[_inv_slot]
	var t: String = str(c["type"])
	_inv_art.type = t
	_inv_art.queue_redraw()
	_clear(_inv_left)
	_clear(_inv_right)
	_clear(_inv_chips)
	_inv_left.add_child(_tile("line", "Леска", str(Data.LINES[State.line]["name"]), "equipped", _pick.bind("line")))
	_inv_left.add_child(_tile("reel", "Катушка", "в составе удилища", "info", say.bind("Катушка встроена в удилище: скорость зависит от модели")))
	if t == "spin":
		_inv_left.add_child(_tile("lure", "Приманка", str(Data.LURES[State.lure]["name"]), "equipped", _pick.bind("lure")))
	else:
		_inv_left.add_child(_tile("hook", "Крючок", str(Data.HOOKS[int(c["hook"])]["name"]), "equipped", _pick.bind("hook")))
		if t == "float":
			_inv_left.add_child(_tile("sinker", "Грузило", "%d г" % int(Data.SINKERS[int(c["sinker"])]), "equipped", _pick.bind("sinker")))
		else:
			_inv_left.add_child(_tile("feeder", "Кормушка", str(Data.FEEDERS[int(c["feeder"])]["name"]), "equipped", _pick.bind("feeder")))
	if t == "float":
		_inv_right.add_child(_tile("float", "Поплавок", str(Data.FLOATS[int(c["float"])]["name"]), "equipped", _pick.bind("float")))
		_inv_right.add_child(_tile("depth", "Глубина", "%.2f м" % float(c["fdepth"]), "equipped", _pick.bind("depth")))
	elif t == "feeder":
		var sg: int = int(c["sig"])
		_inv_right.add_child(_tile("bell" if sg <= 0 else "alarm", "Сигнал", "нет" if sg < 0 else str(Data.SIGNALS[sg]["name"]), "equipped", _pick.bind("sig")))
	if t != "spin":
		_inv_right.add_child(_tile(State.bait if Data.BAITS.has(State.bait) else "worm", "Наживка", "%s (%d)" % [str(Data.BAITS[State.bait]["name"]), int(State.baits.get(State.bait, 0))], "equipped", _pick.bind("bait")))
		_inv_right.add_child(_tile("mix", "Прикормка", "порций: %d" % State.gb_portions, "equipped", _open_mix))
	for cls in Data.CLASS_ORDER:
		var tier: int = int(State.rods.get(cls, -1))
		var rn: String = "нет — купить в магазине" if tier < 0 else str(Data.ROD_CLASSES[cls][tier]["name"])
		var chip = _tile("rod", str(Data.CLASS_NAMES[cls]), rn, "equipped" if cls == t else ("empty" if tier < 0 else "owned"), _set_type.bind(cls))
		chip.custom_minimum_size = Vector2(190, 84)
		_inv_chips.add_child(chip)
	var rod: Dictionary = Data.rod_of(c)
	var info := "Удочка %d: %s" % [_inv_slot + 1, "—" if rod.is_empty() else str(rod["name"])]
	if not rod.is_empty():
		info += " | Тест %.1f кг | Бросок %d м | Леска %.1f кг\nИзнос: леска %d%%, катушка %d%%, удилище %d%%, кольца %d%%" % [float(rod["kg"]), int(rod["range"]), float(Data.LINES[State.line]["kg"]), int(100.0 - State.line_cond), int(100.0 - State.reel_cond), int(100.0 - State.rod_cond), int(100.0 - State.guide_cond)]
		if t == "feeder" and int(Data.FEEDERS[int(c["feeder"])]["w"]) > int(rod["cast"]):
			info += "\nКормушка тяжелее, чем бросает это удилище!"
		elif t == "float":
			var cap: int = int(Data.FLOATS[int(c["float"])]["cap"])
			var sk: int = int(Data.SINKERS[int(c["sinker"])])
			if float(sk) < cap * 0.6:
				info += "\nГрузила мало: поплавок плавает высоко"
			elif sk > cap:
				info += "\nГрузило тяжёлое: поплавок тонет"
			else:
				info += "\nСнасть сбалансирована"
	_inv_info.text = info

func _set_type(cls: String) -> void:
	if _inv_busy():
		return
	if int(State.rods.get(cls, -1)) < 0:
		say("Такого удилища нет — купите в магазине")
		return
	State.slots[_inv_slot]["type"] = cls
	_inv_refresh()

# ---------- выбор детали ----------

func _build_picker() -> void:
	if _picker != null:
		return
	_picker = Control.new()
	_picker.theme = _theme
	_picker.visible = false
	hud.add_child(_picker)
	_picker.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	_picker.add_child(dim)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	var mg := MarginContainer.new()
	for side in ["left", "right"]:
		mg.add_theme_constant_override("margin_" + side, 60)
	mg.add_theme_constant_override("margin_top", 30)
	mg.add_theme_constant_override("margin_bottom", 30)
	_picker.add_child(mg)
	mg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _box(Color(0.07, 0.11, 0.16, 0.98), 28, Color(0.6, 0.64, 0.7), 3))
	mg.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	var head := HBoxContainer.new()
	vb.add_child(head)
	_picker_title = _lbl("", 38)
	_picker_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(_picker_title)
	var cb := _bbtn("Закрыть", _picker_close, 52)
	cb.custom_minimum_size = Vector2(170, 52)
	head.add_child(cb)
	_picker_body = ScrollContainer.new()
	_picker_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_picker_body.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(_picker_body)

func _picker_close() -> void:
	_picker.visible = false

func _picker_show(title: String) -> void:
	_picker_title.text = title
	_picker.visible = true
	_picker.move_to_front()
	if _msg != null:
		_msg.move_to_front()
	_fit(_picker)

func _pick(key: String) -> void:
	if _inv_busy():
		return
	var c: Dictionary = State.slots[_inv_slot]
	var items: Array = []
	var title := ""
	match key:
		"line":
			title = "Выбор лески"
			for i in State.line_best + 1:
				items.append({"kind": "line", "title": Data.LINES[i]["name"], "stat": "Выдерживает %.1f кг" % float(Data.LINES[i]["kg"]), "status": "equipped" if i == State.line else "owned", "cb": _apply.bind(key, i)})
		"hook":
			title = "Выбор крючка"
			for i in Data.HOOKS.size():
				if State.owned.has("hook%d" % i):
					items.append({"kind": "hook", "title": Data.HOOKS[i]["name"], "stat": "Размер рыбы: " + ["мелкая", "средняя", "крупная"][i], "status": "equipped" if int(c["hook"]) == i else "owned", "cb": _apply.bind(key, i)})
		"sinker":
			title = "Выбор грузила"
			for i in Data.SINKERS.size():
				items.append({"kind": "sinker", "title": "%d г" % int(Data.SINKERS[i]), "stat": "Подбери под поплавок", "status": "equipped" if int(c["sinker"]) == i else "owned", "cb": _apply.bind(key, i)})
		"float":
			title = "Выбор поплавка"
			for i in Data.FLOATS.size():
				if State.owned.has("float%d" % i):
					items.append({"kind": "float", "title": Data.FLOATS[i]["name"], "stat": "Грузоподъёмность %d г" % int(Data.FLOATS[i]["cap"]), "status": "equipped" if int(c["float"]) == i else "owned", "cb": _apply.bind(key, i)})
		"feeder":
			title = "Выбор кормушки"
			for i in Data.FEEDERS.size():
				if State.owned.has("feeder%d" % i):
					items.append({"kind": "feeder", "title": Data.FEEDERS[i]["name"], "stat": "Вес %d г" % int(Data.FEEDERS[i]["w"]), "status": "equipped" if int(c["feeder"]) == i else "owned", "cb": _apply.bind(key, i)})
		"sig":
			title = "Сигнал поклёвки"
			items.append({"kind": "hook", "title": "Без сигнала", "stat": "Смотри на кончик удилища", "status": "equipped" if int(c["sig"]) < 0 else "owned", "cb": _apply.bind(key, -1)})
			for i in Data.SIGNALS.size():
				if State.owned.has("sig%d" % i):
					items.append({"kind": "bell" if i == 0 else "alarm", "title": Data.SIGNALS[i]["name"], "stat": "Звук при поклёвке", "status": "equipped" if int(c["sig"]) == i else "owned", "cb": _apply.bind(key, i)})
		"bait":
			title = "Выбор наживки"
			for id in Data.BAITS:
				items.append({"kind": id, "title": Data.BAITS[id]["name"], "stat": "В запасе: %d" % int(State.baits.get(id, 0)), "status": "equipped" if State.bait == id else "owned", "cb": _apply.bind(key, id)})
		"lure":
			title = "Выбор приманки"
			for i in Data.LURES.size():
				if State.owned.has("lure%d" % i):
					items.append({"kind": "lure", "title": Data.LURES[i]["name"], "stat": "Глубина %.1f–%.1f м" % [float(Data.LURES[i]["depth"][0]), float(Data.LURES[i]["depth"][1])], "status": "equipped" if State.lure == i else "owned", "cb": _apply.bind(key, i)})
		"depth":
			title = "Глубина оснастки"
			for i in 12:
				var d: float = 0.5 + 0.5 * float(i)
				items.append({"kind": "depth", "title": "%.1f м" % d, "stat": "Ставь чуть меньше глубины воды", "status": "equipped" if absf(float(c["fdepth"]) - d) < 0.01 else "owned", "cb": _apply.bind(key, d)})
	_clear(_picker_body)
	var g := GridContainer.new()
	g.columns = 4
	g.add_theme_constant_override("h_separation", 14)
	g.add_theme_constant_override("v_separation", 14)
	_picker_body.add_child(g)
	for it in items:
		it["price"] = 0
		if it["status"] == "owned":
			it["btn"] = "ВЫБРАТЬ"
		g.add_child(_card(it))
	_picker_show(title)

func _apply(key: String, val) -> void:
	var c: Dictionary = State.slots[_inv_slot]
	match key:
		"line":
			State.line = int(val)
		"hook", "sinker", "float", "feeder", "sig":
			c[key] = int(val)
		"depth":
			c["fdepth"] = float(val)
		"bait":
			State.bait = str(val)
		"lure":
			State.lure = int(val)
	_picker.visible = false
	State.save_game()
	_inv_refresh()

# ---------- прикормка ----------

func _gb_price() -> int:
	var gs: Dictionary = State.gb_sel
	return int(Data.GB_BASES[gs["base"]]["price"]) + int(Data.GB_FLAVORS[gs["flavor"]]["price"]) + int(Data.GB_ADDS[gs["add"]]["price"])

func _open_mix() -> void:
	if _inv_busy():
		return
	_clear(_picker_body)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_picker_body.add_child(vb)
	var gs: Dictionary = State.gb_sel
	vb.add_child(_lbl("Порций в запасе: %d" % State.gb_portions, 30))
	vb.add_child(_bbtn("Основа: %s" % Data.GB_BASES[gs["base"]]["name"], _mix_cycle.bind("base")))
	vb.add_child(_bbtn("Запах: %s" % Data.GB_FLAVORS[gs["flavor"]]["name"], _mix_cycle.bind("flavor")))
	vb.add_child(_bbtn("Добавка: %s" % Data.GB_ADDS[gs["add"]]["name"], _mix_cycle.bind("add")))
	var likes := ""
	for id in Data.FISH:
		var e: float = Data.gb_effect(id, gs)
		if e >= 1.5:
			likes += "%s ×%.1f;  " % [Data.FISH[id]["name"], e]
	var l := _lbl("Привлекает: " + (likes if likes != "" else "всех слабо"), 24)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(900, 0)
	vb.add_child(l)
	vb.add_child(_bbtn("Замесить 10 порций — %d" % _gb_price(), _mix_make))
	_picker_show("Прикормка")

func _mix_cycle(which: String) -> void:
	var tbl: Dictionary = Data.GB_BASES
	if which == "flavor":
		tbl = Data.GB_FLAVORS
	elif which == "add":
		tbl = Data.GB_ADDS
	var keys: Array = tbl.keys()
	var i: int = keys.find(State.gb_sel[which])
	State.gb_sel[which] = keys[(i + 1) % keys.size()]
	_open_mix()

func _mix_make() -> void:
	var p := _gb_price()
	if State.silver < p:
		say("Не хватает серебра")
		return
	State.silver -= p
	State.gb_mix = State.gb_sel.duplicate()
	State.gb_portions = 10
	State.save_game()
	say("Прикормка готова: 10 порций")
	_open_mix()
	_inv_refresh()
