extends Control
# Карточка (магазин, продажа, рынок) или плитка (инвентарь). Нажатие без сдвига = выбор.
# status: buy | owned | equipped | locked | sell | info | done | empty

signal activated

var kind: String = ""
var title: String = ""
var stat: String = ""
var price: int = 0
var status: String = "buy"
var tint: Color = Color(0.9, 0.7, 0.3)
var lvl: int = 1
var mode: String = "card"       # card | tile
var btn_text: String = ""
var coin: String = "silver"
var price_text: String = ""
var _press_pos: Vector2 = Vector2.ZERO
var _down: bool = false

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP

func _ready() -> void:
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(268, 338) if mode == "card" else Vector2(190, 118)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var e := event as InputEventMouseButton
		if e.button_index != MOUSE_BUTTON_LEFT:
			return
		if e.pressed:
			_down = true
			_press_pos = e.position
			queue_redraw()
		else:
			var moved: float = e.position.distance_to(_press_pos)
			_down = false
			queue_redraw()
			if moved < 14.0 and status != "locked":
				activated.emit()

func _draw() -> void:
	if mode == "tile":
		_draw_tile()
	else:
		_draw_card()

func _box(col: Color, rad: int, border: Color, bw: int, shadow: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(rad)
	s.border_color = border
	s.set_border_width_all(bw)
	if shadow > 0:
		s.shadow_size = shadow
		s.shadow_color = Color(0, 0, 0, 0.45)
	return s

func _draw_card() -> void:
	var f := ThemeDB.fallback_font
	var w := size.x
	var h := size.y
	var base := Color(0.5, 0.53, 0.57)
	if _down:
		base = Color(0.42, 0.45, 0.5)
	draw_style_box(_box(base, 22, Color(0.8, 0.82, 0.86), 3, 8), Rect2(Vector2.ZERO, size))
	draw_style_box(_box(Color(1, 1, 1, 0.08), 18, Color(0, 0, 0, 0), 0), Rect2(Vector2(5, 5), Vector2(w - 10, h * 0.45)))
	var art := Rect2(Vector2(12, 12), Vector2(w - 24, 158))
	draw_style_box(_box(Color(0.06, 0.09, 0.12), 14, Color(0.28, 0.31, 0.36), 2), art)
	draw_set_transform(art.get_center(), 0.0, Vector2(1.3, 1.3))
	_icon(Vector2.ZERO)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 1))
	if lvl > 1:
		draw_string(f, Vector2(art.end.x - 150, art.end.y - 10), "УРОВЕНЬ: %d+" % lvl, HORIZONTAL_ALIGNMENT_RIGHT, 140, 17, Color(0.95, 0.75, 0.25))
	draw_string(f, Vector2(12, 202), title.to_upper(), HORIZONTAL_ALIGNMENT_CENTER, w - 24, 21, Color(0.06, 0.08, 0.11))
	draw_multiline_string(f, Vector2(12, 226), stat, HORIZONTAL_ALIGNMENT_CENTER, w - 24, 16, 2, Color(0.15, 0.19, 0.24))
	var py := h - 84.0
	if status == "buy" or status == "sell":
		var cc := Vector2(w * 0.5 - 62, py)
		_coin(cc, coin)
		var label: String = price_text if price_text != "" else "%d Серебра" % price
		draw_string(f, Vector2(cc.x + 18, py + 7), label, HORIZONTAL_ALIGNMENT_LEFT, 150, 19, Color(0.08, 0.1, 0.14))
	var bt := btn_text
	var bg := Color(0.14, 0.34, 0.58)
	var bd := Color(0.9, 0.75, 0.4)
	match status:
		"buy":
			bt = bt if bt != "" else "КУПИТЬ"
		"sell":
			bt = bt if bt != "" else "ПРОДАТЬ"
			bg = Color(0.18, 0.45, 0.3)
		"owned":
			bt = btn_text if btn_text != "" else "ЕСТЬ"
			bg = Color(0.25, 0.3, 0.37)
			bd = Color(0.6, 0.65, 0.7)
		"equipped":
			bt = "НАДЕТО"
			bg = Color(0.2, 0.5, 0.42)
		"done":
			bt = "ВЫПОЛНЕНО"
			bg = Color(0.25, 0.3, 0.37)
			bd = Color(0.6, 0.65, 0.7)
		"info":
			bt = btn_text if btn_text != "" else "В САДКЕ"
			bg = Color(0.25, 0.3, 0.37)
			bd = Color(0.6, 0.65, 0.7)
		_:
			bt = "УРОВЕНЬ %d" % lvl if lvl > 1 else "ЗАКРЫТО"
			bg = Color(0.17, 0.18, 0.2)
			bd = Color(0.4, 0.4, 0.43)
	if _down and status != "locked":
		bg = bg.lightened(0.15)
	draw_style_box(_box(bg, 24, bd, 3), Rect2(Vector2(14, h - 62), Vector2(w - 28, 48)))
	draw_string(f, Vector2(14, h - 28), bt, HORIZONTAL_ALIGNMENT_CENTER, w - 28, 23, Color(1, 1, 1))

func _draw_tile() -> void:
	var f := ThemeDB.fallback_font
	var w := size.x
	var h := size.y
	var edge := Color(0.62, 0.65, 0.7)
	if status == "equipped":
		edge = Color(0.4, 0.85, 0.8)
	draw_style_box(_box(Color(0.1, 0.14, 0.18) if not _down else Color(0.15, 0.22, 0.27), 14, edge, 3, 6), Rect2(Vector2.ZERO, size))
	draw_set_transform(Vector2(w * 0.5, h * 0.36), 0.0, Vector2(h / 118.0 * 0.78, h / 118.0 * 0.78))
	_icon(Vector2.ZERO)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 1))
	var sh := h * 0.3
	draw_style_box(_box(Color(0.12, 0.12, 0.14), 10, Color(0, 0, 0, 0), 0), Rect2(Vector2(4, h - sh - 4), Vector2(w - 8, sh)))
	for i in int(w / 9.0):
		draw_line(Vector2(6 + i * 9, h - 6), Vector2(14 + i * 9, h - sh - 2), Color(1, 1, 1, 0.05), 2.0)
	draw_string(f, Vector2(4, h - sh * 0.3 - 4), title.to_upper(), HORIZONTAL_ALIGNMENT_CENTER, w - 8, int(clampf(h * 0.17, 13.0, 20.0)), Color(0.95, 0.97, 1.0))
	if stat != "":
		draw_string(f, Vector2(8, 20), stat, HORIZONTAL_ALIGNMENT_LEFT, w - 16, 13, Color(0.7, 0.78, 0.84))
	if status == "empty" or status == "buy":
		draw_string(f, Vector2(w - 30, h * 0.5), "+", HORIZONTAL_ALIGNMENT_LEFT, 24, 26, Color(0.7, 0.75, 0.8))

func _coin(c: Vector2, k: String) -> void:
	if k == "gold":
		draw_colored_polygon(PackedVector2Array([c + Vector2(-9, 5), c + Vector2(-5, -5), c + Vector2(8, -5), c + Vector2(11, 5)]), Color(0.95, 0.75, 0.2))
	else:
		draw_circle(c, 10, Color(0.8, 0.82, 0.86))
		draw_arc(c, 7, 0.0, TAU, 16, Color(0.5, 0.52, 0.58), 2.0)

func _icon(c: Vector2) -> void:
	var w := Color(0.92, 0.95, 0.98)
	var a := Color(0.3, 0.8, 0.75)
	match kind:
		"rod":
			draw_line(c + Vector2(-70, 36), c + Vector2(72, -40), w, 4.0, true)
			draw_line(c + Vector2(-70, 36), c + Vector2(-48, 22), Color(0.7, 0.5, 0.25), 8.0, true)
			draw_circle(c + Vector2(-34, 22), 12, a)
			draw_arc(c + Vector2(-34, 22), 12, 0, TAU, 20, w, 2.0)
		"reel":
			draw_circle(c, 32, Color(0.25, 0.3, 0.35))
			draw_circle(c, 22, Color(0.75, 0.6, 0.25))
			draw_circle(c, 8, Color(0.1, 0.12, 0.15))
			draw_line(c + Vector2(30, 0), c + Vector2(54, 22), w, 5.0)
		"line":
			draw_circle(c, 32, Color(0.25, 0.3, 0.35))
			draw_circle(c, 22, a)
			draw_circle(c, 9, Color(0.05, 0.08, 0.11))
			draw_arc(c, 36, 0, TAU, 30, w, 2.0)
		"hook":
			draw_line(c + Vector2(0, -38), c + Vector2(0, 12), w, 5.0, true)
			draw_arc(c + Vector2(-16, 12), 16, 0.0, PI * 0.95, 20, w, 5.0, true)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-34, 10), c + Vector2(-24, 10), c + Vector2(-30, 0)]), w)
			draw_circle(c + Vector2(0, -42), 6, w)
		"float":
			draw_line(c + Vector2(0, -50), c + Vector2(0, -30), w, 2.0)
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -34), c + Vector2(13, -8), c + Vector2(-13, -8)]), Color(0.95, 0.2, 0.15))
			draw_circle(c + Vector2(0, 4), 18, Color(0.95, 0.95, 0.9))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-8, 18), c + Vector2(8, 18), c + Vector2(0, 40)]), Color(0.95, 0.95, 0.9))
		"sinker":
			draw_circle(c + Vector2(0, 10), 24, Color(0.6, 0.63, 0.68))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-12, -8), c + Vector2(12, -8), c + Vector2(0, -34)]), Color(0.6, 0.63, 0.68))
			draw_arc(c + Vector2(0, -38), 7, 0, TAU, 12, w, 2.5)
		"feeder":
			draw_rect(Rect2(c + Vector2(-30, -22), Vector2(60, 44)), Color(0.25, 0.3, 0.35), false, 3.0)
			for i in 5:
				draw_line(c + Vector2(-30 + i * 15, -22), c + Vector2(-30 + i * 15, 22), w, 2.0)
			draw_line(c + Vector2(-30, 0), c + Vector2(30, 0), w, 2.0)
			draw_line(c + Vector2(0, -22), c + Vector2(0, -42), w, 3.0)
		"bell":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-26, 22), c + Vector2(-18, -14), c + Vector2(0, -28), c + Vector2(18, -14), c + Vector2(26, 22)]), Color(0.9, 0.75, 0.2))
			draw_circle(c + Vector2(0, 26), 6, Color(0.7, 0.55, 0.15))
		"alarm":
			draw_rect(Rect2(c + Vector2(-34, -20), Vector2(68, 40)), Color(0.2, 0.25, 0.3))
			draw_circle(c + Vector2(-16, 0), 7, Color(0.95, 0.25, 0.2))
			draw_circle(c + Vector2(10, 0), 10, Color(0.4, 0.45, 0.5))
			draw_line(c + Vector2(-34, -20), c + Vector2(-34, -40), w, 3.0)
		"stand":
			draw_line(c + Vector2(-30, 40), c + Vector2(0, -20), Color(0.6, 0.45, 0.25), 5.0)
			draw_line(c + Vector2(30, 40), c + Vector2(0, -20), Color(0.6, 0.45, 0.25), 5.0)
			draw_line(c + Vector2(-44, -34), c + Vector2(48, -4), w, 3.0)
		"lure":
			draw_colored_polygon(_ell_at(c, 40, 16, 20), Color(0.8, 0.85, 0.9))
			draw_colored_polygon(PackedVector2Array([c + Vector2(36, 0), c + Vector2(58, -14), c + Vector2(58, 14)]), a)
			draw_circle(c + Vector2(-22, -4), 4, Color(0.05, 0.05, 0.08))
			draw_arc(c + Vector2(-6, 18), 9, 0.0, PI, 10, w, 2.5)
		"worm":
			var pts := PackedVector2Array()
			for i in 24:
				pts.append(c + Vector2(-60 + i * 5.2, sin(i * 0.9) * 12))
			draw_polyline(pts, Color(0.85, 0.45, 0.5), 8.0, true)
		"maggot":
			for i in 5:
				draw_colored_polygon(_ell_at(c + Vector2(-48 + i * 24, (i % 2) * 14 - 7), 10, 5, 12), Color(0.95, 0.93, 0.8))
		"corn":
			for i in 7:
				draw_circle(c + Vector2(-36 + (i % 4) * 24, -14 + (i / 4) * 28), 11, Color(0.97, 0.8, 0.2))
		"bread":
			draw_style_box(_box(Color(0.85, 0.65, 0.35), 18, Color(0, 0, 0, 0), 0), Rect2(c + Vector2(-44, -26), Vector2(88, 52)))
		"mix":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-40, -10), c + Vector2(40, -10), c + Vector2(28, 30), c + Vector2(-28, 30)]), Color(0.55, 0.45, 0.3))
			draw_circle(c + Vector2(-12, -14), 10, Color(0.75, 0.6, 0.35))
			draw_circle(c + Vector2(12, -16), 12, Color(0.7, 0.55, 0.3))
		"depth":
			draw_line(c + Vector2(0, -36), c + Vector2(0, 36), w, 3.0)
			for i in 5:
				draw_line(c + Vector2(-10, -30 + i * 15), c + Vector2(10, -30 + i * 15), w, 2.0)
			draw_colored_polygon(PackedVector2Array([c + Vector2(14, 20), c + Vector2(30, 12), c + Vector2(30, 28)]), a)
		"fish":
			draw_colored_polygon(_ell_at(c, 52, 22, 24), tint)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-48, 0), c + Vector2(-78, -20), c + Vector2(-78, 20)]), tint.darkened(0.25))
			draw_circle(c + Vector2(30, -5), 4, Color(0, 0, 0))
		"sell":
			for i in 3:
				draw_circle(c + Vector2(-20 + i * 20, 20 - i * 14), 20, Color(0.85, 0.85, 0.9))
				draw_arc(c + Vector2(-20 + i * 20, 20 - i * 14), 15, 0, TAU, 20, Color(0.5, 0.5, 0.58), 3.0)
		"gold":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-50, 24), c + Vector2(-34, -16), c + Vector2(42, -16), c + Vector2(56, 24)]), Color(0.95, 0.75, 0.2))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-34, -16), c + Vector2(42, -16), c + Vector2(30, -34), c + Vector2(-22, -34)]), Color(1.0, 0.9, 0.5))
		"quest":
			draw_rect(Rect2(c + Vector2(-34, -40), Vector2(68, 80)), Color(0.85, 0.8, 0.65))
			for i in 4:
				draw_line(c + Vector2(-24, -24 + i * 18), c + Vector2(24, -24 + i * 18), Color(0.3, 0.25, 0.15), 3.0)
		_:
			draw_circle(c, 24, a)

func _ell_at(c: Vector2, rx: float, ry: float, n: int) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n:
		var t := TAU * float(i) / float(n)
		p.append(c + Vector2(cos(t) * rx, sin(t) * ry))
	return p
