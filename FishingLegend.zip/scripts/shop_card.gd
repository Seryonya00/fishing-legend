extends Control
# Карточка товара: рисунок, название, характеристики, цена или статус. Нажатие без сдвига = выбор.

signal activated

var kind: String = ""
var title: String = ""
var stat: String = ""
var price: int = 0
var status: String = "buy"   # buy | owned | equipped | locked
var tint: Color = Color(0.9, 0.7, 0.3)
var _press_pos: Vector2 = Vector2.ZERO
var _down: bool = false

func _init() -> void:
	custom_minimum_size = Vector2(262, 236)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var e := event as InputEventMouseButton
		if e.button_index != MOUSE_BUTTON_LEFT:
			return
		if e.pressed:
			_down = true
			_press_pos = e.position
			queue_redraw()
		else:
			var moved: float = e.position.distance_to(_press_pos)
			_down = false
			queue_redraw()
			if moved < 14.0 and status != "locked":
				activated.emit()

func _draw() -> void:
	var f := ThemeDB.fallback_font
	var accent := Color(0.3, 0.8, 0.75)
	var bg := Color(0.09, 0.13, 0.17)
	var edge := Color(1, 1, 1, 0.08)
	if status == "equipped":
		edge = accent
	elif status == "owned":
		edge = Color(0.3, 0.8, 0.75, 0.35)
	if _down:
		bg = Color(0.13, 0.2, 0.25)
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(20)
	sb.border_color = edge
	sb.set_border_width_all(3 if status == "equipped" else 2)
	draw_style_box(sb, Rect2(Vector2.ZERO, size))
	# рамка под рисунок
	var art := StyleBoxFlat.new()
	art.bg_color = Color(0.05, 0.08, 0.11)
	art.set_corner_radius_all(14)
	draw_style_box(art, Rect2(Vector2(10, 10), Vector2(size.x - 20, 102)))
	_icon(Vector2(size.x * 0.5, 61))
	draw_string(f, Vector2(14, 140), title, HORIZONTAL_ALIGNMENT_LEFT, size.x - 28, 19, Color(0.95, 0.97, 1.0))
	draw_string(f, Vector2(14, 164), stat, HORIZONTAL_ALIGNMENT_LEFT, size.x - 28, 17, Color(0.6, 0.7, 0.75))
	# нижняя плашка: цена или статус
	var pill := StyleBoxFlat.new()
	pill.set_corner_radius_all(16)
	var label := ""
	match status:
		"buy":
			pill.bg_color = Color(0.16, 0.42, 0.4)
			label = str(price)
		"owned":
			pill.bg_color = Color(0.15, 0.2, 0.25)
			label = "Куплено"
		"equipped":
			pill.bg_color = Color(0.2, 0.55, 0.5)
			label = "Надето"
		"sell":
			pill.bg_color = Color(0.25, 0.5, 0.25)
			label = "+%d" % price
		"info":
			pill.bg_color = Color(0.13, 0.17, 0.21)
			label = "В садке"
		_:
			pill.bg_color = Color(0.12, 0.13, 0.15)
			label = "Закрыто"
	draw_style_box(pill, Rect2(Vector2(10, size.y - 52), Vector2(size.x - 20, 42)))
	if status == "buy" or status == "sell":
		draw_circle(Vector2(size.x * 0.5 - 34, size.y - 31), 11, Color(0.85, 0.85, 0.9))
		draw_arc(Vector2(size.x * 0.5 - 34, size.y - 31), 8, 0, TAU, 20, Color(0.55, 0.55, 0.62), 2.0)
		draw_string(f, Vector2(size.x * 0.5 - 16, size.y - 23), label, HORIZONTAL_ALIGNMENT_LEFT, 120, 24, Color(1, 1, 1))
	else:
		draw_string(f, Vector2(10, size.y - 23), label, HORIZONTAL_ALIGNMENT_CENTER, size.x - 20, 22, Color(0.9, 0.95, 0.97))

func _icon(c: Vector2) -> void:
	var w := Color(0.92, 0.95, 0.98)
	var a := Color(0.3, 0.8, 0.75)
	match kind:
		"rod":
			draw_line(c + Vector2(-70, 36), c + Vector2(72, -40), w, 4.0, true)
			draw_line(c + Vector2(-70, 36), c + Vector2(-48, 22), Color(0.6, 0.4, 0.2), 8.0, true)
			draw_circle(c + Vector2(-34, 22), 12, a)
			draw_arc(c + Vector2(-34, 22), 12, 0, TAU, 20, w, 2.0)
		"line":
			draw_circle(c, 32, Color(0.25, 0.3, 0.35))
			draw_circle(c, 22, a)
			draw_circle(c, 9, Color(0.05, 0.08, 0.11))
			draw_arc(c, 36, 0, TAU, 30, w, 2.0)
		"hook":
			draw_line(c + Vector2(0, -38), c + Vector2(0, 12), w, 5.0, true)
			draw_arc(c + Vector2(-16, 12), 16, 0.0, PI * 0.95, 20, w, 5.0, true)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-34, 10), c + Vector2(-24, 10), c + Vector2(-30, 0)]), w)
			draw_circle(c + Vector2(0, -42), 6, w)
		"float":
			draw_line(c + Vector2(0, -50), c + Vector2(0, -30), w, 2.0)
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -34), c + Vector2(13, -8), c + Vector2(-13, -8)]), Color(0.95, 0.2, 0.15))
			draw_circle(c + Vector2(0, 4), 18, Color(0.95, 0.95, 0.9))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-8, 18), c + Vector2(8, 18), c + Vector2(0, 40)]), Color(0.95, 0.95, 0.9))
		"feeder":
			draw_rect(Rect2(c + Vector2(-30, -22), Vector2(60, 44)), Color(0.25, 0.3, 0.35), false, 3.0)
			for i in 5:
				draw_line(c + Vector2(-30 + i * 15, -22), c + Vector2(-30 + i * 15, 22), w, 2.0)
			draw_line(c + Vector2(-30, 0), c + Vector2(30, 0), w, 2.0)
			draw_line(c + Vector2(0, -22), c + Vector2(0, -42), w, 3.0)
		"bell":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-26, 22), c + Vector2(-18, -14), c + Vector2(0, -28), c + Vector2(18, -14), c + Vector2(26, 22)]), Color(0.9, 0.75, 0.2))
			draw_circle(c + Vector2(0, 26), 6, Color(0.7, 0.55, 0.15))
		"alarm":
			draw_rect(Rect2(c + Vector2(-34, -20), Vector2(68, 40)), Color(0.2, 0.25, 0.3))
			draw_circle(c + Vector2(-16, 0), 7, Color(0.95, 0.25, 0.2))
			draw_circle(c + Vector2(10, 0), 10, Color(0.4, 0.45, 0.5))
			draw_line(c + Vector2(-34, -20), c + Vector2(-34, -40), w, 3.0)
		"stand":
			draw_line(c + Vector2(-30, 40), c + Vector2(0, -20), Color(0.6, 0.45, 0.25), 5.0)
			draw_line(c + Vector2(30, 40), c + Vector2(0, -20), Color(0.6, 0.45, 0.25), 5.0)
			draw_line(c + Vector2(-44, -34), c + Vector2(48, -4), w, 3.0)
		"lure":
			draw_set_transform(c, -0.3, Vector2(1, 1))
			draw_colored_polygon(_ell(40, 16, 20), Color(0.8, 0.85, 0.9))
			draw_colored_polygon(PackedVector2Array([Vector2(36, 0), Vector2(56, -14), Vector2(56, 14)]), a)
			draw_circle(Vector2(-22, -4), 4, Color(0.05, 0.05, 0.08))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 1))
		"worm":
			var pts := PackedVector2Array()
			for i in 24:
				pts.append(c + Vector2(-60 + i * 5.2, sin(i * 0.9) * 12))
			draw_polyline(pts, Color(0.85, 0.45, 0.5), 8.0, true)
		"maggot":
			for i in 5:
				draw_colored_polygon(_ell_at(c + Vector2(-48 + i * 24, (i % 2) * 14 - 7), 10, 5, 12), Color(0.95, 0.93, 0.8))
		"corn":
			for i in 7:
				draw_circle(c + Vector2(-36 + (i % 4) * 24, -14 + (i / 4) * 28), 11, Color(0.97, 0.8, 0.2))
		"bread":
			draw_style_box(_rounded(Color(0.85, 0.65, 0.35), 18), Rect2(c + Vector2(-44, -26), Vector2(88, 52)))
		"fish":
			draw_colored_polygon(_ell_at(c, 52, 22, 24), tint)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-48, 0), c + Vector2(-78, -20), c + Vector2(-78, 20)]), tint.darkened(0.25))
			draw_circle(c + Vector2(30, -5), 4, Color(0, 0, 0))
		"sell":
			for i in 3:
				draw_circle(c + Vector2(-20 + i * 20, 20 - i * 14), 20, Color(0.85, 0.85, 0.9))
				draw_arc(c + Vector2(-20 + i * 20, 20 - i * 14), 15, 0, TAU, 20, Color(0.5, 0.5, 0.58), 3.0)
		_:
			draw_circle(c, 24, a)

func _ell(rx: float, ry: float, n: int) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n:
		var t := TAU * float(i) / float(n)
		p.append(Vector2(cos(t) * rx, sin(t) * ry))
	return p

func _ell_at(c: Vector2, rx: float, ry: float, n: int) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n:
		var t := TAU * float(i) / float(n)
		p.append(c + Vector2(cos(t) * rx, sin(t) * ry))
	return p

func _rounded(col: Color, r: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(r)
	return s
