extends Node
# Глобальное состояние игрока. Три слота сохранений: user://save_1..3.json

var _data_script = null
const SLOTS := 3
const RIG0 := {"type": "float", "hook": 0, "float": 0, "sinker": 0, "feeder": 0, "fdepth": 1.5, "sig": 0}
const OWNED0 := {"hook0": true, "float0": true, "feeder0": true, "lure0": true, "sig0": true}

var slot: int = 1
var active: bool = false
var silver: int = 250
var gold: int = 0
var xp: int = 0
var rods: Dictionary = {"float": 0, "feeder": -1, "spin": -1}
var lure: int = 0
var loc: String = "pond"
var line: int = 0
var line_best: int = 0
var line_cond: float = 100.0
var baits: Dictionary = {"worm": 10}
var bait: String = "worm"
var keepnet: Array = []
var record: Dictionary = {}
var counts: Dictionary = {}
var owned: Dictionary = OWNED0.duplicate()
var slots: Array = []
var cur: int = 0
var stands: int = 1
var rig: Dictionary = {}
var gb_sel: Dictionary = {"base": "univ", "flavor": "none", "add": "none"}
var gb_mix: Dictionary = {}
var gb_portions: int = 0
var total_hours: float = 0.0
var market: Dictionary = {"cycle": -1, "n": [0, 0, 0, 0]}
var quests: Array = []
var ach: Dictionary = {}

func _init() -> void:
	_default_slots()

func _default_slots() -> void:
	slots = [RIG0.duplicate(), RIG0.duplicate(), RIG0.duplicate()]
	cur = 0
	rig = slots[0]

func set_cur(i: int) -> void:
	cur = clampi(i, 0, 2)
	rig = slots[cur]

func _ready() -> void:
	# перенос старого одиночного сохранения в слот 1
	if FileAccess.file_exists("user://save.json") and not FileAccess.file_exists(slot_path(1)):
		var b := FileAccess.get_file_as_bytes("user://save.json")
		var f := FileAccess.open(slot_path(1), FileAccess.WRITE)
		if f != null:
			f.store_buffer(b)

func level() -> int:
	return 1 + int(sqrt(float(xp) / 50.0))

func slot_path(i: int) -> String:
	return "user://save_%d.json" % i

func _meta_save() -> void:
	var f := FileAccess.open("user://meta.json", FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify({"last": slot}))

func last_slot() -> int:
	if FileAccess.file_exists("user://meta.json"):
		var d = JSON.parse_string(FileAccess.get_file_as_bytes("user://meta.json").get_string_from_utf8())
		if typeof(d) == TYPE_DICTIONARY:
			return clampi(int(d.get("last", 1)), 1, SLOTS)
	return 1

func has_save(i: int) -> bool:
	return FileAccess.file_exists(slot_path(i))

func has_any() -> bool:
	for i in range(1, SLOTS + 1):
		if has_save(i):
			return true
	return false

func slot_info(i: int) -> Dictionary:
	if not has_save(i):
		return {}
	var d = JSON.parse_string(FileAccess.get_file_as_bytes(slot_path(i)).get_string_from_utf8())
	if typeof(d) != TYPE_DICTIONARY:
		return {}
	var xpv: int = int(d.get("xp", 0))
	var fish_n := 0
	var cn = d.get("counts")
	if typeof(cn) == TYPE_DICTIONARY:
		for k in cn:
			fish_n += int(cn[k])
	return {"level": 1 + int(sqrt(float(xpv) / 50.0)), "silver": int(d.get("silver", 0)), "loc": str(d.get("loc", "pond")), "fish": fish_n}

func delete_slot(i: int) -> void:
	if has_save(i):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(slot_path(i)))

func new_game(i: int) -> void:
	reset()
	slot = i
	active = true
	_fill_quests()
	save_game()

func load_slot(i: int) -> bool:
	reset()
	slot = i
	var ok := _load(slot_path(i))
	if ok:
		active = true
		_fill_quests()
		_meta_save()
	return ok

func reset() -> void:
	silver = 250
	gold = 0
	xp = 0
	rods = {"float": 0, "feeder": -1, "spin": -1}
	lure = 0
	loc = "pond"
	line = 0
	line_best = 0
	line_cond = 100.0
	baits = {"worm": 10}
	bait = "worm"
	keepnet = []
	record = {}
	counts = {}
	owned = OWNED0.duplicate()
	stands = 1
	_default_slots()
	gb_sel = {"base": "univ", "flavor": "none", "add": "none"}
	gb_mix = {}
	gb_portions = 0
	total_hours = 0.0
	market = {"cycle": -1, "n": [0, 0, 0, 0]}
	quests = []
	ach = {}

func save_game() -> void:
	if not active:
		return
	var d := {"silver": silver, "gold": gold, "xp": xp, "rods": rods, "lure": lure, "loc": loc, "line": line, "line_best": line_best, "line_cond": line_cond, "baits": baits, "bait": bait, "keepnet": keepnet, "record": record, "counts": counts, "owned": owned, "slots": slots, "cur": cur, "stands": stands, "gb_sel": gb_sel, "gb_mix": gb_mix, "gb_portions": gb_portions, "total_hours": total_hours, "market": market, "quests": quests, "ach": ach}
	var f := FileAccess.open(slot_path(slot), FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))
	_meta_save()

func _merge(base: Dictionary, extra) -> Dictionary:
	var out := base.duplicate()
	if typeof(extra) == TYPE_DICTIONARY:
		for k in extra:
			out[k] = extra[k]
	return out

func _load(path: String) -> bool:
	if not FileAccess.file_exists(path):
		return false
	var d = JSON.parse_string(FileAccess.get_file_as_bytes(path).get_string_from_utf8())
	if typeof(d) != TYPE_DICTIONARY:
		return false
	silver = int(d.get("silver", silver))
	gold = int(d.get("gold", gold))
	xp = int(d.get("xp", xp))
	rods = _merge(rods, d.get("rods"))
	if d.has("rod") and not d.has("rods"):
		rods["float"] = clampi(int(d["rod"]), 0, 2)
	lure = int(d.get("lure", 0))
	loc = str(d.get("loc", "pond"))
	line = int(d.get("line", 0))
	line_best = maxi(int(d.get("line_best", line)), line)
	line_cond = float(d.get("line_cond", 100.0))
	baits = _merge(baits, d.get("baits"))
	bait = str(d.get("bait", bait))
	keepnet = d.get("keepnet", keepnet)
	record = _merge(record, d.get("record"))
	counts = _merge(counts, d.get("counts"))
	owned = _merge(owned, d.get("owned"))
	gb_sel = _merge(gb_sel, d.get("gb_sel"))
	gb_mix = _merge({}, d.get("gb_mix"))
	gb_portions = int(d.get("gb_portions", 0))
	stands = clampi(int(d.get("stands", 1)), 1, 3)
	var sl = d.get("slots")
	if typeof(sl) == TYPE_ARRAY and sl.size() == 3:
		for i in 3:
			slots[i] = _merge(RIG0, sl[i])
	elif d.has("rig"):
		slots[0] = _merge(RIG0, d.get("rig"))
	set_cur(int(d.get("cur", 0)))
	for sd in slots:
		if int(rods.get(str(sd["type"]), -1)) < 0:
			sd["type"] = "float"
	total_hours = float(d.get("total_hours", 0.0))
	market = _merge(market, d.get("market"))
	var qs = d.get("quests")
	if typeof(qs) == TYPE_ARRAY:
		quests = qs
	ach = _merge({}, d.get("ach"))
	return true

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()

# ---------- задания и достижения ----------

func _dt():
	if _data_script == null:
		_data_script = load("res://scripts/data.gd")
	return _data_script

func _gen_quest() -> Dictionary:
	var r: int = randi() % 3
	if r == 0:
		var n: int = randi_range(3, 8)
		return {"kind": "any", "need": n, "got": 0, "silver": n * 40, "xp": n * 8, "done": false}
	if r == 1:
		var ids: Array = ["roach", "perch", "crucian", "bream"]
		var id: String = ids[randi() % ids.size()]
		var n2: int = randi_range(2, 5)
		return {"kind": "fish", "fish": id, "need": n2, "got": 0, "silver": n2 * 70, "xp": n2 * 12, "done": false}
	var w: float = snappedf(randf_range(1.0, 2.5) + float(level()) * 0.2, 0.5)
	return {"kind": "weight", "w": w, "need": 1, "got": 0, "silver": int(w * 160), "xp": int(w * 30), "done": false}

func _fill_quests() -> void:
	while quests.size() < 3:
		quests.append(_gen_quest())

func quest_text(q: Dictionary) -> String:
	match str(q["kind"]):
		"any":
			return "Поймай %d рыб" % int(q["need"])
		"fish":
			return "Поймай %s: %d шт." % [str(_dt().FISH[q["fish"]]["name"]).to_lower(), int(q["need"])]
	return "Поймай рыбу тяжелее %.1f кг" % float(q["w"])

func claim_quest(i: int) -> bool:
	if i < 0 or i >= quests.size() or not bool(quests[i]["done"]):
		return false
	silver += int(quests[i]["silver"])
	xp += int(quests[i]["xp"])
	quests[i] = _gen_quest()
	save_game()
	return true

# вызывается при каждой пойманной рыбе; возвращает сообщения для показа
func on_catch(fish: Dictionary) -> Array:
	var msgs: Array = []
	var w: float = float(fish["w"])
	for q in quests:
		if bool(q["done"]):
			continue
		var hit := false
		match str(q["kind"]):
			"any":
				hit = true
			"fish":
				hit = str(q["fish"]) == str(fish["id"])
			"weight":
				hit = w >= float(q["w"])
		if hit:
			q["got"] = int(q["got"]) + 1
			if int(q["got"]) >= int(q["need"]):
				q["done"] = true
				msgs.append("Задание выполнено! Забери награду в меню «Задания»")
	var total := 0
	for k in counts:
		total += int(counts[k])
	for a in _dt().ACH:
		var id: String = a["id"]
		if ach.has(id):
			continue
		var ok := false
		match str(a["kind"]):
			"count":
				ok = total >= int(a["need"])
			"weight":
				ok = w >= float(a["need"])
			"species":
				ok = counts.size() >= int(a["need"])
		if ok:
			ach[id] = true
			silver += int(a["silver"])
			msgs.append("Достижение: %s (+%d серебра)" % [str(a["name"]), int(a["silver"])])
	return msgs
