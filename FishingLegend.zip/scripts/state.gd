extends Node
# Глобальное состояние игрока и сохранение (user://save.json)

const SAVE_PATH := "user://save.json"

var silver: int = 150
var gold: int = 0
var xp: int = 0
var rod: int = 0
var line: int = 0
var baits: Dictionary = {"worm": 10}
var bait: String = "worm"
var keepnet: Array = []
var record: Dictionary = {}
var counts: Dictionary = {}
var owned: Dictionary = {"hook0": true, "float0": true, "feeder0": true}
var rig: Dictionary = {"type": "float", "hook": 0, "float": 0, "sinker": 0, "feeder": 0, "fdepth": 1.5}
var gb_sel: Dictionary = {"base": "univ", "flavor": "none", "add": "none"}
var gb_mix: Dictionary = {}
var gb_portions: int = 0

func _ready() -> void:
	load_game()

func level() -> int:
	return 1 + int(sqrt(float(xp) / 50.0))

func reset() -> void:
	silver = 150
	gold = 0
	xp = 0
	rod = 0
	line = 0
	baits = {"worm": 10}
	bait = "worm"
	keepnet = []
	record = {}
	counts = {}
	owned = {"hook0": true, "float0": true, "feeder0": true}
	rig = {"type": "float", "hook": 0, "float": 0, "sinker": 0, "feeder": 0, "fdepth": 1.5}
	gb_sel = {"base": "univ", "flavor": "none", "add": "none"}
	gb_mix = {}
	gb_portions = 0

func save_game() -> void:
	var d := {"silver": silver, "gold": gold, "xp": xp, "rod": rod, "line": line, "baits": baits, "bait": bait, "keepnet": keepnet, "record": record, "counts": counts, "owned": owned, "rig": rig, "gb_sel": gb_sel, "gb_mix": gb_mix, "gb_portions": gb_portions}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))

func _merge(base: Dictionary, extra) -> Dictionary:
	var out := base.duplicate()
	if typeof(extra) == TYPE_DICTIONARY:
		for k in extra:
			out[k] = extra[k]
	return out

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return
	silver = int(d.get("silver", silver))
	gold = int(d.get("gold", gold))
	xp = int(d.get("xp", xp))
	rod = clampi(int(d.get("rod", rod)), 0, 2)
	line = clampi(int(d.get("line", line)), 0, 2)
	baits = _merge(baits, d.get("baits"))
	bait = str(d.get("bait", bait))
	keepnet = d.get("keepnet", keepnet)
	record = _merge(record, d.get("record"))
	counts = _merge(counts, d.get("counts"))
	owned = _merge(owned, d.get("owned"))
	rig = _merge(rig, d.get("rig"))
	gb_sel = _merge(gb_sel, d.get("gb_sel"))
	gb_mix = _merge({}, d.get("gb_mix"))
	gb_portions = int(d.get("gb_portions", 0))

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()
