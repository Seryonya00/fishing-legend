extends Node
# Глобальное состояние игрока и сохранение (user://save.json)

const SAVE_PATH := "user://save.json"

var silver: int = 150
var gold: int = 0
var xp: int = 0
var rods: Dictionary = {"float": 0, "feeder": -1, "spin": -1}
var lure: int = 0
var loc: String = "pond"
var line: int = 0
var baits: Dictionary = {"worm": 10}
var bait: String = "worm"
var keepnet: Array = []
var record: Dictionary = {}
var counts: Dictionary = {}
var owned: Dictionary = {"hook0": true, "float0": true, "feeder0": true, "lure0": true, "sig0": true}
const RIG0 := {"type": "float", "hook": 0, "float": 0, "sinker": 0, "feeder": 0, "fdepth": 1.5, "sig": 0}
var slots: Array = []
var cur: int = 0
var stands: int = 1
var rig: Dictionary = {}
var gb_sel: Dictionary = {"base": "univ", "flavor": "none", "add": "none"}
var gb_mix: Dictionary = {}
var gb_portions: int = 0

func _init() -> void:
	_default_slots()

func _default_slots() -> void:
	slots = [RIG0.duplicate(), RIG0.duplicate(), RIG0.duplicate()]
	cur = 0
	rig = slots[0]

func set_cur(i: int) -> void:
	cur = clampi(i, 0, 2)
	rig = slots[cur]

func _ready() -> void:
	load_game()

func level() -> int:
	return 1 + int(sqrt(float(xp) / 50.0))

func reset() -> void:
	silver = 250
	gold = 0
	xp = 0
	rods = {"float": 0, "feeder": -1, "spin": -1}
	lure = 0
	loc = "pond"
	line = 0
	baits = {"worm": 10}
	bait = "worm"
	keepnet = []
	record = {}
	counts = {}
	owned = {"hook0": true, "float0": true, "feeder0": true, "lure0": true, "sig0": true}
	stands = 1
	_default_slots()
	gb_sel = {"base": "univ", "flavor": "none", "add": "none"}
	gb_mix = {}
	gb_portions = 0

func save_game() -> void:
	var d := {"silver": silver, "gold": gold, "xp": xp, "rods": rods, "lure": lure, "loc": loc, "line": line, "baits": baits, "bait": bait, "keepnet": keepnet, "record": record, "counts": counts, "owned": owned, "slots": slots, "cur": cur, "stands": stands, "gb_sel": gb_sel, "gb_mix": gb_mix, "gb_portions": gb_portions}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))

func _merge(base: Dictionary, extra) -> Dictionary:
	var out := base.duplicate()
	if typeof(extra) == TYPE_DICTIONARY:
		for k in extra:
			out[k] = extra[k]
	return out

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return
	silver = int(d.get("silver", silver))
	gold = int(d.get("gold", gold))
	xp = int(d.get("xp", xp))
	rods = _merge(rods, d.get("rods"))
	if d.has("rod") and not d.has("rods"):
		rods["float"] = clampi(int(d["rod"]), 0, 2)
	lure = int(d.get("lure", 0))
	loc = str(d.get("loc", "pond"))
	line = clampi(int(d.get("line", line)), 0, 2)
	baits = _merge(baits, d.get("baits"))
	bait = str(d.get("bait", bait))
	keepnet = d.get("keepnet", keepnet)
	record = _merge(record, d.get("record"))
	counts = _merge(counts, d.get("counts"))
	owned = _merge(owned, d.get("owned"))
	stands = clampi(int(d.get("stands", 1)), 1, 3)
	var sl = d.get("slots")
	if typeof(sl) == TYPE_ARRAY and sl.size() == 3:
		for i in 3:
			slots[i] = _merge(RIG0, sl[i])
	elif d.has("rig"):
		slots[0] = _merge(RIG0, d.get("rig"))
	set_cur(int(d.get("cur", 0)))
	gb_sel = _merge(gb_sel, d.get("gb_sel"))
	gb_mix = _merge({}, d.get("gb_mix"))
	gb_portions = int(d.get("gb_portions", 0))
	for sdict in slots:
		if int(rods.get(str(sdict["type"]), -1)) < 0:
			sdict["type"] = "float"

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()
