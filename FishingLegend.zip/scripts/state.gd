extends Node
# Глобальное состояние игрока и сохранение (user://save.json)

const SAVE_PATH := "user://save.json"

var silver: int = 150
var gold: int = 0
var xp: int = 0
var rod: int = 0
var line: int = 0
var baits: Dictionary = {"worm": 10}
var bait: String = "worm"
var keepnet: Array = []
var record: Dictionary = {}

func _ready() -> void:
	load_game()

func level() -> int:
	return 1 + int(sqrt(float(xp) / 50.0))

func reset() -> void:
	silver = 150
	gold = 0
	xp = 0
	rod = 0
	line = 0
	baits = {"worm": 10}
	bait = "worm"
	keepnet = []
	record = {}

func save_game() -> void:
	var d := {"silver": silver, "gold": gold, "xp": xp, "rod": rod, "line": line, "baits": baits, "bait": bait, "keepnet": keepnet, "record": record}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return
	silver = int(d.get("silver", silver))
	gold = int(d.get("gold", gold))
	xp = int(d.get("xp", xp))
	rod = clampi(int(d.get("rod", rod)), 0, 2)
	line = clampi(int(d.get("line", line)), 0, 2)
	baits = d.get("baits", baits)
	bait = str(d.get("bait", bait))
	keepnet = d.get("keepnet", keepnet)
	record = d.get("record", record)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()
