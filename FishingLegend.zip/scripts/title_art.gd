extends Control
# Иллюстрация главного меню: прыгающий осётр, удилище, брызги

var _t: float = 0.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	if is_visible_in_tree():
		_t += delta
		queue_redraw()

func _draw() -> void:
	var c := Vector2(size.x * 0.5, size.y * 0.58)
	var bob := sin(_t * 1.1) * 8.0
	# поверхность воды
	var wy := size.y * 0.52
	draw_line(Vector2(0, wy), Vector2(size.x, wy), Color(0.6, 0.85, 1.0, 0.35), 3.0)
	for i in 14:
		var x := size.x * (float(i) / 13.0)
		draw_arc(Vector2(x, wy + 6 + sin(_t + float(i)) * 3.0), 18, PI * 1.1, PI * 1.9, 10, Color(0.6, 0.85, 1.0, 0.18), 2.0)
	# удилище и леска
	var tipp := Vector2(size.x * 0.12, size.y * 0.08)
	var base := Vector2(size.x * 0.9, size.y * 0.42)
	var mid := Vector2(size.x * 0.45, size.y * 0.0 + 20)
	var pts := PackedVector2Array()
	for i in 25:
		var t := float(i) / 24.0
		var p := base.lerp(mid, t * 2.0) if t < 0.5 else mid.lerp(tipp, (t - 0.5) * 2.0)
		p.y += sin(t * PI) * 20.0
		pts.append(p)
	draw_polyline(pts, Color(0.08, 0.09, 0.11), 6.0, true)
	var hook := c + Vector2(150, -90 + bob)
	draw_line(tipp, hook + Vector2(0, -40), Color(0.85, 0.9, 1.0, 0.6), 1.5, true)
	draw_arc(hook + Vector2(-8, 0), 14, 0.2, PI * 1.1, 14, Color(0.85, 0.88, 0.92), 3.0)
	# рыба
	draw_set_transform(c + Vector2(0, bob), -0.55, Vector2(0.78, 0.78))
	var body := PackedVector2Array([Vector2(-300, 40), Vector2(-220, 5), Vector2(-120, -22), Vector2(0, -40), Vector2(120, -44), Vector2(230, -32), Vector2(320, -8), Vector2(392, 18), Vector2(330, 36), Vector2(230, 48), Vector2(120, 58), Vector2(0, 62), Vector2(-120, 60), Vector2(-220, 70)])
	draw_colored_polygon(body, Color(0.55, 0.58, 0.55))
	draw_colored_polygon(PackedVector2Array([Vector2(-200, 62), Vector2(-100, 52), Vector2(0, 58), Vector2(120, 54), Vector2(230, 44), Vector2(320, 32), Vector2(240, 66), Vector2(100, 80), Vector2(-60, 82)]), Color(0.82, 0.84, 0.8))
	draw_colored_polygon(PackedVector2Array([Vector2(-300, 40), Vector2(-390, -30), Vector2(-350, 40), Vector2(-420, 120)]), Color(0.42, 0.45, 0.43))
	draw_colored_polygon(PackedVector2Array([Vector2(60, 50), Vector2(150, 130), Vector2(20, 70)]), Color(0.45, 0.48, 0.46))
	for i in 9:
		draw_rect(Rect2(Vector2(-180 + i * 48, -36 - sin(float(i) * 0.5) * 6.0), Vector2(26, 10)), Color(0.35, 0.37, 0.35))
	draw_circle(Vector2(300, 6), 6, Color(0.02, 0.02, 0.03))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 1))
	# брызги
	for i in 18:
		var a := float(i) * 0.7 + _t * 0.4
		var p := Vector2(c.x - 40 + cos(a) * (60 + float(i) * 5.0), wy - 10 - abs(sin(a * 1.3)) * 70)
		draw_circle(p, 2.0 + float(i % 3), Color(0.8, 0.95, 1.0, 0.5))
