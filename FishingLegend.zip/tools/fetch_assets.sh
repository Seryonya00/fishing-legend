#!/usr/bin/env bash
# Необязательно: качает CC0-текстуру земли с Poly Haven. Игра работает и без неё.
mkdir -p assets
for id in forrest_ground_01 aerial_grass_rock coast_sand_rocks_02 rocky_terrain_02; do
  if curl -fsSL --max-time 60 -o assets/ground_diff.jpg "https://dl.polyhaven.org/file/ph-assets/Textures/jpg/1k/${id}/${id}_diff_1k.jpg"; then
    echo "Poly Haven texture: ${id}"
    exit 0
  fi
  rm -f assets/ground_diff.jpg
done
echo "Poly Haven texture not downloaded, using plain colors"
exit 0
