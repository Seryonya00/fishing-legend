#!/usr/bin/env python3
"""Генерирует мягкие звуки (raw PCM 16 бит, моно, 22050 Гц) в assets/audio/*.pcm
Запуск: python3 tools/gen_audio.py  (только стандартная библиотека)"""
import math, random, struct, os

SR = 22050
random.seed(7)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
os.makedirs(OUT, exist_ok=True)

def n_samples(sec): return int(sec * SR)
def noise(n): return [random.uniform(-1, 1) for _ in range(n)]

def lp(xs, a):
    y = 0.0
    out = []
    for s in xs:
        y += a * (s - y)
        out.append(y)
    return out

def norm(xs, peak):
    m = max(1e-9, max(abs(s) for s in xs))
    return [s * peak / m for s in xs]

def fade(xs, ms=8):
    n = len(xs)
    f = min(int(ms * SR / 1000), n // 2)
    for i in range(f):
        t = i / f
        xs[i] *= t
        xs[n - 1 - i] *= t
    return xs

def loopify(xs, sec=0.4):
    n = len(xs)
    f = int(sec * SR)
    out = xs[: n - f]
    for i in range(f):
        t = i / f
        out[i] = xs[i] * t + xs[n - f + i] * (1 - t)
    return out

def save(name, xs):
    data = bytearray()
    for s in xs:
        v = int(max(-1.0, min(1.0, s)) * 32767)
        data += struct.pack("<h", v)
    with open(os.path.join(OUT, name + ".pcm"), "wb") as f:
        f.write(data)

def env_exp(n, tau):
    return [math.exp(-(i / SR) / tau) for i in range(n)]

# ---------- фоновые петли ----------
def wind():
    n = n_samples(7)
    base = lp(lp(noise(n), 0.03), 0.05)
    out = []
    for i, s in enumerate(base):
        t = i / SR
        am = 0.55 + 0.25 * math.sin(2 * math.pi * t / 5.3) + 0.2 * math.sin(2 * math.pi * t / 2.1 + 1.0)
        out.append(s * am)
    return loopify(norm(out, 0.55), 0.6)

def water():
    n = n_samples(6)
    a = lp(noise(n), 0.07)
    b = lp(noise(n), 0.3)
    out = []
    for i in range(n):
        t = i / SR
        lap = 0.5 + 0.5 * math.sin(2 * math.pi * t / 3.1 + 0.6)
        lap2 = 0.5 + 0.5 * math.sin(2 * math.pi * t / 1.7)
        out.append(a[i] * (0.35 + 0.65 * lap) + b[i] * 0.18 * lap2)
    return loopify(norm(out, 0.5), 0.5)

def rain():
    n = n_samples(4)
    x = noise(n)
    hi = [s - l for s, l in zip(x, lp(x, 0.25))]
    out = lp(hi, 0.55)
    return loopify(norm(out, 0.5), 0.4)

def crickets():
    n = n_samples(4)
    out = [0.0] * n
    for (f0, off) in ((4300.0, 0.0), (4650.0, 0.17)):
        for burst in range(8):
            t0 = burst * 0.5 + off
            for p in range(4):
                tp = t0 + p * 0.055
                for i in range(int(0.03 * SR)):
                    idx = int(tp * SR) + i
                    if idx >= n:
                        continue
                    e = math.sin(math.pi * i / (0.03 * SR)) ** 2
                    out[idx] += math.sin(2 * math.pi * f0 * i / SR) * e * 0.5
    return norm(out, 0.22)

def drag():
    n = n_samples(1.2)
    x = noise(n)
    out = [a - b for a, b in zip(lp(x, 0.4), lp(x, 0.05))]
    return loopify(norm(out, 0.4), 0.2)

# ---------- разовые звуки ----------
def bird(seed):
    r = random.Random(seed)
    out = []
    for note in range(r.randint(3, 5)):
        f0 = r.uniform(2200, 3600)
        f1 = f0 * r.uniform(0.7, 1.4)
        dur = r.uniform(0.06, 0.11)
        n = n_samples(dur)
        ph = 0.0
        for i in range(n):
            f = f0 + (f1 - f0) * i / n
            ph += 2 * math.pi * f / SR
            out.append(math.sin(ph) * (math.sin(math.pi * i / n) ** 2) * 0.5)
        out += [0.0] * n_samples(r.uniform(0.05, 0.12))
    return fade(norm(out, 0.35))

def splash():
    n = n_samples(0.7)
    x = lp(noise(n), 0.22)
    e = env_exp(n, 0.12)
    return fade(norm([a * b for a, b in zip(x, e)], 0.55))

def plop():
    n = n_samples(0.3)
    out = []
    ph = 0.0
    for i in range(n):
        f = 520 * math.exp(-i / SR * 6.0) + 130
        ph += 2 * math.pi * f / SR
        out.append(math.sin(ph) * math.exp(-i / SR * 11.0))
    nz = lp(noise(n), 0.2)
    out = [o + 0.25 * z * math.exp(-i / SR * 25.0) for i, (o, z) in enumerate(zip(out, nz))]
    return fade(norm(out, 0.55))

def plip():
    n = n_samples(0.08)
    out = [math.sin(2 * math.pi * 740 * i / SR) * math.exp(-i / SR * 45.0) for i in range(n)]
    return fade(norm(out, 0.3))

def bell():
    n = n_samples(1.6)
    out = []
    for i in range(n):
        t = i / SR
        v = (math.sin(2 * math.pi * 2093 * t) * math.exp(-t * 2.8)
             + 0.6 * math.sin(2 * math.pi * 3136 * t) * math.exp(-t * 3.6)
             + 0.25 * math.sin(2 * math.pi * 4180 * t) * math.exp(-t * 5.0))
        out.append(v)
    return fade(norm(out, 0.38))

def click():
    n = n_samples(0.03)
    x = noise(n)
    out = [x[i] * math.exp(-i / SR * 220.0) * 0.6 + math.sin(2 * math.pi * 1900 * i / SR) * math.exp(-i / SR * 300.0) * 0.4 for i in range(n)]
    return fade(norm(lp(out, 0.7), 0.3), 2)

def swish():
    n = n_samples(0.4)
    x = lp(noise(n), 0.16)
    out = [x[i] * (math.sin(math.pi * i / n) ** 2) for i in range(n)]
    return fade(norm(out, 0.4))

def chime():
    out = []
    for (f, d) in ((784.0, 0.0), (1046.5, 0.18)):
        n = n_samples(1.3)
        off = int(d * SR)
        out += [0.0] * max(0, off + n - len(out))
        for i in range(n):
            t = i / SR
            out[off + i] += (math.sin(2 * math.pi * f * t) + 0.3 * math.sin(2 * math.pi * f * 2 * t)) * math.exp(-t * 3.2) * (min(1.0, t * 80))
    return fade(norm(out, 0.33))

def snap():
    n = n_samples(0.25)
    x = noise(n)
    out = [x[i] * math.exp(-i / SR * 40.0) for i in range(n)]
    out = lp(out, 0.5)
    return fade(norm(out, 0.6), 2)

def step_grass():
    n = n_samples(0.12)
    x = lp(noise(n), 0.12)
    out = [x[i] * math.exp(-i / SR * 28.0) for i in range(n)]
    return fade(norm(out, 0.3))

def step_wood():
    n = n_samples(0.16)
    out = []
    x = noise(n)
    for i in range(n):
        t = i / SR
        out.append(math.sin(2 * math.pi * 150 * t) * math.exp(-t * 30.0) * 0.8 + x[i] * math.exp(-t * 90.0) * 0.25)
    return fade(norm(lp(out, 0.5), 0.45))

def thunder():
    n = n_samples(4.0)
    x = lp(lp(noise(n), 0.02), 0.04)
    out = []
    for i in range(n):
        t = i / SR
        e = min(1.0, t * 5.0) * math.exp(-t * 0.9) * (0.7 + 0.3 * math.sin(2 * math.pi * t * 1.7))
        out.append(x[i] * e)
    return fade(norm(out, 0.8), 30)


# ===== мягкие версии (переопределяют старые) =====
def wind():
    n = n_samples(7)
    base = lp(lp(noise(n), 0.03), 0.05)
    out = []
    for i, v in enumerate(base):
        t = i / SR
        out.append(v * (0.55 + 0.25 * math.sin(2 * math.pi * t / 5.3) + 0.2 * math.sin(2 * math.pi * t / 2.1 + 1.0)))
    return loopify(norm(out, 0.4), 0.6)

def drag():
    n = n_samples(1.5)
    x = lp(lp(noise(n), 0.12), 0.2)
    out = [x[i] * (0.75 + 0.25 * math.sin(2 * math.pi * i / SR * 0.7)) for i in range(n)]
    return loopify(norm(out, 0.1), 0.3)

def click():
    n = n_samples(0.04)
    x = lp(noise(n), 0.25)
    out = [x[i] * math.sin(math.pi * i / n) ** 2 for i in range(n)]
    return fade(norm(out, 0.09), 4)

def snap():
    n = n_samples(0.3)
    out = []
    ph = 0.0
    for i in range(n):
        f = 320 * math.exp(-i / SR * 9.0) + 110
        ph += 2 * math.pi * f / SR
        out.append(math.sin(ph) * math.exp(-i / SR * 14.0))
    return fade(norm(lp(out, 0.4), 0.22), 10)

def plop():
    n = n_samples(0.35)
    out = []
    ph = 0.0
    for i in range(n):
        f = 380 * math.exp(-i / SR * 7.0) + 120
        ph += 2 * math.pi * f / SR
        out.append(math.sin(ph) * math.exp(-i / SR * 10.0) * min(1.0, i / (SR * 0.01)))
    return fade(norm(lp(out, 0.5), 0.26), 10)

def splash():
    n = n_samples(0.8)
    x = lp(noise(n), 0.1)
    e = [math.exp(-i / SR * 6.0) * min(1.0, i / (SR * 0.02)) for i in range(n)]
    return fade(norm([a * b for a, b in zip(x, e)], 0.3), 15)

def plip():
    n = n_samples(0.1)
    out = [math.sin(2 * math.pi * 620 * i / SR) * math.exp(-i / SR * 35.0) * min(1.0, i / (SR * 0.006)) for i in range(n)]
    return fade(norm(out, 0.16), 6)

def bell():
    n = n_samples(1.4)
    out = []
    for i in range(n):
        t = i / SR
        a = min(1.0, t * 60.0)
        out.append(a * (math.sin(2 * math.pi * 1568 * t) * math.exp(-t * 3.4) + 0.5 * math.sin(2 * math.pi * 2349 * t) * math.exp(-t * 4.5)))
    return fade(norm(out, 0.2), 10)

def rattle():
    out = [0.0] * n_samples(1.6)
    for k in range(6):
        off = int((k * 0.09 + random.uniform(0, 0.03)) * SR)
        f = random.choice([1568, 1760, 2093, 2349])
        for i in range(n_samples(0.5)):
            t = i / SR
            if off + i < len(out):
                out[off + i] += math.sin(2 * math.pi * f * t) * math.exp(-t * 6.0) * min(1.0, t * 80.0) * 0.5
    return fade(norm(out, 0.24), 10)

def beep():
    n = n_samples(0.2)
    out = [(math.sin(2 * math.pi * 880 * i / SR) + 0.3 * math.sin(2 * math.pi * 1320 * i / SR)) * math.sin(math.pi * i / n) ** 2 for i in range(n)]
    return fade(norm(out, 0.16), 10)

def swish():
    n = n_samples(0.45)
    x = lp(lp(noise(n), 0.1), 0.2)
    return fade(norm([x[i] * math.sin(math.pi * i / n) ** 2 for i in range(n)], 0.2), 20)

def chime():
    out = []
    for (f, d) in ((660.0, 0.0), (880.0, 0.22)):
        n = n_samples(1.8)
        off = int(d * SR)
        out += [0.0] * max(0, off + n - len(out))
        for i in range(n):
            t = i / SR
            out[off + i] += (math.sin(2 * math.pi * f * t) + 0.2 * math.sin(2 * math.pi * f * 2 * t)) * math.exp(-t * 2.4) * min(1.0, t * 12.0)
    return fade(norm(out, 0.2), 30)

def step_grass():
    n = n_samples(0.14)
    x = lp(lp(noise(n), 0.1), 0.3)
    return fade(norm([x[i] * math.exp(-i / SR * 24.0) * min(1.0, i / (SR * 0.01)) for i in range(n)], 0.18), 8)

def step_wood():
    n = n_samples(0.18)
    out = [math.sin(2 * math.pi * 140 * i / SR) * math.exp(-i / SR * 26.0) * min(1.0, i / (SR * 0.008)) for i in range(n)]
    return fade(norm(lp(out, 0.4), 0.28), 8)

def thunder():
    n = n_samples(4.5)
    x = lp(lp(noise(n), 0.02), 0.03)
    out = []
    for i in range(n):
        t = i / SR
        out.append(x[i] * min(1.0, t * 3.0) * math.exp(-t * 0.8) * (0.7 + 0.3 * math.sin(2 * math.pi * t * 1.3)))
    return fade(norm(out, 0.5), 60)

def frog():
    out = []
    for c in range(3):
        n = n_samples(0.22)
        for i in range(n):
            t = i / SR
            am = 0.5 + 0.5 * math.sin(2 * math.pi * 28 * t)
            out.append(math.sin(2 * math.pi * (170 + 20 * c) * t) * am * math.sin(math.pi * i / n) ** 2)
        out += [0.0] * n_samples(0.12)
    return fade(norm(lp(out, 0.35), 0.2), 20)

def fishjump():
    n = n_samples(0.9)
    x = lp(noise(n), 0.09)
    out = [x[i] * math.exp(-i / SR * 5.0) * min(1.0, i / (SR * 0.04)) for i in range(n)]
    ph = 0.0
    for i in range(int(0.2 * SR)):
        ph += 2 * math.pi * (300 * math.exp(-i / SR * 8.0) + 100) / SR
        out[int(0.3 * SR) + i] += math.sin(ph) * math.exp(-i / SR * 12.0) * 0.5
    return fade(norm(lp(out, 0.4), 0.25), 20)

def rustle():
    n = n_samples(5)
    x = noise(n)
    hi = [a - b for a, b in zip(x, lp(x, 0.2))]
    out = lp(hi, 0.45)
    out = [out[i] * (0.5 + 0.5 * math.sin(2 * math.pi * i / SR / 2.5) ** 2) for i in range(n)]
    return loopify(norm(out, 0.22), 0.4)

def music():
    chords = [
        [110.0, 164.81, 196.0, 261.63],
        [87.31, 130.81, 164.81, 220.0],
        [130.81, 196.0, 246.94, 329.63],
        [98.0, 146.83, 164.81, 246.94],
    ]
    seg = 6.0
    total = n_samples(seg * len(chords))
    out = [0.0] * total
    for k, ch in enumerate(chords):
        start = int((k * seg - 1.6) * SR)
        length = int((seg + 3.2) * SR)
        for f in ch:
            for det in (0.0, 0.7):
                ph = random.uniform(0, 6.28)
                w = 2 * math.pi * (f + det) / SR
                for i in range(length):
                    e = math.sin(math.pi * i / length) ** 2
                    out[(start + i) % total] += math.sin(ph + w * i) * e * 0.16
    out = lp(out, 0.18)
    return norm(out, 0.32)


def rain():
    # естественный дождь: мягкий шорох + множество отдельных капель + редкие «плюхи» по воде
    n = n_samples(8)
    x = noise(n)
    soft = [a * 0.65 + b * 0.35 for a, b in zip(lp(x, 0.07), lp(x, 0.3))]
    out = [v * 0.2 for v in soft]
    rnd = random.Random(21)
    for _ in range(8 * 240):
        pos = rnd.randrange(0, n - 600)
        f = rnd.uniform(1600, 5200)
        dec = rnd.uniform(220, 650)
        amp = rnd.uniform(0.04, 0.26)
        for i in range(520):
            t = i / SR
            out[pos + i] += math.sin(2 * math.pi * f * t) * math.exp(-t * dec) * amp
    for _ in range(8 * 5):
        pos = rnd.randrange(0, n - 3000)
        f0 = rnd.uniform(180, 380)
        amp = rnd.uniform(0.15, 0.35)
        ph = 0.0
        for i in range(2400):
            t = i / SR
            ph += 2 * math.pi * (f0 * math.exp(-t * 5.0) + 90) / SR
            out[pos + i] += math.sin(ph) * math.exp(-t * 22.0) * amp
    out = [out[i] * (0.88 + 0.12 * math.sin(2 * math.pi * i / SR / 3.7)) for i in range(n)]
    out = lp(out, 0.6)
    return loopify(norm(out, 0.32), 0.5)


def ratchet():
    # мягкий «треск» фрикциона: частые тихие щелчки, закольцованные
    n = n_samples(1.0)
    out = [0.0] * n
    rnd = random.Random(33)
    ticks = 28
    for k in range(ticks):
        pos = int(k * n / ticks) + rnd.randint(0, 200)
        amp = rnd.uniform(0.5, 1.0)
        for i in range(260):
            if pos + i >= n:
                break
            t = i / SR
            out[pos + i] += amp * (math.sin(2 * math.pi * 1500 * t) * 0.6 + rnd.uniform(-0.4, 0.4)) * math.exp(-t * 520.0)
    out = lp(out, 0.55)
    return norm(out, 0.18)

for name, fn in [
    ("wind", wind), ("water", water), ("rain", rain), ("crickets", crickets), ("drag", drag),
    ("rustle", rustle), ("music", music), ("ratchet", ratchet),
    ("bird1", lambda: bird(1)), ("bird2", lambda: bird(2)), ("bird3", lambda: bird(3)),
    ("splash", splash), ("plop", plop), ("plip", plip), ("bell", bell), ("rattle", rattle),
    ("beep", beep), ("click", click), ("swish", swish), ("chime", chime), ("snap", snap),
    ("step_grass", step_grass), ("step_wood", step_wood), ("thunder", thunder),
    ("frog", frog), ("fishjump", fishjump),
]:
    save(name, fn())
print("audio ok")
